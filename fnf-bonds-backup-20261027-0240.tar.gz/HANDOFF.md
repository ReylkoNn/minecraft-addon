# HANDOFF — FNF Bonds (аддон для Friends&Foes, NeoForge / Minecraft 26.2)

Обновлён: 2026-10-27 02:30 (после перезапуска песочницы).
Проект: `/home/user/fnf-bonds`. Мод: `fnfbonds` — «деревенская экономика» (v0.1.0 собрана и проверена; v0.2.0 = текстуры + блоки, сборка ЗАБЛОКИРОВАНА одним шагом, см. §3).

---

## 1. Что готово и проверено

- **Код**: 45+ java-файлов, экономика деревни (контракты, стояние, караваны, цены, проекты), GUI 288×216, HUD, `/bonds`, 9 достижений. Серверный self-test: **44/0** (детерминированно). Клиентский: 9/0 + 7 скриншотов (`release/screenshots-v0.1.0/`).
- **Текстуры (одобрены пользователем)**: 8 предметов 32×32 + 5 блоков ×(top+side) + beeswax_block — **установлены в проект** (`assets/fnfbonds/textures/{item,block}`, модели `models/block/*.json` — 5× `cube`, beeswax `cube_all`; JSON валидны). Источники NN-генераций: `uploads/`, пайплайны: `work/grid_snap.py`, `work/grid_snap_blocks.py`.
- **Релизы**: `release/` — v0.1.0 (zip/tar.gz/jar), textures-pass v0.1.1 (zip/tar.gz), CHECKSUMS.txt. Бэкапы: `backups/`.
- **ClientSelfTest расширен** фазами 08/09 (текстур-пруф: 14 ItemStack + 6 блоков в мире + InventoryScreen → скриншоты `08_blocks_row`, `09_items_inventory`) — **НЕ компилировалось ни разу** (сборка до compileJava не дошла). Первый успешный build может выявить ошибки в этих правках — чинить по факту.

## 2. Главное достижение последней сессии: конвейер декомпиляции MC 26.2 в песочнице 2 ГБ БЕЗ swap

Проблема: NFRT декомпилирует Minecraft vineflower'ом, которому нужно ~4 ГБ heap; машина 2 ГБ без swap (swapon недоступен, uid 1000; jupyter-server — root, не убивается; ~600 МБ базы не freeing).

Решение (ВСЁ проверено на практике, артефакты — см. §4):
1. **Патч neoform zip** (`config.json`): `functions.decompile.jvmargs=[]` (иначе NFRT's `setJvmArgs` принудительно ставит `-Xmx4096m` — он ЗАМЕНЯЕТ любой -Xmx из конфига!) + `--thread-count=1` вставлен **ПЕРЕД** `-cfg=` (порядок критичен: vineflower трактует всё после первого позиционного аргумента как пути; опция после `{output}` превращается в файл/каталог назначения!).
2. **Батч-декомпиляция**: 7055 внешних классов → 7 батчей по ≤1100 (`-only=<список через запятую>`), heap 1150m SerialGC, каждый ~20-60 с, 0-1 заглушек. Единственный класс, который vineflower НЕ может сделать ни при каком heap ≤1.4 ГБ — `BlockStateData` (гигантский метод datafix) → **CFR 0.152** + 3 механические правки generic-кастов + javac-проверка (`cfr_fix.py`).
3. **Проблема стилей**: батч-контекст меняет стиль импорта/имён (FQN vs short, nested-import) → 4 реджекта vanilla-патчей + 110 реджектов NeoForge-патчей. **Решение — closure-техника** (`closure.py` + `big_runner.py`): для каждого реджект-файла в `-only` включаются ВСЕ MC-классы, чьи короткие имена встречаются в тексте файла (closure). Стиль совпадает с эталоном ИДЕАЛЬНО: после замены 114 целей closure-версиями → **vanilla 144 патча + NeoForge 882 патча легли с НУЛЁМ реджектов**.
4. **Инъекция в кеш NFRT**: финальный jar копируется в `~/.cache/gradle/caches/neoformruntime/intermediate_results/decompile_<KEY>_output.jar` **ПЛЮС sidecar** `decompile_<KEY>.txt` (JSON-манифест компонентов ключа — БЕЗ него кеш-хит не срабатывает!). KEY = `7b35e5ff231ac4d752f1f4bfd421f6a745ca2059` для текущей патченной конфигурации; sidecar сохранён в `work/vf/`. Ключ ловится из verbose-лога (`neoFormRuntime.verbose=true` в build.gradle печатает `Cache Key: decompile_...` + компоненты). Ключ меняется при ЛЮБОМ изменении config-аргументов.
5. **Память при сборке**: декомпиляция НЕ должна идти одновременно с gradle-демоном. Когда decompile в кеше — демон можно раздуть: `-Dorg.gradle.jvmargs="-Xmx1200m -XX:MaxMetaspaceSize=320m -XX:+UseSerialGC"` + `JAVA_TOOL_OPTIONS="-Xmx1100m -XX:+UseSerialGC"` (для форков). ECJ (`useEclipseCompiler=true` в build.gradle) компилирует 7055 файлов за ~14 с в 1.2 ГБ heap.

## 3. ТЕКУЩИЙ БЛОКЕР (ровно один) и следующие шаги

Сборка 2026-10-26 23:00 дошла до: decompile ✓ (кеш) → patch ✓ → applyNeoforgePatches ✓ (0 реджектов!) → transformSources ✓ → **recompile (ECJ): 1 ошибка**:
```
ERRORS FOUND in com/mojang/blaze3d/opengl/GlBuffer.java
ERROR: Pb(1103) Flexible Constructor Bodies is a preview feature ... Use --enable-preview
```
Причина: конструктор `GlBuffer.Direct` в декомпиляте имеет операторы ДО `super(...)` (JEP 513 — preview в Java 25). Это моя БАТЧ-версия файла (GlBuffer не входил в 114 closure-целей). Гипотеза: в полном/closure-контексте vineflower выдаёт классический порядок (эталонный конвейер NeoForge как-то компилируется — значит их декомпилят либо без preview-синтаксиса, либо с другим флагом).

**План (по приоритету):**
1. **Closure-прогон для GlBuffer**: `python3 closure.py decompile_final2.jar glb_list.txt com/mojang/blaze3d/opengl/GlBuffer.java` → один vf-запуск с этим списком (как в big_runner, ~1 мин) → заменить `com/mojang/blaze3d/opengl/GlBuffer.java` в финальном jar → реинъекция (§2.4) → rebuild. Если конструктор стал классическим — ГОТОВО.
2. Если не помогло: **ручная правка в кеше transformSources** (`transformSources_fba42a54..._output.zip`): переписать конструктор Direct — `super(usage, size, handle, canPersistentMap);` первой строкой, остальные операторы после (СНАЧАЛА проверить конструкторы GpuBuffer/GlBuffer на порядок-зависимость: `MEMORY_POOL.malloc` до super может быть намеренным). Ключ recompile-ноды контент-зависимый → пересчитается сам.
3. Альтернативы (тяжёлые): патч NFRT jar (ECJ `enablePreviewFeatures`), либо `useEclipseCompiler=false` (javac in-daemon — память рискованнее, и javac 25 тоже требует --enable-preview для JEP513 — вероятно тупик).
4. После успешного build: **проверить compileJava наших 45+ файлов** (особенно ClientSelfTest 08/09 — не компилировались!), затем `-PselfTest` (runServer, 44/0), затем релиз v0.2.0 (поднять `mod_version` в gradle.properties!) + CHECKSUMS + скриншоты 08/09 через `runClient -PclientTest` (ЕСЛИ память позволит: игра ~900m-1.1g + демон 384m + xvfb; при невозможности — релиз без 08/09, текстуры data-driven и уже валидированы JSON-ом).

## 4. Карта файлов (что где после перезапуска)

- `/home/user/fnf-bonds/` — проект (текстуры/модели установлены; build.gradle: `neoFormRuntime{useEclipseCompiler=true; verbose=true}`; ClientSelfTest 08/09). `libs/` — F&F 5.0.3 + ResourcefulLib 5.0.4. `gradlew` (+x теряется при рестарте!).
- `/home/user/work/vf/` — конвейер декомпиляции:
  - `REBUILD.sh` — **ПОШАГОВОЕ восстановление всего с нуля** (JDK, прогрев кеша, патч zip, батчи, CFR, closure, merge, инъекция, build);
  - `vf_runner.py` (батчи 0-6), `big_runner.py` (5 closure-прогонов по `run_plan.json`), `closure.py`, `merge_final.py`, `cfr_fix.py`, `vf_batches.py`;
  - `batches.json`, `big_targets.txt` (114 целей), `big_list.txt`, `run_plan.json`, `test4_list.txt`;
  - `decompile_7b35e5ff231ac4d752f1f4bfd421f6a745ca2059.txt` — **sidecar-манифест ключа кеша** (критичен!);
  - `libraries.txt`, `cfr_cp.txt`, `cfr_cp_full.txt`, `cfr.jar` (CFR 0.152), `stubfix.py`;
  - логи: `log_0*.txt` (батчи), `run_*.log` (closure: видны заглушки Blocks/DataFixers — они НЕ цели, игнорируются).
  - **ВСЕ jar-артефакты конвейера утеряны/вычищены** (decompile_final2.jar, big_*.jar, out_*.jar, test4.jar, cfr_fix/) — REBUILD.sh перегенерирует их с нуля за ~40-60 мин машинного времени.
- `/home/user/work/` — текстурные скрипты (`grid_snap*.py`, `make_*`, `postprocess.py`) + `texnn32/` (**финалы текстур: items32 + block faces**). Промежуточные кропы `texsrc*/`, скачанные `dl/`, распакованный `fnf/`+`fnf.jar` — **УДАЛЕНЫ 27.10 для вписывания в лимит снапшота**; при надобности: texsrc кропается заново из `uploads/` (aspect-grid, длинная сторона 32), F&F-схемы = `unzip fnf-bonds/libs/friendsandfoes-neoforge-5.0.3+mc26.2.jar`.
- `/home/user/uploads/` — NN-генерации пользователя (источники текстур) — 21 файл, НЕ ТРОГАТЬ.
- `/home/user/release/` — `fnfbonds-0.1.0.jar` (РАБОЧИЙ собранный мод), textures-pass v0.1.1 (.zip), `screenshots-v0.1.0/` (7 шт.), CHECKSUMS.txt. Project-архивы v0.1.0 и textures .tar.gz удалены 27.10 (дублировали содержимое workspace/бэкапа).
- `/home/user/backups/` — ЕДИНСТВЕННЫЙ актуальный бэкап (старые -2152/-0200/-1340 удалены 27.10: устарели и не содержали uploads/ и work/vf/). **ПОЛИТИКА: суммарный workspace должен быть <128 МБ, иначе снапшот МОЛЧА выбрасывает файлы (так пропал бэкап -0235 при workspace ~220 МБ).** После любого крупного бэкапа — чистить промежуточное.
- `fnf-bonds/run/` — остались только конфиги; `saves/`, `world/`, `logs/`, `screenshots/` удалены 27.10 (скриншоты сохранены в `release/screenshots-v0.1.0/`; сейвы пересоздаются runServer).
- `~/.cache/` — **НЕ переживает рестарт**: JDK25, gradle-кеш (~490 МБ), все инъекции.

## 5. Ключевые команды

```
# Сборка (когда decompile уже в кеше):
cd /home/user/fnf-bonds && GRADLE_USER_HOME=/home/user/.cache/gradle JAVA_HOME=/home/user/.cache/jdk25 \
JAVA_TOOL_OPTIONS="-Xmx1100m -XX:+UseSerialGC" ./gradlew build --no-daemon \
  -Dorg.gradle.jvmargs="-Xmx1200m -XX:MaxMetaspaceSize=320m -XX:+UseSerialGC" \
  -Dorg.gradle.workers.max=1 --console=plain

# Серверный self-test:  ./gradlew runServer -PselfTest   (демон ≤512m, игра ≤1.1g)
# Клиентский: xvfb-run -a -s "-screen 0 1280x800x24" env GRADLE_USER_HOME=... JAVA_HOME=... \
#   JAVA_TOOL_OPTIONS=-Xmx900m ./gradlew runClient -PclientTest -Dorg.gradle.jvmargs=-Xmx384m
```

## 6. Грабли (проверено на себе)

1. `pkill -f <паттерн>` убивает СОБСТВЕННЫЙ bash, если паттерн есть в командной строке → только `"[C]onsole..."` с скобками.
2. Пайп gradle в `tail` скрывает лог до конца; `grep` в pipe буферизует. Только прямой вывод / tee в файл.
3. vineflower: опции ТОЛЬКО до первого позиционного аргумента; `-t=1` не существует (`--thread-count=1`); каталог-назначение создаётся если output не .jar.
4. NFRT `setJvmArgs`: для vineflower ЛЮБОЙ `-Xmx` в config jvmargs заменяется на `-Xmx4096m` (max(4096, 256×cpu)); пустой jvmargs → heap берётся из `JAVA_TOOL_OPTIONS` env.
5. Кеш NFRT = `<step>_<sha1>_output.jar` **плюс** `<step>_<sha1>.txt` sidecar; без sidecar — кеш-промах. Ключ меняется от любых правок config.json.
6. Gradle НЕ перепроверяет sha1 файлов в files-2.1 при каждом билде → подмена neoform zip in-place работает (но рестарт песочницы всё стирает).
7. **Лимит снапшота workspace ~128 МБ/10k файлов**: большие jar в `work/` МОГУТ НЕ ПЕРЕЖИТЬ рестарт (так потеряли decompile_final2.jar). Держать ≤1-2 крупных артефакта, остальное чистить; важное дублировать в tar.gz.
8. Машина 2 ГБ: `free` ≥1.3 ГБ для vf-прогона; RSS vf ≈ heap+150 МБ (SerialGC); G1 держит +180 МБ. При available<50 МБ начинается reclaim-шторм (bash отвечает минутами, loadavg>7) — глушить процесс и уменьшать heap.
9. OOM-заглушки vineflower (WARN "couldn't be decompiled") НЕ фатальны для патчей, если класс не патчится (проверять по `/tmp/userdev_patchlist.txt` из userdev jar и `/tmp/nf/patches`), но фатальны для ECJ-рекомпайла → чинить CFR.
10. Заглушки closure-членов (Blocks, DataFixers в run_*.log) — ИГНОРИРОВАТЬ: их .java не используются, важен только struct-контекст.

## 7. Статус по задаче пользователя

Текстуры установлены; сборка v0.2.0 была в ОДНОМ шаге от успеха (все патчи легли, ECJ скомпилировал 7054/7055). Пользователь остановил работу 2026-10-27 из-за длительности починки; требуемый порядок: бэкап → отчёт → СТОП и ждать явного go/no-go.
