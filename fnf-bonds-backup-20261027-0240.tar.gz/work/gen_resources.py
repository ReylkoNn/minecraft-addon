#!/usr/bin/env python3
"""Generates every data-driven resource for fnfbonds: models, blockstates, loot tables, tags,
recipes, villager trades and localisation (EN/RU)."""
import json
import pathlib

ROOT = pathlib.Path('/home/user/fnf-bonds/src/main/resources')
A = ROOT / 'assets/fnfbonds'
D = ROOT / 'data/fnfbonds'
FNF_TAGS = ROOT / 'data/friendsandfoes/tags/villager_trade/beekeeper'


def w(path: pathlib.Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def opt(item_id):
    """Optional tag entry: safe when Friends&Foes is absent (it is a hard dep, but tags must not
    hard-crash a datapack override)."""
    return {"id": item_id, "required": False}


BLOCKS = ['ledger_desk', 'contract_board', 'trade_post', 'wax_press', 'cold_cellar', 'beeswax_block']
ITEMS = ['beeswax', 'chitin', 'chitin_plate', 'frost_vial', 'wax_seal', 'mead', 'ledger_book', 'route_map']

# ------------------------------------------------------------------ blocks & items
for b in BLOCKS:
    w(A / 'blockstates' / f'{b}.json', {"variants": {"": {"model": f'fnfbonds:block/{b}'}}})
    w(A / 'models/block' / f'{b}.json',
      {"parent": "minecraft:block/cube_all", "textures": {"all": f'fnfbonds:block/{b}'}})
    w(A / 'models/item' / f'{b}.json', {"parent": f'fnfbonds:block/{b}'})
    w(D / 'loot_table/blocks' / f'{b}.json', {
        "type": "minecraft:block",
        "pools": [{
            "rolls": 1, "bonus_rolls": 0,
            "entries": [{"type": "minecraft:item", "name": f'fnfbonds:{b}'}],
            "conditions": [{"condition": "minecraft:survives_explosion"}]}]})

for i in ITEMS:
    w(A / 'models/item' / f'{i}.json',
      {"parent": "minecraft:item/generated", "textures": {"layer0": f'fnfbonds:item/{i}'}})

# ------------------------------------------------------------------------- tags
COMMODITIES = {
    'grain': ['minecraft:wheat', 'minecraft:bread', 'minecraft:hay_block'],
    'produce': ['minecraft:apple', 'minecraft:carrot', 'minecraft:potato', 'minecraft:beetroot',
                'minecraft:sweet_berries', 'minecraft:melon_slice', 'minecraft:pumpkin',
                'minecraft:glow_berries', 'minecraft:golden_carrot'],
    'honey': ['minecraft:honeycomb', 'minecraft:honey_bottle', 'minecraft:honey_block',
              'fnfbonds:beeswax'],
    'livestock': ['minecraft:leather', 'minecraft:beef', 'minecraft:porkchop', 'minecraft:chicken',
                  'minecraft:mutton', 'minecraft:rabbit', 'minecraft:egg', '#minecraft:wool',
                  'minecraft:feather'],
    'timber': ['minecraft:oak_log', 'minecraft:spruce_log', 'minecraft:birch_log',
               'minecraft:jungle_log', 'minecraft:acacia_log', 'minecraft:dark_oak_log',
               'minecraft:mangrove_log', 'minecraft:cherry_log', 'minecraft:bamboo_block',
               'minecraft:crimson_stem', 'minecraft:warped_stem'],
    'stone': ['minecraft:cobblestone', 'minecraft:stone', 'minecraft:andesite',
              'minecraft:diorite', 'minecraft:granite', 'minecraft:tuff', 'minecraft:deepslate',
              'minecraft:blackstone', 'minecraft:calcite'],
    'metal': ['minecraft:iron_ingot', 'minecraft:copper_ingot', 'minecraft:raw_iron',
              'minecraft:raw_copper', 'minecraft:gold_ingot', 'minecraft:raw_gold',
              'minecraft:iron_nugget', 'minecraft:gold_nugget'],
    'gem': ['minecraft:diamond', 'minecraft:emerald', 'minecraft:amethyst_shard',
            'minecraft:lapis_lazuli', 'minecraft:redstone'],
    'fish': ['minecraft:cod', 'minecraft:salmon', 'minecraft:tropical_fish', 'minecraft:pufferfish',
             'minecraft:cooked_cod', 'minecraft:cooked_salmon', 'minecraft:kelp'],
    'frost': ['minecraft:ice', 'minecraft:packed_ice', 'minecraft:blue_ice', 'minecraft:snowball',
              'minecraft:snow_block', opt('minecraft:powder_snow_bucket'), 'fnfbonds:frost_vial'],
    'chitin': ['fnfbonds:chitin', 'fnfbonds:chitin_plate', opt('minecraft:turtle_scute'), opt('friendsandfoes:crab_claw'),
               opt('friendsandfoes:barnacle_tooth')],
    'nether': ['minecraft:quartz', 'minecraft:nether_wart', 'minecraft:glowstone_dust',
               'minecraft:blaze_rod', 'minecraft:magma_cream', 'minecraft:nether_bricks',
               'minecraft:soul_sand'],
}
for name, values in COMMODITIES.items():
    w(D / f'tags/item/commodity/{name}.json', {"replace": False, "values": values})

w(D / 'tags/item/donations.json', {"replace": False, "values": [
    'minecraft:emerald', 'minecraft:emerald_block', 'fnfbonds:wax_seal', 'fnfbonds:beeswax',
    'minecraft:honeycomb', 'minecraft:bread', opt('friendsandfoes:buttercup')]})
w(D / 'tags/item/press_inputs.json', {"replace": False, "values": [
    'minecraft:honeycomb', 'minecraft:honey_bottle', 'minecraft:red_dye', 'minecraft:wheat',
    'fnfbonds:beeswax', 'fnfbonds:chitin', opt('friendsandfoes:crab_claw'),
    opt('friendsandfoes:barnacle_tooth')]})
w(D / 'tags/block/light_sources.json', {"replace": False, "values": [
    'minecraft:torch', 'minecraft:soul_torch', 'minecraft:redstone_torch', 'minecraft:wall_torch',
    'minecraft:soul_wall_torch', 'minecraft:lantern', 'minecraft:soul_lantern',
    'minecraft:glowstone', 'minecraft:sea_lantern', 'minecraft:campfire',
    'minecraft:soul_campfire', 'minecraft:shroomlight', 'minecraft:ochre_froglight',
    'minecraft:verdant_froglight', 'minecraft:pearlescent_froglight', 'minecraft:copper_bulb',
    'minecraft:jack_o_lantern', 'minecraft:beacon', 'minecraft:end_rod']})

w(D / 'tags/entity_type/friendly_mobs.json', {"replace": False, "values": [
    'minecraft:cow', 'minecraft:sheep', 'minecraft:pig', 'minecraft:chicken', 'minecraft:rabbit',
    'minecraft:bee', 'minecraft:cat', 'minecraft:wolf', 'minecraft:fox', 'minecraft:goat',
    'minecraft:horse', 'minecraft:donkey', 'minecraft:mule', 'minecraft:llama',
    'minecraft:axolotl', 'minecraft:allay', 'minecraft:camel', 'minecraft:frog',
    'minecraft:sniffer', 'minecraft:armadillo', 'minecraft:villager', 'minecraft:iron_golem',
    'minecraft:snow_golem', 'minecraft:wandering_trader',
    opt('friendsandfoes:moobloom'), opt('friendsandfoes:crab'), opt('friendsandfoes:penguin'),
    opt('friendsandfoes:barnacle'), opt('friendsandfoes:tuff_golem'), opt('friendsandfoes:glare'),
    opt('friendsandfoes:mauler')]})
w(D / 'tags/entity_type/hostile_mobs.json', {"replace": False, "values": [
    'minecraft:zombie', 'minecraft:husk', 'minecraft:drowned', 'minecraft:skeleton',
    'minecraft:stray', 'minecraft:bogged', 'minecraft:creeper', 'minecraft:spider',
    'minecraft:cave_spider', 'minecraft:witch', 'minecraft:pillager', 'minecraft:vindicator',
    'minecraft:evoker', 'minecraft:ravager', 'minecraft:phantom', 'minecraft:slime',
    'minecraft:magma_cube', 'minecraft:enderman', 'minecraft:silverfish', 'minecraft:breeze',
    opt('friendsandfoes:iceologer'), opt('friendsandfoes:illusioner'), opt('friendsandfoes:mauler'),
    opt('friendsandfoes:wildfire'), opt('friendsandfoes:ice_chunk'),
    opt('friendsandfoes:player_illusion')]})
w(D / 'tags/entity_type/grudge_mobs.json', {"replace": False, "values": [
    'minecraft:villager', 'minecraft:iron_golem', 'minecraft:wandering_trader', 'minecraft:cat',
    'minecraft:wolf', 'minecraft:allay', 'minecraft:axolotl',
    opt('friendsandfoes:moobloom'), opt('friendsandfoes:tuff_golem'), opt('friendsandfoes:crab'),
    opt('friendsandfoes:penguin'), opt('friendsandfoes:barnacle'), opt('friendsandfoes:glare')]})
w(D / 'tags/entity_type/livestock_mobs.json', {"replace": False, "values": [
    'minecraft:cow', 'minecraft:sheep', 'minecraft:pig', 'minecraft:chicken', 'minecraft:rabbit',
    'minecraft:goat', 'minecraft:bee', 'minecraft:horse', 'minecraft:donkey', 'minecraft:llama',
    'minecraft:camel', 'minecraft:sniffer', 'minecraft:armadillo',
    opt('friendsandfoes:moobloom'), opt('friendsandfoes:crab'), opt('friendsandfoes:penguin')]})

# --------------------------------------------------------------------- recipes
def shaped(name, pattern, key, result, count=1, category='misc'):
    """26.x ingredients are plain ids / #tags (HolderSet codec), not {"item": ...} objects."""
    return (name, {"type": "minecraft:crafting_shaped", "category": category, "pattern": pattern,
                   "key": key, "result": {"id": f'fnfbonds:{result}', "count": count}})


def shapeless(name, ingredients, result, count=1, category='misc'):
    return (name, {"type": "minecraft:crafting_shapeless", "category": category,
                   "ingredients": ingredients, "result": {"id": f'fnfbonds:{result}', "count": count}})


RECIPES = [
    shaped('ledger_desk', ['BBB', 'P P', 'P P'],
           {'B': 'minecraft:book', 'P': '#minecraft:planks'}, 'ledger_desk', 1, 'misc'),
    shaped('contract_board', ['PPP', 'SRS', 'P P'],
           {'P': '#minecraft:planks', 'S': 'minecraft:paper', 'R': 'minecraft:stick'},
           'contract_board', 1, 'misc'),
    shaped('trade_post', [' E ', 'PSP', ' S '],
           {'E': 'minecraft:emerald', 'P': '#minecraft:planks', 'S': 'minecraft:stick'},
           'trade_post', 1, 'misc'),
    shaped('wax_press', ['III', 'HIH', 'PPP'],
           {'I': 'minecraft:iron_ingot', 'H': 'minecraft:honeycomb', 'P': '#minecraft:planks'},
           'wax_press', 1, 'misc'),
    shaped('cold_cellar', ['PIP', 'SBS', 'PPP'],
           {'P': '#minecraft:planks', 'I': 'minecraft:packed_ice', 'S': 'minecraft:snowball',
            'B': 'minecraft:barrel'}, 'cold_cellar', 1, 'misc'),
    shaped('beeswax_block', ['WWW', 'WWW', 'WWW'], {'W': 'fnfbonds:beeswax'},
           'beeswax_block', 1, 'building'),
    shapeless('beeswax_from_beeswax_block', ['fnfbonds:beeswax_block'], 'beeswax', 9),
    shapeless('wax_seal', ['fnfbonds:beeswax', 'fnfbonds:beeswax', 'minecraft:red_dye'],
              'wax_seal', 4),
    shaped('chitin_plate', ['CC', 'CC'], {'C': 'fnfbonds:chitin'}, 'chitin_plate', 1, 'misc'),
    shapeless('ledger_book', ['minecraft:book', 'fnfbonds:beeswax', 'minecraft:emerald'],
              'ledger_book', 1),
    shapeless('mead', ['minecraft:honey_bottle', 'minecraft:wheat'], 'mead', 1),
    shapeless('frost_vial', ['minecraft:glass_bottle', 'minecraft:packed_ice'], 'frost_vial', 1),
    shaped('route_map', ['PCP', 'BMB', 'PCP'],
           {'P': 'minecraft:paper', 'C': 'minecraft:compass', 'B': 'fnfbonds:beeswax',
            'M': 'minecraft:map'}, 'route_map', 1, 'equipment'),
    shaped('chitin_from_crab_claw', ['CC'], {'C': 'friendsandfoes:crab_claw'}, 'chitin', 2, 'misc'),
    shaped('chitin_from_barnacle_tooth', ['TT'], {'T': 'friendsandfoes:barnacle_tooth'},
           'chitin', 2, 'misc'),
    shapeless('beeswax_from_honeycomb',
              ['minecraft:honeycomb', 'minecraft:honeycomb', 'minecraft:honeycomb',
               'minecraft:campfire'], 'beeswax', 2),
    shaped('beeswax_block_from_honey_block', ['HH', 'HH'],
           {'H': 'minecraft:honey_block'}, 'beeswax_block', 2, 'building'),
]
for name, body in RECIPES:
    w(D / f'recipe/{name}.json', body)

# ------------------------------------------------------------- villager trades
TRADES = {
    1: [('beeswax_emerald', {"wants": {"id": 'fnfbonds:beeswax', "count": 12.0},
                             "gives": {"id": 'minecraft:emerald', "count": 1},
                             "max_uses": 16.0, "xp": 3.0, "reputation_discount": 0.05}),
        ('wax_seal_emerald', {"wants": {"id": 'minecraft:emerald', "count": 2.0},
                              "gives": {"id": 'fnfbonds:wax_seal', "count": 2},
                              "max_uses": 8.0, "xp": 4.0, "reputation_discount": 0.05})],
    2: [('chitin_emerald', {"wants": {"id": 'fnfbonds:chitin', "count": 10.0},
                            "gives": {"id": 'minecraft:emerald', "count": 2},
                            "max_uses": 12.0, "xp": 8.0, "reputation_discount": 0.05}),
        ('emerald_mead', {"wants": {"id": 'minecraft:emerald', "count": 3.0},
                          "gives": {"id": 'fnfbonds:mead', "count": 1},
                          "max_uses": 8.0, "xp": 6.0, "reputation_discount": 0.05})],
    3: [('emerald_ledger_book', {"wants": {"id": 'minecraft:emerald', "count": 14.0},
                                 "gives": {"id": 'fnfbonds:ledger_book', "count": 1},
                                 "max_uses": 3.0, "xp": 20.0, "reputation_discount": 0.05}),
        ('frost_vial_emerald', {"wants": {"id": 'fnfbonds:frost_vial', "count": 6.0},
                                "gives": {"id": 'minecraft:emerald', "count": 3},
                                "max_uses": 8.0, "xp": 14.0, "reputation_discount": 0.05})],
    4: [('chitin_plate_emerald', {"wants": {"id": 'fnfbonds:chitin_plate', "count": 12.0},
                                  "gives": {"id": 'minecraft:emerald', "count": 8},
                                  "max_uses": 6.0, "xp": 25.0, "reputation_discount": 0.05}),
        ('emerald_contract_board', {"wants": {"id": 'minecraft:emerald', "count": 18.0},
                                    "gives": {"id": 'fnfbonds:contract_board', "count": 1},
                                    "max_uses": 3.0, "xp": 30.0, "reputation_discount": 0.05})],
}
for level, entries in TRADES.items():
    values = []
    for name, body in entries:
        w(ROOT / f'data/fnfbonds/villager_trade/beekeeper/{level}/{name}.json', body)
        values.append(f'fnfbonds:beekeeper/{level}/{name}')
    # merged into the Friends&Foes tag id on purpose: that is how a datapack/addon extends a trade pool
    w(FNF_TAGS / f'level_{level}.json', {"replace": False, "values": values})

# ------------------------------------------------------------------------ lang
EN = {}
RU = {}


def L(key, en, ru):
    EN[key] = en
    RU[key] = ru


L('itemGroup.fnfbonds', 'Bonds & Ledger', 'Узы и Учёт')
for b, en, ru in [
    ('ledger_desk', 'Ledger Desk', 'Стол учёта'),
    ('contract_board', 'Contract Board', 'Доска контрактов'),
    ('trade_post', 'Trade Post', 'Торговый столб'),
    ('wax_press', 'Wax Press', 'Воскопресс'),
    ('cold_cellar', 'Cold Cellar', 'Холодный погреб'),
    ('beeswax_block', 'Block of Beeswax', 'Блок пчелиного воска')]:
    L(f'block.fnfbonds.{b}', en, ru)
for i, en, ru in [
    ('beeswax', 'Beeswax', 'Пчелиный воск'),
    ('chitin', 'Chitin', 'Хитин'),
    ('chitin_plate', 'Chitin Plate', 'Хитиновая пластина'),
    ('frost_vial', 'Frost Vial', 'Флакон стужи'),
    ('wax_seal', 'Wax Seal', 'Восковая печать'),
    ('mead', 'Mead', 'Медовуха'),
    ('ledger_book', 'Ledger Book', 'Книга учёта'),
    ('route_map', 'Route Map', 'Дорожная карта')]:
    L(f'item.fnfbonds.{i}', en, ru)

L('screen.fnfbonds.ledger', 'Ledger', 'Книга учёта')
L('screen.fnfbonds.ledger.title', 'Ledger of %s', 'Учётная книга: %s')
for t, en, ru in [('overview', 'Overview', 'Обзор'), ('contracts', 'Contracts', 'Контракты'),
                  ('market', 'Market', 'Рынок'), ('caravans', 'Caravans', 'Караваны'),
                  ('projects', 'Projects', 'Проекты')]:
    L(f'tab.fnfbonds.{t}', en, ru)
for b, en, ru in [
    ('accept', 'Accept', 'Принять'), ('turn_in', 'Turn in', 'Сдать'), ('abandon', 'Abandon', 'Отказ'),
    ('reroll', 'Reroll', 'Обновить'), ('sell', 'Sell', 'Продать'), ('buy', 'Buy', 'Купить'),
    ('dispatch', 'Dispatch', 'Отправить'), ('collect', 'Collect', 'Забрать'),
    ('cycle_commodity', 'Cargo…', 'Груз…'), ('build', 'Build', 'Построить'),
    ('donate', 'Donate 16', 'Пожертвовать 16'), ('credit', 'Borrow 32', 'Занять 32'),
    ('repay', 'Repay 32', 'Вернуть 32'), ('loot', 'Lost loot', 'Утраченное')]:
    L(f'button.fnfbonds.{b}', en, ru)
for k, en, ru in [
    ('tier', 'Bond', 'Узы'), ('standing', 'Standing', 'Репутация'),
    ('contribution', 'Contribution', 'Вклад'), ('emeralds', 'Emeralds', 'Изумруды'),
    ('seals', 'Wax seals', 'Печати'), ('bank', 'Bank', 'Казна'), ('credit', 'Debt', 'Долг'),
    ('threat', 'Threat', 'Угроза'), ('day', 'Day', 'День'), ('radius', 'Radius', 'Радиус'),
    ('contracts_done', 'Contracts done', 'Контрактов сдано'),
    ('contracts_failed', 'Contracts failed', 'Контрактов провалено'),
    ('caravans_done', 'Caravans delivered', 'Караванов доставлено'), ('streak', 'Streak', 'Серия'),
    ('reward', '%s em / %s bond', '%s из. / %s уз'), ('tier_req', 'tier %s', 'уровень %s'),
    ('contract_slots', 'Slots: %s', 'Слотов: %s'), ('amount', 'Amount', 'Количество'),
    ('have', 'have %s', 'есть %s'), ('arrived', 'Arrived', 'Прибыл'), ('eta', 'ETA %ss', 'Ещё %s с'),
    ('raided', 'Raided %s/%s', 'Нападение %s/%s'), ('cargo', 'Cargo: %s', 'Груз: %s'),
    ('caravan_slots', 'Caravans: %s/%s', 'Караваны: %s/%s'), ('cost', '%s contribution + %s em',
                                                              '%s вклада + %s из.'),
    ('built', 'Built', 'Построено')]:
    L(f'label.fnfbonds.{k}', en, ru)
for k, en, ru in [
    ('no_desk', 'Place a ledger desk to found this settlement', 'Поставьте стол учёта, чтобы основать поселение'),
    ('loot', 'Lost loot waiting: %s', 'Ждёт утраченный груз: %s'),
    ('no_contracts', 'The board is empty. It refills at dawn.', 'Доска пуста. Обновится на рассвете.'),
    ('no_caravans', 'No caravans on the road.', 'В пути нет караванов.'),
    ('no_routes', 'No other settlement knows this one yet.', 'Другие поселения ещё не связаны.'),
    ('projects', 'Projects are shared by the whole settlement and paid with contribution.',
     'Проекты общие и оплачиваются вкладом.')]:
    L(f'hint.fnfbonds.{k}', en, ru)
for k, en, ru in [('calm', 'calm', 'спокойно'), ('wary', 'wary', 'настороже'),
                  ('tense', 'tense', 'напряжённо'), ('besieged', 'besieged', 'осада')]:
    L(f'threat.fnfbonds.{k}', en, ru)
for k, en, ru in [('settlement', '%s', '%s'), ('contribution', 'contribution %s', 'вклад %s'),
                  ('seals', 'seals %s', 'печати %s'), ('contracts', 'contracts %s/%s', 'контракты %s/%s')]:
    L(f'hud.fnfbonds.{k}', en, ru)
for k, en, ru in [('outcast', 'Outcast', 'Изгой'), ('stranger', 'Stranger', 'Чужак'),
                  ('neighbor', 'Neighbor', 'Сосед'), ('trusted', 'Trusted', 'Доверенный'),
                  ('elder', 'Elder', 'Старейшина'), ('patron', 'Patron', 'Покровитель')]:
    L(f'standing.fnfbonds.{k}', en, ru)
for k, en, ru in [('apiary', 'Settlement Apiary', 'Поселковая пасека'),
                  ('warehouse', 'Warehouse', 'Склад'), ('watchtower', 'Watchtower', 'Дозорная башня'),
                  ('market_square', 'Market Square', 'Торговая площадь'), ('cellar', 'Deep Cellar', 'Глубокий погреб'),
                  ('chitin_works', 'Chitin Works', 'Хитиновая мастерская'),
                  ('museum', 'Curiosity Museum', 'Музей диковин'),
                  ('seal_works', 'Seal Works', 'Печатная мастерская'),
                  ('embassy', 'Embassy', 'Посольство')]:
    L(f'project.fnfbonds.{k}', en, ru)
for k, en, ru in [('grain', 'Grain', 'Зерно'), ('produce', 'Produce', 'Овощи и фрукты'),
                  ('honey', 'Honey & Wax', 'Мёд и воск'), ('livestock', 'Livestock', 'Скот'),
                  ('timber', 'Timber', 'Лес'), ('stone', 'Stone', 'Камень'), ('metal', 'Metal', 'Металл'),
                  ('gem', 'Gems', 'Самоцветы'), ('fish', 'Fish', 'Рыба'), ('frost', 'Frost', 'Стужа'),
                  ('chitin', 'Chitin', 'Хитин'), ('nether', 'Nether Goods', 'Адские товары')]:
    L(f'commodity.fnfbonds.{k}', en, ru)
for k, en, ru in [('delivery', 'Delivery', 'Поставка'), ('hunt', 'Hunt', 'Охота'),
                  ('herd', 'Herd', 'Стадо'), ('apiary', 'Apiary Work', 'Пасечные работы'),
                  ('build', 'Construction', 'Стройка'), ('light', 'Lighting', 'Освещение'),
                  ('escort', 'Escort', 'Эскорт'), ('cleanse', 'Cleanse', 'Зачистка')]:
    L(f'contract.fnfbonds.{k}', en, ru)
    L(f'contract.fnfbonds.{k}.goal', en + ' goal', 'Цель: ' + ru.lower())
for k, en, ru in [
    ('settlement.founded', 'Settlement founded: %s (radius %s)', 'Основано поселение: %s (радиус %s)'),
    ('settlement.joined', 'You joined the settlement of %s', 'Вы присоединились к поселению %s'),
    ('settlement.removed', 'Settlement %s dissolved', 'Поселение %s расформировано'),
    ('settlement.renamed', 'Settlement renamed to %s', 'Поселение переименовано в %s'),
    ('settlement.income', '%s earned %s em from its residents', '%s заработало %s из. на жителях'),
    ('contract.accepted', 'Contract accepted: %s', 'Контракт принят: %s'),
    ('contract.done', 'Contract complete! +%s standing', 'Контракт выполнен! +%s репутации'),
    ('contract.expired', 'Contract expired: %s', 'Срок контракта истёк: %s'),
    ('contract.abandoned', 'Contract abandoned. The settlement remembers.',
     'Контракт брошен. Поселение это запомнит.'),
    ('contract.progress', '%s: %s/%s', '%s: %s/%s'),
    ('contract.rerolled', 'The board was refreshed for %s wax seals', 'Доска обновлена за %s печатей'),
    ('contracts.rolled', 'New contracts posted', 'Выставлены новые контракты'),
    ('market.sold', 'Sold %s × %s for %s em', 'Продано %s × %s за %s из.'),
    ('market.bought', 'Bought %s × %s for %s em', 'Куплено %s × %s за %s из.'),
    ('caravan.sent', 'Caravan to %s departs with %s × %s', 'Караван в %s отправился: %s × %s'),
    ('caravan.arrived', 'A caravan from %s arrived', 'Прибыл караван из %s'),
    ('caravan.collected', 'Caravan delivered: %s em', 'Караван доставлен: %s из.'),
    ('caravan.raided', 'Your caravan was ambushed! Escort it: %s/%s',
     'На караван напали! Отбейте атаку: %s/%s'),
    ('caravan.saved', 'You saved the caravan. The cargo is intact.', 'Караван отбит. Груз цел.'),
    ('caravan.lost', 'The caravan was lost. Some cargo may be recovered.',
     'Караван потерян. Часть груза можно вернуть.'),
    ('project.built', '%s built: %s', '%s возвёл: %s'),
    ('project.announcement', 'The settlement finished %s!', 'Поселение достроило: %s!'),
    ('donate.done', 'You donated to the settlement. +%s standing', 'Вы пожертвовали поселению. +%s репутации'),
    ('credit.taken', 'You borrowed %s em from the settlement treasury', 'Вы заняли %s из. из казны'),
    ('credit.repaid', 'You repaid %s em', 'Вы вернули %s из.'),
    ('loot.claimed', 'Recovered cargo from the lost caravan', 'Груз утраченного каравана возвращён'),
    ('grudge', 'The settlement saw you kill one of its own. Standing lost.',
     'Поселение видело, как вы убили его жителя. Репутация упала.'),
    ('mead.shared', 'You shared mead with a villager', 'Вы угостили жителя медовухой'),
    ('herd.credit', '%s now feels at home here', '%s теперь чувствует себя здесь как дома'),
    ('standing.changed', '%s: standing %+s (now %s)', '%s: репутация %+s (теперь %s)'),
    ('threat.set', 'Threat set to %s (%s)', 'Угроза: %s (%s)'),
    ('tick.forced', 'Forced a daily settlement tick', 'Суточный ход поселений выполнен принудительно')]:
    L(f'chat.fnfbonds.{k}', en, ru)
for k, en, ru in [
    ('error.not_in_settlement', 'You are not inside a settlement', 'Вы вне поселения'),
    ('error.no_settlement', 'No settlement here — place a ledger desk first',
     'Здесь нет поселения — сначала поставьте стол учёта'),
    ('error.no_settlement_near', 'No settlement within %s blocks', 'В радиусе %s блоков нет поселения'),
    ('error.no_desk', 'This settlement has no ledger desk', 'У поселения нет стола учёта'),
    ('error.cannot_found', 'Too close to another settlement', 'Слишком близко к другому поселению'),
    ('error.far', 'You are too far from the settlement centre', 'Вы слишком далеко от центра поселения'),
    ('error.taken', 'That contract is already taken', 'Контракт уже взят'),
    ('error.tier', 'Your bond is too low for this contract', 'Ваших уз не хватает для контракта'),
    ('error.seals', 'Not enough wax seals', 'Недостаточно восковых печатей'),
    ('error.poor', 'Not enough emeralds', 'Недостаточно изумрудов'),
    ('error.not_enough', 'Not enough goods', 'Недостаточно товаров'),
    ('error.no_unit', 'You carry none of that commodity', 'У вас нет такого товара'),
    ('error.nothing_to_sell', 'Nothing to sell', 'Нечего продавать'),
    ('error.nothing_to_send', 'Nothing to send: %s', 'Нечего отправлять: %s'),
    ('error.no_route', 'No route to that settlement', 'Маршрута к этому поселению нет'),
    ('error.caravan_slots', 'Caravan limit reached (%s)', 'Достигнут предел караванов (%s)'),
    ('error.caravan_traveling', 'That caravan is still on the road', 'Караван ещё в пути'),
    ('error.caravan_raided', 'The caravan is under attack — defend it first',
     'Караван атакуют — сначала отбейте нападение'),
    ('error.contract_slots', 'Contract limit reached (%s)', 'Достигнут предел контрактов (%s)'),
    ('error.contribution', 'Not enough contribution', 'Недостаточно вклада'),
    ('error.credit_limit', 'Credit limit reached', 'Предел займа достигнут'),
    ('error.donate_limit', 'Daily donation limit reached', 'Дневной предел пожертвований'),
    ('error.built', 'Already built', 'Уже построено'),
    ('error.need_trusted', 'Only Trusted bonds and above may build', 'Строить могут только Доверенные и выше'),
    ('error.outcast', 'Outcasts are not welcome at the desk', 'Изгоям стол учёта недоступен'),
    ('error.mead_cooldown', 'You already shared mead today', 'Сегодня вы уже угощали медовухой'),
    ('error.no_loot', 'There is no lost cargo to claim', 'Возвращать нечего')]:
    L(f'chat.fnfbonds.{k}', en, ru)
L('chat.fnfbonds.missing.dep', 'Bonds & Ledger needs %s', 'Узы и Учёт требуют %s')

w(A / 'lang/en_us.json', EN)
w(A / 'lang/ru_ru.json', RU)
print('lang keys:', len(EN))
print('files written under', ROOT)
