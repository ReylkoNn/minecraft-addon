import pathlib
from PIL import Image, ImageDraw, ImageFont
NN32 = pathlib.Path('texnn32')
NN16 = pathlib.Path('texnn')
OUT = NN32 / 'final_items32.png'
try:
    F = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 15)
    T = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 20)
except OSError:
    F = T = ImageFont.load_default()
ITEMS = ['beeswax','chitin','chitin_plate','frost_vial','wax_seal','mead','ledger_book','route_map']

def slot(d, x, y, s):
    d.rectangle([x, y, x+s-1, y+s-1], fill=(139,139,139,255))
    d.line([x,y,x+s-1,y], fill=(55,55,55,255)); d.line([x,y,x,y+s-1], fill=(55,55,55,255))
    d.line([x,y+s-1,x+s-1,y+s-1], fill=(255,255,255,255)); d.line([x+s-1,y,x+s-1,y+s-1], fill=(255,255,255,255))

W = 8*(128+22)+40
H = 56 + (128+44) + (64+26) + (32+26) + (64+40)
sheet = Image.new('RGBA',(W,H),(38,38,42,255))
d = ImageDraw.Draw(sheet)
d.text((30,12),'fnfbonds items — 32x32 grid-snap, aspect preserved', fill=(235,225,200,255), font=T)
y=56
d.text((30,y-20),'x4 on inventory slot', fill=(160,160,170,255), font=F)
for i,n in enumerate(ITEMS):
    x=30+i*(128+22); slot(d,x,y,128)
    s=Image.open(NN32/f'item_{n}.png').resize((128,128), Image.NEAREST)
    sheet.paste(s,(x,y),s); d.text((x+2,y+134),n,fill=(210,210,215,255),font=F)
y+=128+44
d.text((30,y-20),'x2 — GUI scale 2 (1080p)', fill=(160,160,170,255), font=F)
for i,n in enumerate(ITEMS):
    x=30+i*(128+22)
    s=Image.open(NN32/f'item_{n}.png').resize((64,64), Image.NEAREST)
    sheet.paste(s,(x,y),s)
y+=64+26
d.text((30,y-20),'x1 — true 32x32 canvas', fill=(160,160,170,255), font=F)
for i,n in enumerate(ITEMS):
    x=30+i*(128+22)
    s=Image.open(NN32/f'item_{n}.png')
    sheet.paste(s,(x,y),s)
y+=32+26
d.text((30,y-20),'source photo crop (left) vs 32x32 result (right), x4', fill=(160,160,170,255), font=F)
import statistics
def src_crop(n):
    p = sorted(pathlib.Path('texsrc').glob(f'item_{n}.*'))[0]
    img = Image.open(p).convert('RGBA'); w,h = img.size; px = img.load(); bg = px[0,0]
    for yy in range(h):
        for xx in range(w):
            r,g,b,a = px[xx,yy]
            if abs(r-bg[0])<90 and abs(g-bg[1])<90 and abs(b-bg[2])<90:
                px[xx,yy]=(r,g,b,0)
    return img.crop(img.getbbox())
for i,n in enumerate(ITEMS):
    x=30+i*(128+22)
    c = src_crop(n); cw,ch = c.size; k = 64/max(cw,ch)
    c2 = c.resize((max(1,round(cw*k)), max(1,round(ch*k))), Image.BOX)
    sheet.paste(c2,(x,y),c2)
    b=Image.open(NN32/f'item_{n}.png').resize((64,64), Image.NEAREST)
    sheet.paste(b,(x+62,y),b)
sheet.save(OUT)
print('sheet', OUT, sheet.size)
