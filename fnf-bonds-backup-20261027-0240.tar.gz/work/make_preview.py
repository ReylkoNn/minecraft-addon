#!/usr/bin/env python3
"""Look-dev sheet for the fnfbonds texture pass: items on inventory slots,
blocks as 2:1 isometric cubes assembled from their top/side faces."""
import pathlib

from PIL import Image, ImageDraw, ImageFont

TEX = pathlib.Path('/home/user/work/texhq')
OUT = TEX / 'preview.png'

S = 8          # item zoom
A, B, FH = 4, 2, 4   # iso cube steps

try:
    FONT = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 15)
    TITLE = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 20)
except OSError:
    FONT = TITLE = ImageFont.load_default()

ITEMS = ['beeswax', 'chitin', 'chitin_plate', 'frost_vial', 'wax_seal', 'mead',
         'ledger_book', 'route_map']
BLOCKS = ['ledger_desk', 'wax_press', 'cold_cellar', 'contract_board', 'trade_post',
          'beeswax_block']


def shade(color, factor):
    r, g, b, a = color
    return (min(255, int(r * factor)), min(255, int(g * factor)),
            min(255, int(b * factor)), a)


def slot(draw, x, y, size):
    draw.rectangle([x, y, x + size - 1, y + size - 1], fill=(139, 139, 139, 255))
    draw.line([x, y, x + size - 1, y], fill=(55, 55, 55, 255))
    draw.line([x, y, x, y + size - 1], fill=(55, 55, 55, 255))
    draw.line([x, y + size - 1, x + size - 1, y + size - 1], fill=(255, 255, 255, 255))
    draw.line([x + size - 1, y, x + size - 1, y + size - 1], fill=(255, 255, 255, 255))


def iso_cube(canvas, top, side, ox, oy):
    draw = ImageDraw.Draw(canvas)
    tp, sp = top.load(), side.load()
    cx, ty = ox + 16 * A, oy

    def P(u, v):
        return (cx + (u - v) * A, ty + (u + v) * B)

    for u in range(16):
        for v in range(16):
            c = tp[u, v]
            if c[3]:
                draw.polygon([P(u, v), P(u + 1, v), P(u + 1, v + 1), P(u, v + 1)], fill=c)
    for u in range(16):
        for w in range(16):
            x0, y0 = P(u, 16)
            x1, y1 = P(u + 1, 16)
            c = sp[u, w]
            if c[3]:
                draw.polygon([(x0, y0 + w * FH), (x1, y1 + w * FH),
                              (x1, y1 + (w + 1) * FH), (x0, y0 + (w + 1) * FH)],
                             fill=shade(c, 0.85))
    for v in range(16):
        for w in range(16):
            x0, y0 = P(16, v)
            x1, y1 = P(16, v + 1)
            c = sp[15 - v, w]
            if c[3]:
                draw.polygon([(x0, y0 + w * FH), (x1, y1 + w * FH),
                              (x1, y1 + (w + 1) * FH), (x0, y0 + (w + 1) * FH)],
                             fill=shade(c, 0.62))


def main():
    cell, gap = 128, 22
    width = 8 * (cell + gap) + 60
    height = 46 + (cell + 34) + 40 + (128 + 64 + 34) + 30
    sheet = Image.new('RGBA', (width, height), (38, 38, 42, 255))
    draw = ImageDraw.Draw(sheet)
    draw.text((30, 12), 'Friends&Foes: Bonds & Ledger — texture pass (16x16, vanilla atlas cost)',
              fill=(235, 225, 200, 255), font=TITLE)

    y = 46
    draw.text((30, y - 4), 'items', fill=(160, 160, 170, 255), font=FONT)
    y += 18
    for i, name in enumerate(ITEMS):
        x = 30 + i * (cell + gap)
        slot(draw, x, y, cell)
        sprite = Image.open(TEX / f'item_{name}.png').resize((cell, cell), Image.NEAREST)
        sheet.paste(sprite, (x, y), sprite)
        draw.text((x + 4, y + cell + 6), name, fill=(210, 210, 215, 255), font=FONT)

    y += cell + 40
    draw.text((30, y - 6), 'blocks (isometric preview from top+side faces)',
              fill=(160, 160, 170, 255), font=FONT)
    y += 12
    for i, name in enumerate(BLOCKS):
        x = 30 + i * (cell + gap + 20)
        top = Image.open(TEX / f'block_{name}_top.png')
        side = Image.open(TEX / f'block_{name}_side.png')
        iso_cube(sheet, top, side, x, y)
        draw.text((x + 30, y + 128 + 8), name, fill=(210, 210, 215, 255), font=FONT)

    sheet.save(OUT)
    print('preview:', OUT, sheet.size)


if __name__ == '__main__':
    main()
