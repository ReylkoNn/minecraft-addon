#!/usr/bin/env python3
"""Split the preProcessJar outer-class list into batches for vineflower -only runs."""
import zipfile, json, os

SRC = '/home/user/.cache/gradle/caches/neoformruntime/intermediate_results/preProcessJar_dad447fdce426e4e05a84a2eff47da4c9f24f251_output.jar'
OUT = '/home/user/work/vf/batches.json'
BATCH = 1100

zj = zipfile.ZipFile(SRC)
outer = sorted({n[:-6].split('$')[0] for n in zj.namelist() if n.endswith('.class')})
# dedupe: outer names are without .class already (stripped 6 chars)
batches = [outer[i:i + BATCH] for i in range(0, len(outer), BATCH)]
os.makedirs('/home/user/work/vf', exist_ok=True)
with open(OUT, 'w') as f:
    json.dump(batches, f)
print('outer classes:', len(outer))
for i, b in enumerate(batches):
    print(f'batch {i:02d}: {len(b):5d}  {b[0]} .. {b[-1]}')
