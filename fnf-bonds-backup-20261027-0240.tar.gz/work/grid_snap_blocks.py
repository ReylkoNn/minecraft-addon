#!/usr/bin/env python3
"""Block faces: full-frame 32x32 median grid (no crop, fully opaque).
Two mechanical completions, disclosed:
  wax_press_side   - near-white void cells (net left background windows) filled with
                     the median dark-wood colour of the same texture;
  contract_board_top - not generated: assembled from the plank bands of the user's own
                     contract_board_side (no new art invented).
"""
import pathlib
import statistics

from PIL import Image

SRC = pathlib.Path('/home/user/work/texsrc_blocks')
OUT = pathlib.Path('/home/user/work/texnn32')

FACES = [
    ('ledger_desk', 'top'), ('ledger_desk', 'side'),
    ('wax_press', 'top'), ('wax_press', 'side'),
    ('cold_cellar', 'top'), ('cold_cellar', 'side'),
    ('contract_board', 'side'),
    ('trade_post', 'top'), ('trade_post', 'side'),
    ('beeswax_block', 'side'),
]


def full32(path):
    img = Image.open(path).convert('RGB')
    w, h = img.size
    px = img.load()
    grid = Image.new('RGBA', (32, 32), (0, 0, 0, 255))
    gp = grid.load()
    for j in range(32):
        y0, y1 = j * h // 32, max(j * h // 32 + 1, (j + 1) * h // 32)
        for i in range(32):
            x0, x1 = i * w // 32, max(i * w // 32 + 1, (i + 1) * w // 32)
            rs = gs = bs = n = 0
            for y in range(y0, y1):
                for x in range(x0, x1):
                    r, g, b = px[x, y]
                    rs += r
                    gs += g
                    bs += b
                    n += 1
            gp[i, j] = (rs // n, gs // n, bs // n, 255)
    return grid


def main():
    grids = {}
    for name, part in FACES:
        cands = sorted(SRC.glob(f'{name}_{part}.*'))
        g = full32(cands[0])
        grids[(name, part)] = g
        g.save(OUT / f'block_{name}_{part}.png')
        print(f'{name}_{part} <- {cands[0].name}')

    # wax_press_side: fill near-white voids with median dark wood of the same face
    g = grids[('wax_press', 'side')]
    px = g.load()
    woods = [px[x, y][:3] for y in range(32) for x in range(32)
             if px[x, y][0] > px[x, y][1] > px[x, y][2] and px[x, y][0] < 150]
    fill = (int(statistics.median(c[0] for c in woods)),
            int(statistics.median(c[1] for c in woods)),
            int(statistics.median(c[2] for c in woods)), 255)
    n = 0
    for y in range(32):
        for x in range(32):
            r, gg, b, a = px[x, y]
            if min(r, gg, b) > 225:
                px[x, y] = fill
                n += 1
    g.save(OUT / 'block_wax_press_side.png')
    print('wax_press_side: void cells filled with', fill, 'count', n)

    # contract_board_top: plank bands reused from the user's side face
    side = grids[('contract_board', 'side')]
    sp = side.load()
    top = Image.new('RGBA', (32, 32), (0, 0, 0, 255))
    tp = top.load()
    bands = [range(0, 8), range(24, 32), range(0, 8), range(24, 32)]
    for bi, band in enumerate(bands):
        for k, sy in enumerate(band):
            y = bi * 8 + k
            for x in range(32):
                tp[x, y] = sp[x, sy]
    top.save(OUT / 'block_contract_board_top.png')
    print('contract_board_top assembled from side plank bands')

    # beeswax block: one face for top as well
    Image.open(OUT / 'block_beeswax_block_side.png').save(OUT / 'block_beeswax_block_top.png')
    print('beeswax_block_top = side face')


if __name__ == '__main__':
    main()
