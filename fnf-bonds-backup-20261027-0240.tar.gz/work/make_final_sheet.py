#!/usr/bin/env python3
"""Final sheet: the 8 finished 16x16 item sprites at x8 (slot), x4, x2 and x1 (true size)."""
import pathlib

from PIL import Image, ImageDraw, ImageFont

NN = pathlib.Path('/home/user/work/texnn')
OUT = NN / 'final_items.png'

try:
    FONT = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 15)
    TITLE = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 20)
except OSError:
    FONT = TITLE = ImageFont.load_default()

ITEMS = ['beeswax', 'chitin', 'chitin_plate', 'frost_vial', 'wax_seal', 'mead',
         'ledger_book', 'route_map']


def slot(draw, x, y, size):
    draw.rectangle([x, y, x + size - 1, y + size - 1], fill=(139, 139, 139, 255))
    draw.line([x, y, x + size - 1, y], fill=(55, 55, 55, 255))
    draw.line([x, y, x, y + size - 1], fill=(55, 55, 55, 255))
    draw.line([x, y + size - 1, x + size - 1, y + size - 1], fill=(255, 255, 255, 255))
    draw.line([x + size - 1, y, x + size - 1, y + size - 1], fill=(255, 255, 255, 255))


def zoom_row(sheet, draw, y, zoom, label, slots=False):
    draw.text((30, y - 20), label, fill=(160, 160, 170, 255), font=FONT)
    cell = 16 * zoom
    for i, name in enumerate(ITEMS):
        x = 30 + i * (128 + 22)
        if slots:
            slot(draw, x, y, cell)
        sprite = Image.open(NN / f'item_{name}.png').resize((cell, cell), Image.NEAREST)
        sheet.paste(sprite, (x, y), sprite)
        if slots:
            draw.text((x + 2, y + cell + 6), name, fill=(210, 210, 215, 255), font=FONT)
    return cell


def main():
    width = 8 * (128 + 22) + 40
    height = 56 + (128 + 44) + (64 + 26) + (32 + 26) + (16 + 24) + 10
    sheet = Image.new('RGBA', (width, height), (38, 38, 42, 255))
    draw = ImageDraw.Draw(sheet)
    draw.text((30, 12), 'fnfbonds v0.1.0 — final item sprites, 16x16 RGBA',
              fill=(235, 225, 200, 255), font=TITLE)
    y = 56
    c = zoom_row(sheet, draw, y, 8, 'x8 on inventory slot', slots=True)
    y += c + 44
    c = zoom_row(sheet, draw, y, 4, 'x4')
    y += c + 26
    c = zoom_row(sheet, draw, y, 2, 'x2')
    y += c + 26
    c = zoom_row(sheet, draw, y, 1, 'x1 — true in-game size')
    sheet.save(OUT)
    print('final sheet:', OUT, sheet.size)


if __name__ == '__main__':
    main()
