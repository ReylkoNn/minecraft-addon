import pathlib
from PIL import Image, ImageDraw, ImageFont
NN = pathlib.Path('texnn32')
OUT = NN / 'preview_blocks32.png'
try:
    F = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 15)
    T = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 20)
except OSError:
    F = T = ImageFont.load_default()
BLOCKS = ['ledger_desk','wax_press','cold_cellar','contract_board','trade_post','beeswax_block']
A, B, FH = 2, 1, 2

def shade(c, f):
    return (min(255,int(c[0]*f)), min(255,int(c[1]*f)), min(255,int(c[2]*f)), 255)

def iso(canvas, top, side, ox, oy):
    d = ImageDraw.Draw(canvas)
    tp, sp = top.load(), side.load()
    cx, ty = ox + 32*A, oy
    def P(u,v): return (cx + (u-v)*A, ty + (u+v)*B)
    for u in range(32):
        for v in range(32):
            d.polygon([P(u,v),P(u+1,v),P(u+1,v+1),P(u,v+1)], fill=tp[u,v])
    for u in range(32):
        for w in range(32):
            x0,y0 = P(u,32); x1,y1 = P(u+1,32)
            d.polygon([(x0,y0+w*FH),(x1,y1+w*FH),(x1,y1+(w+1)*FH),(x0,y0+(w+1)*FH)], fill=shade(sp[u,w],0.85))
    for v in range(32):
        for w in range(32):
            x0,y0 = P(32,v); x1,y1 = P(32,v+1)
            d.polygon([(x0,y0+w*FH),(x1,y1+w*FH),(x1,y1+(w+1)*FH),(x0,y0+(w+1)*FH)], fill=shade(sp[31-v,w],0.62))

CW = 32*2*A  # 128 cube width
CH = 32*2*B + 32*FH  # 64+64
W = 6*(CW+30)+40
H = 56 + CH + 30 + 70 + 60
sheet = Image.new('RGBA',(W,H),(38,38,42,255))
d = ImageDraw.Draw(sheet)
d.text((30,12),'fnfbonds blocks — 32x32 faces from NN sources (iso preview)', fill=(235,225,200,255), font=T)
y = 56
for i,n in enumerate(BLOCKS):
    x = 30+i*(CW+30)
    top = Image.open(NN/f'block_{n}_top.png'); side = Image.open(NN/f'block_{n}_side.png')
    iso(sheet, top, side, x, y)
    d.text((x+30, y+CH+8), n, fill=(210,210,215,255), font=F)
    t2 = top.resize((64,64), Image.NEAREST); s2 = side.resize((64,64), Image.NEAREST)
    sheet.paste(t2,(x,y+CH+34),t2); sheet.paste(s2,(x+70,y+CH+34),s2)
d.text((30, y+CH+34+70), 'flat faces x2 under each cube: top | side', fill=(160,160,170,255), font=F)
sheet.save(OUT)
print('sheet', OUT, sheet.size)
