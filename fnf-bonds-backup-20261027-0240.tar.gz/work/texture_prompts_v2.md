# Промты v2 — жёсткий стиль pixel-art, каждый промт самодостаточен для копирования

Что изменилось по сравнению с v1: убран фотореализм. Каждый промт теперь **полностью
самодостаточен** (копируй весь блок целиком, ничего не дописывая), жёстко фиксирует:
стиль (16-bit pixel-art, сетка 16×16, nearest-апскейл), источник света (сверху-слева),
палитру в hex, раскладку элементов в текселях и запрет градиентов/AA/фотореализма.

Настройки прогона: квадрат 1:1 (512 или 1024), 2–4 кандидата на спрайт. Если у сети есть
пресеты стиля — выбирай «pixel art». Результаты клади в `work/texsrc/` под именами файлов
из заголовков (варианты — `_v2`, `_v3`): я нарежу их на точную сетку 16×16, почищу
тексели и соберу превью-лист.

---

## ПРЕДМЕТЫ

### item_beeswax.png
```
16-bit pixel art item sprite in the style of a classic Minecraft inventory icon: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; flat cel shading, light source top-left; a 1-texel dark outline around the silhouette; a single centered object occupying about 12 of 16 texels; the rest of the canvas is solid flat magenta #FF00FF chroma-key background; no text, no watermark, no photorealism, no 3D render. Subject lock: a rounded-rectangle lump ingot of golden beeswax, 12 texels wide and 10 texels tall; palette exactly: highlight #F7DA6B, base #E8B84B, mid #C99334, shadow #9A6B26, outline #4A3210; the top face shows six hexagonal honeycomb indentations as 2-texel dark cells in two offset rows; one 2-texel specular highlight cluster on the top-left of the top face; the bottom and right edges of the lump use the shadow tone.
```

### item_chitin.png
```
16-bit pixel art item sprite in the style of a classic Minecraft inventory icon: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; flat cel shading, light source top-left; a 1-texel dark outline around the silhouette; a single centered object occupying about 12 of 16 texels; the rest of the canvas is solid flat magenta #FF00FF chroma-key background; no text, no watermark, no photorealism, no 3D render. Subject lock: one curved claw-like shard of insect chitin lying diagonally from bottom-left to top-right, 3-4 texels wide, with two serrated notch cuts on its lower edge; palette exactly: highlight #BFE8DC, base #7FC4B4, mid #4E9488, shadow #2E6058, outline #14302C; a 1-texel highlight ridge runs along the upper edge of the shard; the thick bottom-left end shows a fibrous fracture as two dark shadow texels.
```

### item_chitin_plate.png
```
16-bit pixel art item sprite in the style of a classic Minecraft inventory icon: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; flat cel shading, light source top-left; a 1-texel dark outline around the silhouette; a single centered object occupying about 12 of 16 texels; the rest of the canvas is solid flat magenta #FF00FF chroma-key background; no text, no watermark, no photorealism, no 3D render. Subject lock: a square armor plate 12 texels wide and 11 tall, built from three horizontal overlapping chitin bands; each band has a 1-texel highlight top edge, a base-tone middle and a 1-texel dark groove below it; one 1-texel pale rivet at each end of every band top edge; palette exactly: highlight #A8DCCE, base #6FB0A2, mid #47857A, groove #23544C, rivet #D8F0E8, outline #102824.
```

### item_frost_vial.png
```
16-bit pixel art item sprite in the style of a classic Minecraft inventory icon: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; flat cel shading, light source top-left; a 1-texel dark outline around the silhouette; a single centered object occupying about 12 of 16 texels; the rest of the canvas is solid flat magenta #FF00FF chroma-key background; no text, no watermark, no photorealism, no 3D render. Subject lock: a small glass vial 6 texels wide and 12 tall, centered: a 2-texel tall cork stopper #A8763E on top, a glass body outlined in #1E3A50, filled two thirds with luminous pale-blue liquid (base #7EC8F0, highlight #C8ECFC, deep #3E88C0), single white frost dots on the lower outer glass texels, and one 1-texel vertical specular streak on the left glass wall.
```

### item_wax_seal.png
```
16-bit pixel art item sprite in the style of a classic Minecraft inventory icon: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; flat cel shading, light source top-left; a 1-texel dark outline around the silhouette; a single centered object occupying about 12 of 16 texels; the rest of the canvas is solid flat magenta #FF00FF chroma-key background; no text, no watermark, no photorealism, no 3D render. Subject lock: a round red wax seal 12 texels in diameter viewed exactly from above with an irregular squeezed edge; wax body base #C23A30 with a highlight #E86A52 arc on the top-left and shadow #8E221C on the bottom-right; a recessed 1-texel dark ring #6E1614 at radius 4; inside the ring a raised square stamp 6x6 texels of the base tone carrying an embossed diamond emblem of four dark texels #6E1614 around one central highlight texel #E86A52; outline #4A0E0E.
```

### item_mead.png
```
16-bit pixel art item sprite in the style of a classic Minecraft inventory icon: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; flat cel shading, light source top-left; a 1-texel dark outline around the silhouette; a single centered object occupying about 12 of 16 texels; the rest of the canvas is solid flat magenta #FF00FF chroma-key background; no text, no watermark, no photorealism, no 3D render. Subject lock: a thick glass mug of mead 9 texels wide and 12 tall with a 2-texel thick C-shaped handle on the right; a 2-texel tall white foam head #F4F0E4 with one-texel overhang bumps above the rim; golden liquid base #E8A832 with a 1-texel vertical highlight streak #F8D070 on the left and shadow #B07820 on the right; glass outline #3A2A12; one 1-texel specular dot on the left glass wall.
```

### item_ledger_book.png
```
16-bit pixel art item sprite in the style of a classic Minecraft inventory icon: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; flat cel shading, light source top-left; a 1-texel dark outline around the silhouette; a single centered object occupying about 12 of 16 texels; the rest of the canvas is solid flat magenta #FF00FF chroma-key background; no text, no watermark, no photorealism, no 3D render. Subject lock: a closed ledger book seen straight at the front cover, 12 texels wide and 12 tall; cover base brown #8A5A2C with a 1-texel darker spine groove #5A3A1A at column 2 and an embossed frame line #5A3A1A inset two texels from the cover edges; a 4x4 red wax seal #C23A30 with one highlight texel #E86A52 in the cover center; a 1x2 brass clasp #D4AC40 on the right cover edge; a 2-column wide cream page block #EAE2C8 along the right side; outline #2A1808.
```

### item_route_map.png
```
16-bit pixel art item sprite in the style of a classic Minecraft inventory icon: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; flat cel shading, light source top-left; a 1-texel dark outline around the silhouette; a single centered object occupying about 14 of 16 texels; the rest of the canvas is solid flat magenta #FF00FF chroma-key background; no text, no watermark, no photorealism, no 3D render. Subject lock: a folded parchment map 14 texels wide and 11 tall; paper base #E2D0A0 with shade #CEBA8C and 1-texel fold lines #AC9468 at columns 5 and 10 and along row 8; a 2x2 water patch #6C94A8 top-left and another mid-right; a 2x2 forest patch #7A9456 bottom-left and another top-right; a dashed route of single texels #9E4228 stepping diagonally from the bottom-left to the top-right, ending in a 2x2 red X mark #BA3428; outline #3E3018.
```

---

## ГРАНИ БЛОКОВ

Общий замок для граней (встроен в каждый промт): узор заполняет всю сетку 16×16 от края
до края, ортопроекция, без рамки и фона, контур только у внутренних элементов.

### block_ledger_desk_side.png
```
16-bit pixel art cube-face block texture in the style of a classic Minecraft block texture: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; the pattern fills the entire 16x16 grid edge to edge, flat orthographic frontal view, no border, no background, no perspective; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; light source top-left; no text, no watermark, no photorealism, no 3D render. Layout lock: warm oak plank facade, base #A8763E with horizontal plank seam lines #6E4A24 at rows 5 and 10; upper section rows 1-4 holds two drawer fronts #C08A4A, each with one 1-texel brass handle #D4AC40 in its middle; lower section rows 11-14 is one inset panel outlined #6E4A24; a 1-texel dark trim #4A3210 along row 0 and row 15.
```

### block_ledger_desk_top.png
```
16-bit pixel art cube-face block texture in the style of a classic Minecraft block texture: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; the pattern fills the entire 16x16 grid edge to edge, flat orthographic top-down view, no border, no background, no perspective; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; light source top-left; no text, no watermark, no photorealism, no 3D render. Layout lock: oak plank desktop base #B08048 with stepped vertical grain lines #8A5A2C; an axis-aligned open paper ledger 8x6 texels #EAE2C8 left of center with 1-texel text lines #8A8272 and one red margin dot #C23A30; a 2x2 black ink pot #202024 with one highlight texel #8A8E96 to the right of the ledger; two single-texel wax droplets #E8B84B on the wood.
```

### block_wax_press_side.png
```
16-bit pixel art cube-face block texture in the style of a classic Minecraft block texture: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; the pattern fills the entire 16x16 grid edge to edge, flat orthographic frontal view, no border, no background, no perspective; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; light source top-left; no text, no watermark, no photorealism, no 3D render. Layout lock: heavy timber press frame, 2-texel dark posts #4A3210 at columns 0-1 and 14-15, top beam rows 0-1 #6E4A24; a central vertical iron screw 2 texels wide #8A8E96 with a 4x2 square head #6E727A at rows 2-3; a horizontal press plate at rows 7-8 #6E727A with a 1-texel top highlight #A8ACB4; single-texel golden wax drips #E8B84B falling from the plate at columns 5 and 10; a shallow tray at rows 13-15 #6E4A24 filled with wax #E8B84B and a highlight line #F7DA6B.
```

### block_wax_press_top.png
```
16-bit pixel art cube-face block texture in the style of a classic Minecraft block texture: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; the pattern fills the entire 16x16 grid edge to edge, flat orthographic top-down view, no border, no background, no perspective; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; light source top-left; no text, no watermark, no photorealism, no 3D render. Layout lock: a square timber frame 2 texels wide #6E4A24 with darker corner joints #4A3210; inside it a 12x12 worn iron plate base #7A7E86 with stepped scratch highlights #A8ACB4; a 4x4 square screw head #5A5E66 in the exact center with a 1-texel highlight on its top-left; single-texel wax residue dots #E8B84B in two inner corners of the frame.
```

### block_cold_cellar_side.png
```
16-bit pixel art cube-face block texture in the style of a classic Minecraft block texture: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; the pattern fills the entire 16x16 grid edge to edge, flat orthographic frontal view, no border, no background, no perspective; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; light source top-left; no text, no watermark, no photorealism, no 3D render. Layout lock: rows 0-1 are a white-blue frost band #EAF4FA with 1-texel icicle drips #CFE4F0 hanging into rows 2-3 at columns 2, 6 and 11; rows 2-15 are dark stone bricks base #565C66 with 1-texel mortar lines #2A2E36 in offset courses every 4 rows and 1-texel brick top highlights #6E747E; single cold-blue tint texels #4A5A6A at a few mortar crossings.
```

### block_cold_cellar_top.png
```
16-bit pixel art cube-face block texture in the style of a classic Minecraft block texture: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; the pattern fills the entire 16x16 grid edge to edge, flat orthographic top-down view, no border, no background, no perspective; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; light source top-left; no text, no watermark, no photorealism, no 3D render. Layout lock: a square slab of stone bricks base #565C66 with mortar lines #2A2E36 in offset courses; a 4x4 iron ring handle #3A3E46 with top-left highlight texels #8A8E96 centered over a 2x2 mount #2A2E36; frost crystals #EAF4FA along all four edges, 1 texel thick at edge middles and 2 texels at the corners.
```

### block_contract_board_side.png
```
16-bit pixel art cube-face block texture in the style of a classic Minecraft block texture: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; the pattern fills the entire 16x16 grid edge to edge, flat orthographic frontal view, no border, no background, no perspective; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; light source top-left; no text, no watermark, no photorealism, no 3D render. Layout lock: horizontal wooden planks base #A8763E with seam lines #6E4A24 at rows 4, 9 and 14; three pinned parchment notices 3 texels wide and 5 tall at columns 2-4, 7-9 and 12-14, rows 3-7: paper #EAE2C8 with 1-texel text lines #8A8272, one red wax dot #C23A30 at the bottom-right of each notice and one dark pin texel #4A3210 at the top-center; darker trim #4A3210 along row 0 and row 15.
```

### block_contract_board_top.png
```
16-bit pixel art cube-face block texture in the style of a classic Minecraft block texture: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; the pattern fills the entire 16x16 grid edge to edge, flat orthographic top-down view, no border, no background, no perspective; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; light source top-left; no text, no watermark, no photorealism, no 3D render. Layout lock: plain worn wooden plank surface base #A8763E with stepped vertical grain lines #8A5A2C; two nail heads #4A3210 each with one highlight texel #C08A4A at texel (2,2) and texel (13,13); a few corner shade texels #8A5A2C.
```

### block_trade_post_side.png
```
16-bit pixel art cube-face block texture in the style of a classic Minecraft block texture: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; the pattern fills the entire 16x16 grid edge to edge, flat orthographic frontal view, no border, no background, no perspective; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; light source top-left; no text, no watermark, no photorealism, no 3D render. Layout lock: background fill dark wood shade #6E4A24; a horizontal sign board at rows 1-4, plank #C08A4A with a 1-texel border #4A3210 and three clusters of two faded red trade-mark texels #9E4228; a central support post at columns 7-8, rows 5-12, #8A5A2C with a 1-texel edge shade #6E4A24 on its right; two crates at rows 9-15, left at columns 0-5 and right at columns 10-15: plank faces #A8763E with 1-texel borders #4A3210 and one diagonal brace texel line #8A5A2C each.
```

### block_trade_post_top.png
```
16-bit pixel art cube-face block texture in the style of a classic Minecraft block texture: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; the pattern fills the entire 16x16 grid edge to edge, flat orthographic top-down view, no border, no background, no perspective; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; light source top-left; no text, no watermark, no photorealism, no 3D render. Layout lock: top-down crate lids: left 7 columns are one crate lid, planks #A8763E with a 1-texel frame #4A3210 and an X-brace #8A5A2C; right 7 columns are a second crate lid in offset tone #B08048 with the same frame and brace; the central 2 columns are a crossbeam #6E4A24 with two nail dots #4A3210; one rope corner dot #CEBA8C on each lid.
```

### block_beeswax_block_side.png
```
16-bit pixel art cube-face block texture in the style of a classic Minecraft block texture: drawn on an exact 16x16 texel grid, presented upscaled with nearest-neighbor so every texel is a solid square of one flat color; the pattern fills the entire 16x16 grid edge to edge, flat orthographic frontal view, no border, no background, no perspective; hard stepped edges, no anti-aliasing, no gradients, no blur, no dithering; light source top-left; no text, no watermark, no photorealism, no 3D render. Layout lock: a full-frame honeycomb of hexagonal cells 4 texels wide in offset rows; 1-texel cell walls #C99334; cell interiors alternate between capped cells #E8B84B with one highlight dot #F7DA6B and open cells #9A6B26 with one glossy honey texel #F2C85E; the comb pattern touches all four edges of the grid.
```

---

## Если сеть всё равно сбивается в фотореализм

Добавь в начало промта одну из этих скобок стиля (на выбор, что сработает):
- `sprite sheet asset for a retro pixel video game, `
- `in the style of a 1990s point-and-click adventure inventory icon, `
- `vector-flat pixel-perfect game icon, visible square pixel grid, `

И усиливь запреты в конце: `strictly no photography, strictly no realistic lighting,
strictly no smooth shading, every color region must be a flat solid block of pixels.`
