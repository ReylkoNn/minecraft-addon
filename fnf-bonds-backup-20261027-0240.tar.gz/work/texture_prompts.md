# Промты для генерации исходников спрайтов fnfbonds (v0.1.0 texture pass)

Цель: получить в другой нейросети (фото/рендер-качества) исходники, из которых я затем
соберу игровые спрайты 16×16: вырежу фон, урежу до 16px, соберу палитру с hue-shifted
тенями, добавлю контур и доведу пиксели руками. От тебя — только прогнать промты и
положить результаты в `work/texsrc/` под точными именами файлов из заголовков ниже.

## Общие правила прогонов

- Формат: **строго 1:1** (1024×1024 или 512×512). Один объект/поверхность на кадр.
- Имена файлов — как в заголовках (`item_beeswax.png`, `block_wax_press_side.png` …).
  Если гонишь несколько вариантов — суффикс `_v2`, `_v3`: я выберу лучший.
- К каждому промту дописывать **STYLE_…** и **NEG** (соответственно типу спрайта).
- Предметы (`STYLE_ITEM`): объект изолирован на ровном сером `#808080` — это мой ключ
  для вырезания. Если сеть умеет прозрачный фон — ещё лучше, ставь его.
- Грани блоков (`STYLE_FACE`): поверхность заполняет кадр **от края до края**, без рамок,
  без виньетки, без перспективы (ортопроекция). Seamless не нужен (грань = один quad).
- Чем проще силуэт и крупнее детали — тем лучше они переживут даунскейл до 16px.
  Мелкая вязкость всё равно исчезнет, зато съест контраст.

## Глобальные токены

**STYLE_ITEM** =
`photorealistic studio product shot, single object centered, occupies about 85 percent of the frame, straight-on frontal view, soft even key light from the top-left, subtle rim light, flat uniform mid-gray background hex 808080, no cast shadow on the background, bold simple shapes readable at very small size, rich material detail, square 1:1 composition`

**STYLE_FACE** =
`photorealistic surface texture, flat orthographic frontal view, the surface fills the entire frame edge to edge, uniform soft lighting from the top-left, no perspective, no vignette, no border, no frame, square 1:1 composition`

**NEG** =
`text, letters, numbers, runes, watermark, logo, frame, border, multiple objects, hands, fingers, cropped object, extreme perspective, fisheye, harsh black shadows, pure black background, pure white background, vignette, film grain, jpeg artifacts, depth of field blur`

---

## ПРЕДМЕТЫ (8)

### item_beeswax.png — слиток воска
`A single solid ingot-like lump of golden yellow beeswax, a slightly rounded rectangular block, its top surface pressed with a pattern of hexagonal honeycomb cell indentations, semi-matte waxy surface with one soft specular highlight on the upper left, tiny air bubbles and warmer amber tones in the crevices, clean crisp silhouette` + STYLE_ITEM + NEG

### item_chitin.png — осколок хитина
`A single curved shard of insect chitin, an elongated claw-like flake with a serrated notched edge on one side, deep teal-green color with a pearlescent sheen, layered fibrous fracture at the thick end, one smooth glossy ridge running along the center, lying diagonally across the frame` + STYLE_ITEM + NEG

### item_chitin_plate.png — хитиновая пластина
`A square armor plate assembled from three horizontal overlapping bands of teal-green chitin, small pale rivets at the corners of each band, dark recessed grooves between the bands, perfectly flat straight-on view of the plate face, the plate fills most of the frame, slight pearlescent sheen on the band edges` + STYLE_ITEM + NEG

### item_frost_vial.png — флакон мороза
`A small round glass vial with a narrow neck and a natural cork stopper, filled two thirds with luminous pale-blue liquid, delicate white frost crystals creeping over the lower half of the glass, two bright specular streaks on the glass, the liquid softly glowing from within` + STYLE_ITEM + NEG

### item_wax_seal.png — восковая печать
`A round red wax seal viewed exactly from above, irregular squeezed wax edge with two small drips, a recessed darker ring around a raised square stamp, an embossed diamond emblem pressed into the center of the stamp, semi-gloss wax surface with a soft highlight on the upper left` + STYLE_ITEM + NEG

### item_mead.png — кружка меда
`A thick glass mug of golden mead with a dense white foam head rising just above the rim, a sturdy glass handle on the right side, small bubbles rising through the honey-gold liquid, warm amber tones, straight-on side view, mug standing upright` + STYLE_ITEM + NEG

### item_ledger_book.png — книга учёта
`A closed thick leather ledger book viewed straight at the front cover, worn medium-brown leather, a darker spine groove along the left edge, an embossed rectangular frame on the cover, a small red wax seal with a brass stud in the center of the cover, a brass clasp on the right edge, a cream-colored page block visible along the right side` + STYLE_ITEM + NEG

### item_route_map.png — карта маршрута
`An old parchment map viewed flat from directly above, a folded square sheet with two visible crease lines, faded blue-green water and green forest patches, a dashed red-brown route line crossing diagonally to a bold red X mark in the upper right corner, a small green village mark in the lower left corner, aged paper tones` + STYLE_ITEM + NEG

---

## ГРАНИ БЛОКОВ (11)

### block_ledger_desk_side.png — стол писаря, бок
`Front view of a sturdy craftsman's wooden desk facade: warm oak planks, an upper section with two drawers and small brass handles, a paneled lower section, dark wood trim along all edges, subtle wear on the corners` + STYLE_FACE + NEG

### block_ledger_desk_top.png — стол писаря, верх
`Top-down view of a wooden desk work surface: warm oak planks, an open paper ledger with faint handwritten lines lying at a slight angle, a small black ink pot with a quill beside it, a few wax droplets on the wood` + STYLE_FACE + NEG

### block_wax_press_side.png — пресс воска, бок
`Front view of a wooden screw press: heavy timber frame, a central vertical iron screw with a square head, a horizontal press plate under the screw, golden liquid wax dripping from the plate into a shallow tray at the bottom, dark wood tones` + STYLE_FACE + NEG

### block_wax_press_top.png — пресс воска, верх
`Top-down view of the top of a screw press: a square timber frame around a worn dark iron plate, a square screw head in the exact center, traces of yellow wax in the corners of the frame` + STYLE_FACE + NEG

### block_cold_cellar_side.png — холодный погреб, бок
`Front view of a cold cellar wall: dark grey stone brick masonry with pale mortar lines, a band of white frost and small icicles hanging along the top edge, cold blue tint in the crevices between bricks` + STYLE_FACE + NEG

### block_cold_cellar_top.png — холодный погреб, верх
`Top-down view of a square stone cellar hatch: a slab of grey stone bricks, a dark iron ring handle in the center, white frost crystals thickening toward the edges of the slab` + STYLE_FACE + NEG

### block_contract_board_side.png — доска контрактов, бок
`Front view of a village bulletin board: horizontal warm-brown wooden planks, three white parchment notices pinned in a row, each notice with faint text lines and a small red wax dot, darker wood trim along the top and bottom edges` + STYLE_FACE + NEG

### block_contract_board_top.png — доска контрактов, верх
`Top-down view of a plain worn wooden plank surface, warm medium brown, visible wood grain, two dark nail heads near opposite corners` + STYLE_FACE + NEG

### block_trade_post_side.png — торговый пост, бок
`Front view of a trading post: a horizontal painted sign board across the top with faded red trade marks on it, a central wooden support post below the sign, stacked wooden crates with plank patterns on both sides at the bottom, weathered medium-brown wood` + STYLE_FACE + NEG

### block_trade_post_top.png — торговый пост, верх
`Top-down view of the top of a trading post: weathered wooden crate lids and a crossbeam filling the frame, plank seams, rope corners on one crate, warm brown tones` + STYLE_FACE + NEG

### block_beeswax_block_side.png — блок воска, любая грань (одна на весь куб)
`A solid block face of golden beeswax completely covered in hexagonal honeycomb cells, some cells capped with lighter matte wax, a few open cells showing glossy honey inside, warm amber palette, even comb size across the whole frame` + STYLE_FACE + NEG

---

## Что я сделаю с результатами (моя сторона конвейера)

1. Вырежу фон (ключ по `#808080`/альфе), обрежу по bbox объекта, нормализую масштаб.
2. Даунскейл до 16×16 area-фильтром (не nearest), затем quantize палитры до 10–16 цветов
   с hue-shifted тенями (тени в холодный/тёплый оттенок, не просто затемнение).
3. Контур в 1px самым тёмным цветом палитры, ручная чистка «каши» и лесенок.
4. Проверка читаемости: мок слота инвентаря ×8 + изометрия куба; листы preview/compare.
5. Установка в мод: `assets/fnfbonds/textures/`, 5 моделей блоков `cube_all` → `cube`
   (top/side/bottom), пересборка jar, по желанию ингейм-скриншоты.

Если какой-то промт даст мусор — не перегонивай сам: пришли файл как есть,
я поправлю промт точечно (свет/ракурс/детали) и скажу, что изменить.
