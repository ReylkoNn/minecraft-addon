#!/usr/bin/env python3
"""Run vineflower over the full preProcessJar in batches (-only=<classes>) so the
1150m heap never holds more than ~1100 class ASTs at once. Outputs out_NN.jar + log_NN.txt."""
import json, subprocess, sys, os, re, time

JAVA = '/home/user/.cache/jdk25/bin/java'
VF = '/home/user/.cache/gradle/caches/modules-2/files-2.1/org.vineflower/vineflower/1.12.0/85570609a0a5941a7d2918b6260b209de810f66f/vineflower-1.12.0.jar'
VFP = '/home/user/.cache/gradle/caches/modules-2/files-2.1/net.neoforged/vineflower-plugins/0.1.6/84857083964b98ac94f8d124f401c2b2d86839ab/vineflower-plugins-0.1.6.jar'
SRC = '/home/user/.cache/gradle/caches/neoformruntime/intermediate_results/preProcessJar_dad447fdce426e4e05a84a2eff47da4c9f24f251_output.jar'
WD = '/home/user/work/vf'

FLAGS = ['--decompile-inner', '--remove-bridge', '--decompile-generics', '--ascii-strings',
         '--remove-synthetic', '--include-classpath', '--ignore-invalid-bytecode',
         '--bytecode-source-mapping', '--dump-code-lines', '--indent-string=    ',
         '--log-level=WARN', '--thread-count=1']

def run_batch(i, classes, heap):
    out = f'{WD}/out_{i:02d}.jar'
    log = f'{WD}/log_{i:02d}.txt'
    if os.path.exists(out):
        os.remove(out)
    cmd = [JAVA, f'-Xmx{heap}m', '-XX:+UseSerialGC', '-cp', f'{VF}:{VFP}',
           'org.jetbrains.java.decompiler.main.decompiler.ConsoleDecompiler',
           *FLAGS, '-only=' + ','.join(classes), '-cfg=./libraries.txt', SRC, out]
    t0 = time.time()
    with open(log, 'w') as lf:
        rc = subprocess.call(cmd, stdout=lf, stderr=subprocess.STDOUT, cwd=WD)
    dt = time.time() - t0
    txt = open(log, errors='replace').read()
    bad = len(re.findall(r"couldn't be (?:fully )?decompiled", txt))
    oom = txt.count('OutOfMemoryError')
    size = os.path.getsize(out) if os.path.exists(out) else -1
    print(f'batch {i:02d}: rc={rc} {dt:.0f}s out={size}B stubs={bad} oom={oom}', flush=True)
    return rc, bad

def main():
    only = sys.argv[1:] if len(sys.argv) > 1 else None
    batches = json.load(open(f'{WD}/batches.json'))
    heap = int(os.environ.get('VF_HEAP', '1150'))
    targets = [int(x) for x in only] if only else range(len(batches))
    for i in targets:
        run_batch(i, batches[i], heap)
    print('ALL DONE', flush=True)

if __name__ == '__main__':
    main()
