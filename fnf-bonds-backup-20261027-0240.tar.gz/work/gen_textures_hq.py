#!/usr/bin/env python3
"""Hand-drawn 16x16 pixel art for fnfbonds (high-quality pass).

Every sprite is an ASCII grid: one character per texel, '.' = transparent.
Palettes are deliberately small and hand-picked (outline / shadow / mid /
light / highlight plus accents), light comes from the top-left like in
vanilla item art, and gradients on liquids and wax are checker-dithered.

Output:
  work/texhq/*.png     the real 16x16 textures (items + block faces)
  work/texhq/preview.png  a look-dev sheet: items on inventory slots and
                          blocks as isometric cubes built from their faces
Nothing here costs the game anything: 16x16 PNGs, vanilla atlas, mipmaps.
"""
import pathlib

from PIL import Image, ImageDraw, ImageFont

OUT = pathlib.Path('/home/user/work/texhq')
OUT.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------- grids
# items ---------------------------------------------------------------------

BEESWAX = [
    '................',
    '................',
    '................',
    '....KKKKKKKK....',
    '..KKHHLLHHLLKK..',
    '.KHHLLHHLLHHLMK.',
    '.KHLWLHLWLHLLMK.',
    '.KLLHLHLHLLLMMK.',
    '.KMLWLHLWLMLMMK.',
    '.KMLLHLHLHLLMMK.',
    '.KMMLLHLHLLLMMK.',
    '.KMMMLLLLLMMMDK.',
    '..KMMMMMMMDDDK..',
    '...KKKKKKKKKK...',
    '................',
    '................',
]
BEESWAX_P = {
    'K': (72, 44, 12, 255), 'D': (146, 92, 22, 255), 'M': (196, 132, 34, 255),
    'L': (228, 172, 60, 255), 'H': (252, 216, 122, 255), 'W': (120, 72, 18, 255),
}

CHITIN = [
    '................',
    '..........KKK...',
    '.........KHLK...',
    '........KHLMLK..',
    '.......KHLMLRK..',
    '......KHLMLRRK..',
    '.....KHLMLRRDK..',
    '....KHLMKRRDDK..',
    '...KHLMLRRDDDK..',
    '..KHLMLRRDDDDK..',
    '..KHLMKRRDDDK...',
    '..KLMRRDDDDK....',
    '..KMRDDDDKK.....',
    '..KRDDDKK.......',
    '..KDDKK.........',
    '..KKK...........',
]
CHITIN_P = {
    'K': (14, 26, 28, 255), 'D': (46, 78, 82, 255), 'R': (32, 56, 60, 255),
    'M': (78, 122, 122, 255), 'L': (122, 172, 164, 255), 'H': (186, 228, 214, 255),
}

CHITIN_PLATE = [
    '................',
    '................',
    '..KKKKKKKKKKKK..',
    '.KHLLHLLHLLHLDK.',
    '.KLLMMLMMLMMLDK.',
    '.KRRRRRRRRRRRRK.',
    '.KHLLHLLHLLHLDK.',
    '.KLLMMLMMLMMLDK.',
    '.KRRRRRRRRRRRRK.',
    '.KHLLHLLHLLHLDK.',
    '.KLLMMLMMLMMLDK.',
    '.KRRRRRRRRRRRRK.',
    '..KDDKDDKDDKDK..',
    '...KKKKKKKKKK...',
    '................',
    '................',
]
CHITIN_PLATE_P = {
    'K': (14, 26, 28, 255), 'D': (40, 68, 72, 255), 'R': (28, 48, 52, 255),
    'M': (70, 112, 112, 255), 'L': (112, 160, 152, 255), 'H': (198, 236, 222, 255),
}

FROST_VIAL = [
    '................',
    '......KKKK......',
    '......KccK......',
    '......KCcc......',
    '.....KGgGK......',
    '.....KGgGK......',
    '....KGgGgGK.....',
    '....KGgbbgGK....',
    '....KGbBBbgK....',
    '....KgbBSBbK....',
    '....KbBBBbbK....',
    '....KbBbBBbK....',
    '....KbbBBbbK....',
    '.....KbbbbK.....',
    '......KKKK......',
    '................',
]
FROST_VIAL_P = {
    'K': (22, 28, 40, 255), 'C': (146, 102, 60, 255), 'c': (110, 74, 42, 255),
    'G': (206, 232, 240, 255), 'g': (158, 202, 220, 255), 'B': (126, 198, 234, 255),
    'b': (70, 142, 204, 255), 'S': (238, 252, 255, 255),
}

WAX_SEAL = [
    '................',
    '................',
    '.....KKKKKK.....',
    '...KKHHHHMMKK...',
    '..KHHMMMMMMMLK..',
    '.KHMMMMMMMMMLLK.',
    '.KMMDDDDDDDDMLK.',
    '.KMMDLLDDLLDMLK.',
    '.KMMDLDLLDLDMLK.',
    '.KMMDLDLLDLDMLK.',
    '.KMMDLLDDLLDMLK.',
    '.KMMDDDDDDDDMLK.',
    '..KLLMMMMMMLLK..',
    '...KKLLMMLKKK...',
    '.....KKKKKK.....',
    '................',
]
WAX_SEAL_P = {
    'K': (52, 12, 12, 255), 'D': (104, 22, 20, 255), 'M': (164, 42, 36, 255),
    'L': (206, 82, 62, 255), 'H': (240, 148, 118, 255),
}

MEAD = [
    '................',
    '....KKKKKKK.....',
    '...KFFFFFFFK.K..',
    '...KFfFFfFFK.K..',
    '...KAAAAAAAKKK..',
    '...KAaAAAaAKHK..',
    '...KAaAAAaAKHK..',
    '...KAAAAAAAKHK..',
    '...KAaAAAaAKHK..',
    '...KAaAAAaAKHK..',
    '...KAAAAAAAKKK..',
    '...KAaAAAaAK....',
    '...KAAAAAAAK....',
    '....KKKKKKK.....',
    '................',
    '................',
]
MEAD_P = {
    'K': (30, 22, 14, 255), 'F': (246, 244, 230, 255), 'f': (214, 206, 182, 255),
    'A': (214, 150, 42, 255), 'a': (168, 110, 26, 255), 'H': (236, 244, 246, 255),
}

LEDGER_BOOK = [
    '................',
    '.KKKKKKKKKKKK...',
    '.KMMMMMMMMMLKpP.',
    '.KDMMMMMMMMLKpP.',
    '.KDMMMMMMMMLKpP.',
    '.KDMMKSSSSKLKpP.',
    '.KDMMKSHHSKLBpP.',
    '.KDMMKSHHSKLBpP.',
    '.KDMMKSSSSKLKpP.',
    '.KDMMMMMMMMLKpP.',
    '.KMMMMMMMMMLKpP.',
    '.KDDDDDDDDDLKpP.',
    '..KKKKKKKKKKK...',
    '................',
    '................',
    '................',
]
LEDGER_BOOK_P = {
    'K': (24, 14, 8, 255), 'D': (84, 50, 26, 255), 'M': (126, 78, 40, 255),
    'L': (156, 102, 54, 255), 'P': (234, 226, 200, 255), 'p': (196, 186, 156, 255),
    'S': (168, 42, 36, 255), 'B': (212, 164, 64, 255), 'H': (228, 118, 98, 255),
}

ROUTE_MAP = [
    '................',
    '.KKKKKKKKKKKKKK.',
    '.KPPPqPPPPqPPPK.',
    '.KPWWqPPPPqXXPK.',
    '.KPWWqPPPPRXXPK.',
    '.KPqPPqPPRqPPGK.',
    '.KPPPPqPRPqPPPK.',
    '.KPGPPqPPPqPWWK.',
    '.KppppppRpppppK.',
    '.KPPGPRPPPqPPPK.',
    '.KPPRqPPPPqPPPK.',
    '.KGGPqPPPPqPPPK.',
    '.KKKKKKKKKKKKKK.',
    '................',
    '................',
    '................',
]
ROUTE_MAP_P = {
    'K': (62, 48, 28, 255), 'P': (226, 208, 160, 255), 'p': (206, 186, 140, 255),
    'q': (172, 150, 108, 255), 'R': (158, 66, 40, 255), 'W': (108, 148, 168, 255),
    'G': (122, 148, 86, 255), 'X': (186, 52, 40, 255),
}

ITEMS = {
    'beeswax': (BEESWAX, BEESWAX_P),
    'chitin': (CHITIN, CHITIN_P),
    'chitin_plate': (CHITIN_PLATE, CHITIN_PLATE_P),
    'frost_vial': (FROST_VIAL, FROST_VIAL_P),
    'wax_seal': (WAX_SEAL, WAX_SEAL_P),
    'mead': (MEAD, MEAD_P),
    'ledger_book': (LEDGER_BOOK, LEDGER_BOOK_P),
    'route_map': (ROUTE_MAP, ROUTE_MAP_P),
}

# block faces ----------------------------------------------------------------

WOOD_D = (84, 54, 28, 255)
WOOD_M = (122, 82, 44, 255)
WOOD_L = (152, 106, 60, 255)
WOOD_K = (52, 34, 18, 255)

DESK_TOP = [
    'dddddddddddddddd',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dPPPPPPPPdIIKdmd',
    'dPppppppPdIKKdmd',
    'dPppppppPdIIKdmd',
    'dPPPPPPPPddKKdmd',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dddddddddddddddd',
]
DESK_TOP_P = {
    'd': WOOD_K, 'm': WOOD_M, 'l': WOOD_L, 'P': (234, 226, 200, 255),
    'p': (204, 194, 164, 255), 'I': (30, 26, 34, 255), 'K': (58, 44, 30, 255),
}

DESK_SIDE = [
    'dddddddddddddddd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dKKKKKKKKKKKKKKd',
    'dKlllllllllllKKd',
    'dKlmmmmmmmmmlKKd',
    'dKlmmBBmmmmmlKKd',
    'dKlmmmmmmmmmlKKd',
    'dKlllllllllllKKd',
    'dKKKKKKKKKKKKKKd',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dKllllllllllllKd',
    'dKllllllllllllKd',
    'dddddddddddddddd',
]
DESK_SIDE_P = {
    'd': WOOD_K, 'm': WOOD_M, 'l': WOOD_L, 'K': (46, 30, 16, 255),
    'B': (212, 164, 64, 255),
}

PRESS_TOP = [
    'dddddddddddddddd',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmKKKKKKKKKKmmd',
    'dmmKSSSSSSSSKmmd',
    'dmmKSSbbbbSSKmmd',
    'dmmKSSbHHbSSKmmd',
    'dmmKSSbHHbSSKmmd',
    'dmmKSSbbbbSSKmmd',
    'dmmKSSSSSSSSKmmd',
    'dmmKKKKKKKKKKmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dddddddddddddddd',
]
PRESS_TOP_P = {
    'd': WOOD_K, 'm': WOOD_M, 'l': WOOD_L, 'K': (40, 40, 46, 255),
    'S': (108, 108, 118, 255), 'b': (70, 70, 80, 255), 'H': (176, 176, 188, 255),
}

PRESS_SIDE = [
    'dddddddddddddddd',
    'dlllllllllllllld',
    'dKmmmmmmmmmmmmKd',
    'dKmmmmKKmmmmmmKd',
    'dKSSSSKKSSSSSSKd',
    'dKSSSSKKSSSSSSKd',
    'dKmmmmKKmmmmmmKd',
    'dKmmmmKKmmmmmmKd',
    'dKKKKKKKKKKKKKKd',
    'dKLLLLLLLLLLLLKd',
    'dKLLLLLLLLLLLLKd',
    'dKKKKKKKKKKKKKKd',
    'dmmmmmmmmmmmmmmd',
    'dKYYYYYYYYYYYYKd',
    'dKYYYYYYYYYYYYKd',
    'dddddddddddddddd',
]
PRESS_SIDE_P = {
    'd': WOOD_K, 'm': WOOD_M, 'l': WOOD_L, 'K': (46, 30, 16, 255),
    'S': (108, 108, 118, 255), 'L': (152, 106, 60, 255), 'Y': (214, 168, 60, 255),
}

CELLAR_TOP = [
    'kkkkkkkkkkkkkkkk',
    'kFFFFFFFFFFFFFFk',
    'kFssssssssssssFk',
    'kFskkkkkkkkkksFk',
    'kFskssssssssksFk',
    'kFskssHHHHssksFk',
    'kFskssHHHHssksFk',
    'kFskssssssssksFk',
    'kFskssssssssksFk',
    'kFskssHHHHssksFk',
    'kFskssHHHHssksFk',
    'kFskssssssssksFk',
    'kFskkkkkkkkkksFk',
    'kFssssssssssssFk',
    'kFFFFFFFFFFFFFFk',
    'kkkkkkkkkkkkkkkk',
]
CELLAR_TOP_P = {
    'k': (28, 32, 38, 255), 'F': (186, 220, 234, 255), 's': (96, 102, 112, 255),
    'H': (60, 66, 76, 255),
}

CELLAR_SIDE = [
    'FFFFFFFFFFFFFFFF',
    'FfFfFfFfFfFfFfFf',
    'ksskkssskksskkss',
    'ksskkssskksskkss',
    'kkkkkkkkkkkkkkkk',
    'sskkssskksskkssk',
    'sskkssskksskkssk',
    'kkkkkkkkkkkkkkkk',
    'kksskkssskksskks',
    'kksskkssskksskks',
    'kkkkkkkkkkkkkkkk',
    'skkssskksskksskk',
    'skkssskksskksskk',
    'kkkkkkkkkkkkkkkk',
    'sskkssskksskkssk',
    'sskkssskksskkssk',
]
CELLAR_SIDE_P = {
    'k': (38, 42, 50, 255), 's': (108, 114, 124, 255), 'F': (186, 220, 234, 255),
    'f': (140, 180, 202, 255),
}

BOARD_SIDE = [
    'dddddddddddddddd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dKPPPKdPPPKdPPKd',
    'dKqqqKdqqqKdqqKd',
    'dKPPPKdPPPKdPPKd',
    'dKpRpKdpRpKdpRKd',
    'dKPPPKdPPPKdPPKd',
    'dKqqqKdqqqKdqqKd',
    'dKKKKKdKKKKdKKKd',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dddddddddddddddd',
]
BOARD_SIDE_P = {
    'd': WOOD_K, 'm': WOOD_M, 'l': WOOD_L, 'K': (46, 30, 16, 255),
    'P': (232, 226, 208, 255), 'p': (200, 192, 168, 255), 'R': (158, 66, 40, 255),
    'q': (168, 148, 112, 255),
}

BOARD_TOP = [
    'dddddddddddddddd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dlllllllllllllld',
    'dmmmmmmmmmmmmmmd',
    'dddddddddddddddd',
]
BOARD_TOP_P = {'d': WOOD_K, 'm': WOOD_M, 'l': WOOD_L}

POST_SIDE = [
    'dddddddddddddddd',
    'dKKKKKKKKKKKKKKd',
    'dKPPPPPPPPPPPPKd',
    'dKpppRpppRpppRKd',
    'dKPPPPPPPPPPPPKd',
    'dKKKKKKKKKKKKKKd',
    'mmmmmKMMLLKmmmmm',
    'mmmmmKMMLLKmmmmm',
    'mmmmmKMMLLKmmmmm',
    'KKKKKKMMLLKKKKKK',
    'KLMMLKMMLLKLMMLK',
    'KLMMLKMMLLKLMMLK',
    'KKKKKKMMLLKKKKKK',
    'mmmmmmKKKKmmmmmm',
    'mmmmmmKKKKmmmmmm',
    'dddddddddddddddd',
]
POST_SIDE_P = {
    'd': WOOD_K, 'm': (98, 68, 38, 255), 'l': WOOD_L, 'K': (46, 30, 16, 255),
    'P': (214, 172, 100, 255), 'p': (122, 62, 40, 255), 'L': (172, 122, 68, 255), 'M': (140, 96, 52, 255),
    'R': (158, 66, 40, 255),
}

POST_TOP = [
    '................',
    '....dddddddd....',
    '....dmmmmml d...'.replace(' ', 'l'),
    '....dmllllmld...'.replace('l', 'l', 1),
    '....dmllllmld...',
    '....dmllllmld...',
    '....dmllllmld...',
    '....dmllllmld...',
    '....dmllllmld...',
    '....dmllllmld...',
    '....dmmmmmmld...'.replace('l', 'l'),
    '....dddddddd....',
    '................',
    '................',
    '................',
    '................',
]
POST_TOP_P = {'d': WOOD_K, 'm': WOOD_M, 'l': WOOD_L}

BEESWAX_BLOCK = [
    'MMMMMMMMMMMMMMMM',
    'MKLLKMMKLLKMMKLL',
    'MKHLLKMKHLLKMKHL',
    'MKLLLKMKLLLKMKLL',
    'MKDDKMMKDDKMMKDD',
    'MMMMMMMMMMMMMMMM',
    'MMKLLKMMKLLKMMKL',
    'MMKHLLKMKHLLKMKH',
    'MMKLLLKMKLLLKMKL',
    'MMKDDKMMKDDKMMKD',
    'MMMMMMMMMMMMMMMM',
    'KLLKMMKLLKMMKLLK',
    'KHLLKMKHLLKMKHLL',
    'KLLLKMKLLLKMKLLL',
    'KDDKMMKDDKMMKDDK',
    'MMMMMMMMMMMMMMMM',
]
BEESWAX_BLOCK_P = {
    'M': (196, 138, 40, 255), 'K': (120, 76, 20, 255), 'L': (228, 176, 66, 255),
    'H': (250, 214, 120, 255), 'D': (146, 96, 26, 255),
}

BLOCKS = {
    'ledger_desk': (DESK_TOP, DESK_TOP_P, DESK_SIDE, DESK_SIDE_P),
    'wax_press': (PRESS_TOP, PRESS_TOP_P, PRESS_SIDE, PRESS_SIDE_P),
    'cold_cellar': (CELLAR_TOP, CELLAR_TOP_P, CELLAR_SIDE, CELLAR_SIDE_P),
    'contract_board': (BOARD_TOP, BOARD_TOP_P, BOARD_SIDE, BOARD_SIDE_P),
    'trade_post': (POST_TOP, POST_TOP_P, POST_SIDE, POST_SIDE_P),
    'beeswax_block': (BEESWAX_BLOCK, BEESWAX_BLOCK_P, BEESWAX_BLOCK, BEESWAX_BLOCK_P),
}

# -------------------------------------------------------------------- render


def from_grid(grid, palette):
    assert len(grid) == 16, len(grid)
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    px = img.load()
    for y, row in enumerate(grid):
        assert len(row) == 16, (y, row, len(row))
        for x, ch in enumerate(row):
            if ch == '.':
                continue
            px[x, y] = palette[ch]
    return img


def main():
    for name, (grid, palette) in ITEMS.items():
        from_grid(grid, palette).save(OUT / f'item_{name}.png')
    for name, (tg, tp, sg, sp) in BLOCKS.items():
        from_grid(tg, tp).save(OUT / f'block_{name}_top.png')
        from_grid(sg, sp).save(OUT / f'block_{name}_side.png')
    print('textures written to', OUT)


if __name__ == '__main__':
    main()
