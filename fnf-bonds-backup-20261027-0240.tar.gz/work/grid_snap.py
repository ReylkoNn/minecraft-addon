#!/usr/bin/env python3
"""Grid-snap extraction: detect the NN sprite's native texel grid, take each native
texel's median colour (no cross-texel blending => no mud), place on a 32x32 canvas.
Minecraft renders 32x32 item textures pixel-crisp at GUI scale 2+, so the in-game
look matches the generation source."""
import pathlib
import statistics

from PIL import Image

SRC = pathlib.Path('/home/user/work/texsrc')
OUT = pathlib.Path('/home/user/work/texnn32')
OUT.mkdir(parents=True, exist_ok=True)

NAMES = ['beeswax', 'chitin', 'chitin_plate', 'frost_vial', 'wax_seal', 'mead',
         'ledger_book', 'route_map']


def runs_lengths(vals):
    out = []
    cur = 1
    for i in range(1, len(vals)):
        if vals[i] == vals[i - 1]:
            cur += 1
        else:
            if cur >= 2:
                out.append(cur)
            cur = 1
    if cur >= 2:
        out.append(cur)
    return out


def process(path):
    img = Image.open(path).convert('RGBA')
    w, h = img.size
    px = img.load()
    bg = px[0, 0]
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if abs(r - bg[0]) < 90 and abs(g - bg[1]) < 90 and abs(b - bg[2]) < 90:
                px[x, y] = (r, g, b, 0)
    img = img.crop(img.getbbox())
    w, h = img.size
    px = img.load()

    def rough(x, y):
        r, g, b, a = px[x, y]
        return (r // 24, g // 24, b // 24, 1 if a else 0)

    hs, vs = [], []
    for y in range(0, h, 3):
        hs += runs_lengths([rough(x, y) for x in range(w)])
    for x in range(0, w, 3):
        vs += runs_lengths([rough(x, y) for y in range(h)])
    t = round((statistics.median(hs) + statistics.median(vs)) / 2)
    # keep the source aspect ratio: longest side = 32 texels
    if w >= h:
        gw, gh = 32, max(1, round(32 * h / w))
    else:
        gh, gw = 32, max(1, round(32 * w / h))
    grid = Image.new('RGBA', (gw, gh), (0, 0, 0, 0))
    gp = grid.load()
    for j in range(gh):
        y0, y1 = j * h / gh, (j + 1) * h / gh
        for i in range(gw):
            x0, x1 = i * w / gw, (i + 1) * w / gw
            rs = gs = bs = n = 0
            tot = 0
            for y in range(int(y0), min(h, int(y1) + 1)):
                for x in range(int(x0), min(w, int(x1) + 1)):
                    r, g, b, a = px[x, y]
                    tot += 1
                    if a:
                        rs += r
                        gs += g
                        bs += b
                        n += 1
            if tot and n / tot >= 0.45:
                gp[i, j] = (rs // n, gs // n, bs // n, 255)
    canvas = Image.new('RGBA', (32, 32), (0, 0, 0, 0))
    canvas.paste(grid, ((32 - gw) // 2, (32 - gh) // 2), grid)
    return canvas, (gw, gh), t


def is_fringe(c):
    r, g, b, a = c
    return a > 0 and r > g + 15 and b > g + 30


def main():
    for name in NAMES:
        cands = sorted(SRC.glob(f'item_{name}.*'))
        sprite, dims, t = process(cands[0])
        px = sprite.load()
        fixes = 0
        for y in range(32):
            for x in range(32):
                if is_fringe(px[x, y]):
                    repl = None
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < 32 and 0 <= ny < 32:
                            c = px[nx, ny]
                            if c[3] and not is_fringe(c):
                                repl = c
                                break
                    px[x, y] = repl if repl else (0, 0, 0, 0)
                    fixes += 1
        sprite.save(OUT / f'item_{name}.png')
        print(f'{name}: native grid {dims[0]}x{dims[1]} (texel ~{t}px), fringe {fixes}')


if __name__ == '__main__':
    main()
