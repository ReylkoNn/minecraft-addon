#!/usr/bin/env python3
"""Post-process NN-generated sprite sources into clean 16x16 RGBA game textures:
background key by corner colour -> bbox crop -> alpha-weighted area downscale to
<=16 texels (transparent pixels contribute nothing, so no pink fringe) -> hard alpha ->
colours kept 1:1 from the source -> centre on a 16x16 canvas. No manual edits."""
import pathlib

from PIL import Image

SRC = pathlib.Path('/home/user/work/texsrc')
OUT = pathlib.Path('/home/user/work/texnn')
OUT.mkdir(parents=True, exist_ok=True)

NAMES = ['beeswax', 'chitin', 'chitin_plate', 'frost_vial', 'wax_seal', 'mead',
         'ledger_book', 'route_map']


def dist(c1, c2):
    return sum((a - b) ** 2 for a, b in zip(c1[:3], c2[:3])) ** 0.5


def process(path):
    img = Image.open(path).convert('RGBA')
    w, h = img.size
    px = img.load()
    corners = [px[0, 0], px[w - 1, 0], px[0, h - 1], px[w - 1, h - 1]]
    bg = tuple(sum(c[i] for c in corners) // 4 for i in range(4))
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            px[x, y] = (r, g, b, 0 if dist((r, g, b), bg) < 90 else 255)
    img = img.crop(img.getbbox())
    bw, bh = img.size
    scale = min(16 / bw, 16 / bh)
    tw, th = max(1, round(bw * scale)), max(1, round(bh * scale))
    src = img.load()
    small = Image.new('RGBA', (tw, th), (0, 0, 0, 0))
    sp = small.load()
    for ty in range(th):
        y0 = ty * bh // th
        y1 = max(y0 + 1, (ty + 1) * bh // th)
        for tx in range(tw):
            x0 = tx * bw // tw
            x1 = max(x0 + 1, (tx + 1) * bw // tw)
            sr = sg = sb = sa = 0
            n = 0
            for y in range(y0, y1):
                row = y * bw
                for x in range(x0, x1):
                    r, g, b, a = src[x, y]
                    if a:
                        sr += r
                        sg += g
                        sb += b
                        sa += a
                        n += 1
            area = (y1 - y0) * (x1 - x0)
            if n and sa / n >= 90:
                sp[tx, ty] = (sr // n, sg // n, sb // n, 255)
    canvas = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    canvas.paste(small, ((16 - tw) // 2, (16 - th) // 2), small)
    return canvas


def main():
    for name in NAMES:
        cands = sorted(SRC.glob(f'item_{name}.*'))
        if not cands:
            print('MISSING', name)
            continue
        sprite = process(cands[0])
        sprite.save(OUT / f'item_{name}.png')
        bbox = sprite.getbbox()
        print(f'{name}: content {bbox[2] - bbox[0]}x{bbox[3] - bbox[1]} from {cands[0].name}')


if __name__ == '__main__':
    main()
