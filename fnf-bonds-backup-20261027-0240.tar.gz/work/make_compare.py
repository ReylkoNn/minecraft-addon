#!/usr/bin/env python3
"""Old-placeholder vs new-texture comparison sheet (x6 zoom)."""
import pathlib

from PIL import Image, ImageDraw, ImageFont

OLD = pathlib.Path('/home/user/fnf-bonds/src/main/resources/assets/fnfbonds/textures')
NEW = pathlib.Path('/home/user/work/texhq')
OUT = NEW / 'compare.png'

try:
    FONT = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 14)
    TITLE = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 19)
except OSError:
    FONT = TITLE = ImageFont.load_default()

Z = 6
ENTRIES = [
    ('item', 'beeswax', 'item/beeswax.png', 'item_beeswax.png'),
    ('item', 'chitin', 'item/chitin.png', 'item_chitin.png'),
    ('item', 'chitin_plate', 'item/chitin_plate.png', 'item_chitin_plate.png'),
    ('item', 'frost_vial', 'item/frost_vial.png', 'item_frost_vial.png'),
    ('item', 'wax_seal', 'item/wax_seal.png', 'item_wax_seal.png'),
    ('item', 'mead', 'item/mead.png', 'item_mead.png'),
    ('item', 'ledger_book', 'item/ledger_book.png', 'item_ledger_book.png'),
    ('item', 'route_map', 'item/route_map.png', 'item_route_map.png'),
    ('block', 'ledger_desk', 'block/ledger_desk.png', 'block_ledger_desk_side.png'),
    ('block', 'wax_press', 'block/wax_press.png', 'block_wax_press_side.png'),
    ('block', 'cold_cellar', 'block/cold_cellar.png', 'block_cold_cellar_side.png'),
    ('block', 'contract_board', 'block/contract_board.png', 'block_contract_board_side.png'),
    ('block', 'trade_post', 'block/trade_post.png', 'block_trade_post_side.png'),
    ('block', 'beeswax_block', 'block/beeswax_block.png', 'block_beeswax_block_side.png'),
]


def main():
    row_h = Z * 16 + 14
    width = 700
    height = 52 + row_h * len(ENTRIES) + 16
    sheet = Image.new('RGBA', (width, height), (38, 38, 42, 255))
    draw = ImageDraw.Draw(sheet)
    draw.text((24, 12), 'old placeholder  ->  new texture (x6, nearest)',
              fill=(235, 225, 200, 255), font=TITLE)
    y = 52
    for kind, name, old_rel, new_rel in ENTRIES:
        draw.text((24, y + 24), f'{kind}: {name}', fill=(205, 205, 212, 255), font=FONT)
        old = Image.open(OLD / old_rel).convert('RGBA').resize((Z * 16, Z * 16), Image.NEAREST)
        new = Image.open(NEW / new_rel).convert('RGBA').resize((Z * 16, Z * 16), Image.NEAREST)
        for img, x in ((old, 250), (new, 430)):
            draw.rectangle([x - 3, y - 3, x + Z * 16 + 2, y + Z * 16 + 2],
                           fill=(139, 139, 139, 255))
            sheet.paste(img, (x, y), img)
        draw.text((360, y + 34), '->', fill=(150, 150, 160, 255), font=FONT)
        y += row_h
    sheet.save(OUT)
    print('compare:', OUT, sheet.size)


if __name__ == '__main__':
    main()
