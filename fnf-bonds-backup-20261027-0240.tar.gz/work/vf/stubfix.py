#!/usr/bin/env python3
"""Post-process the full-context vineflower run:
1. parse full_run.log for classes/methods that failed to decompile (OOM stubs)
2. re-decompile those classes with CFR (memory-friendly, different engine)
3. javac-check each CFR file against the full binary classpath
4. merge: full-run output.jar with stub-class .java replaced by CFR versions
   -> decompile_final_full.jar (+ inject into NFRT cache)
Only classes NOT targeted by neoform/userdev patches may be CFR-replaced;
the script aborts if a stub class appears in either patch list.
"""
import re, os, sys, subprocess, zipfile, shutil, json

WD = '/home/user/work/vf/full'
LOG = f'{WD}/full_run.log'
SRC = '/home/user/.cache/gradle/caches/neoformruntime/intermediate_results/preProcessJar_dad447fdce426e4e05a84a2eff47da4c9f24f251_output.jar'
VFOUT = f'{WD}/output.jar'
CFR = '/home/user/work/vf/cfr.jar'
JAVA = '/home/user/.cache/jdk25/bin/java'
JAVAC = '/home/user/.cache/jdk25/bin/javac'
CPFILE = '/home/user/work/vf/cfr_cp_full.txt'
FINAL = '/home/user/work/vf/decompile_final_full.jar'
CACHE = '/home/user/.cache/gradle/caches/neoformruntime/intermediate_results/decompile_7b35e5ff231ac4d752f1f4bfd421f6a745ca2059_output.jar'
PATCHLIST = '/tmp/userdev_patchlist.txt'
VANILLA_PATCHES = '/tmp/nf/patches'

def failed_classes():
    txt = open(LOG, errors='replace').read()
    cls = set()
    for m in re.finditer(r"(?:Method \S+ .*? in class|Class) ([\w/$.]+) couldn't be", txt):
        cls.add(m.group(1).replace('.', '/'))
    return sorted(cls)

def check_not_patched(classes):
    bad = []
    ud = open(PATCHLIST).read() if os.path.exists(PATCHLIST) else ''
    for c in classes:
        simple = c.split('/')[-1]
        if simple in ud:
            bad.append(c)
        for root, _, files in os.walk(VANILLA_PATCHES):
            for f in files:
                if f == simple + '.java.patch':
                    bad.append(c)
    return sorted(set(bad))

def cfr_fix(classes):
    os.makedirs(f'{WD}/cfr_fix', exist_ok=True)
    # mini jar with the failed classes (+ inner classes)
    src = zipfile.ZipFile(SRC)
    mini = f'{WD}/stub_mini.jar'
    with zipfile.ZipFile(mini, 'w', zipfile.ZIP_STORED) as z:
        for n in src.namelist():
            if not n.endswith('.class'):
                continue
            outer = n[:-6].split('$')[0]
            if outer in classes:
                z.writestr(n, src.read(n))
    cp = open(CPFILE).read().strip()
    rc = subprocess.call([JAVA, '-Xmx1100m', '-XX:+UseSerialGC', '-jar', CFR, mini,
                          '--extraclasspath', cp, '--outputdir', f'{WD}/cfr_fix',
                          '--comments', 'false'], cwd=WD)
    print('cfr rc', rc)
    return rc

def javac_check(classes):
    cp = open(CPFILE).read().strip()
    files = [f'{WD}/cfr_fix/{c}.java' for c in classes]
    files = [f for f in files if os.path.exists(f)]
    os.makedirs('/tmp/stubtest', exist_ok=True)
    r = subprocess.run([JAVAC, '-J-Xmx512m', '-proc:none', '-nowarn', '-d', '/tmp/stubtest',
                        '-cp', cp, *files], capture_output=True, text=True)
    errs = [l for l in r.stdout.splitlines() if 'error:' in l]
    print('javac errors:', len(errs))
    for l in errs[:20]:
        print('  ', l)
    return len(errs) == 0, files

def merge(classes):
    zin = zipfile.ZipFile(VFOUT)
    repl = {}
    for c in classes:
        p = f'{WD}/cfr_fix/{c}.java'
        if os.path.exists(p):
            repl[c + '.java'] = open(p, 'rb').read()
    n_repl = 0
    with zipfile.ZipFile(FINAL, 'w', zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename in repl:
                data = repl[item.filename]
                n_repl += 1
            zout.writestr(item, data)
        # add any CFR files whose vf entry was missing entirely
        have = set(zin.namelist())
        for name, data in repl.items():
            if name not in have:
                zout.writestr(name, data)
                n_repl += 1
    print('merged, replaced:', n_repl, 'final size:', os.path.getsize(FINAL))

def main():
    classes = failed_classes()
    print('failed classes:', len(classes))
    for c in classes:
        print('  ', c)
    if not classes:
        shutil.copy(VFOUT, FINAL)
        print('no stubs; final = vf output')
    else:
        patched = check_not_patched(classes)
        if patched:
            print('ABORT: stub classes are patch targets:', patched)
            sys.exit(2)
        cfr_fix(classes)
        ok, files = javac_check(classes)
        if not ok:
            print('ABORT: CFR output does not compile; fix manually then re-run merge')
            sys.exit(3)
        merge(classes)
    shutil.copy(FINAL, CACHE)
    print('injected into NFRT cache:', CACHE, os.path.getsize(CACHE))

if __name__ == '__main__':
    main()
