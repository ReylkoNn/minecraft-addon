#!/usr/bin/env bash
# ============================================================================
# REBUILD.sh — полное восстановление конвейера декомпиляции MC 26.2 с нуля
# (после перезапуска песочницы, когда ~/.cache стёрт).
# Запускать по шагам, НЕ одним куском: каждый шаг помечен. Ожидаемое общее
# время: ~40-60 мин (основное — прогрев кеша gradle и 5 closure-прогонов).
# Все артефакты-ингредиенты лежат в /home/user/work/vf/ (в бэкапе).
# ============================================================================
set -x
VF=/home/user/work/vf
PROJ=/home/user/fnf-bonds
NEOFORM_ZIP_REL=caches/modules-2/files-2.1/net.neoforged/neoform/26.2-2/3d2a141ade741ddf729e22f48db391c9b3f5da0/neoform-26.2-2.zip
GUH=/home/user/.cache/gradle
PRE=$GUH/caches/neoformruntime/intermediate_results/preProcessJar_dad447fdce426e4e05a84a2eff47da4c9f24f251_output.jar

# ---- ШАГ 1: JDK 25 ----------------------------------------------------------
mkdir -p /home/user/.cache/jdk25
curl -sfL "https://api.adoptium.net/v3/binary/latest/25/ga/linux/x64/jdk/hotspot/normal/eclipse" \
  | tar -xz -C /home/user/.cache/jdk25 --strip-components=1
/home/user/.cache/jdk25/bin/java -version
chmod +x $PROJ/gradlew

# ---- ШАГ 2: прогрев кеша + патч neoform zip на лету ------------------------
# Градл скачает зависимости; как только появится neoform zip — патчим его
# (jvmargs decompile -> [] и --thread-count=1 ПЕРЕД -cfg=, порядок важен!).
# Затем NFRT дойдёт до decompile и запустит vineflower с -Xmx из env;
# vineflower нужно убить (он не нужен — декомпилим сами батчами).
cd $PROJ
GRADLE_USER_HOME=$GUH JAVA_HOME=/home/user/.cache/jdk25 \
JAVA_TOOL_OPTIONS=-Xmx500m \
  ./gradlew createMinecraftArtifacts --no-daemon \
  -Dorg.gradle.jvmargs="-Xmx384m -XX:MaxMetaspaceSize=256m" \
  -Dorg.gradle.workers.max=1 --console=plain > /tmp/warm.log 2>&1 &
GPID=$!
# ждём появления zip и патчим
for i in $(seq 1 240); do
  [ -f "$GUH/$NEOFORM_ZIP_REL" ] && break; sleep 5
done
python3 - <<'PY'
import zipfile, json, shutil, os
p = '/home/user/.cache/gradle/caches/modules-2/files-2.1/net.neoforged/neoform/26.2-2/3d2a141ade741ddf729e22f48db391c9b3f5da0/neoform-26.2-2.zip'
d = '/tmp/nf'; shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
zipfile.ZipFile(p).extractall(d)
cfg = json.load(open(d + '/config.json'))
fn = cfg['functions']['decompile']
fn['jvmargs'] = []
args = [a for a in fn['args'] if a != '--thread-count=1']
i = next(k for k, a in enumerate(args) if a.startswith('-cfg='))
args.insert(i, '--thread-count=1')
fn['args'] = args
json.dump(cfg, open(d + '/config.json', 'w'), indent=1)
os.remove(p); shutil.make_archive('/tmp/nf-patched', 'zip', d); shutil.copy('/tmp/nf-patched.zip', p)
print('neoform zip patched')
PY
# ждём запуска vineflower и убиваем его (патч zip к этому моменту уже применён)
for i in $(seq 1 240); do
  pgrep -f "[C]onsoleDecompiler" && { pkill -9 -f "[C]onsoleDecompiler"; break; }; sleep 5
done
wait $GPID   # градл упадёт — это ожидаемо
ls -la $PRE  # preProcessJar должен быть в кеше

# ---- ШАГ 3: classpath-файл для CFR/javac -----------------------------------
python3 - <<'PY'
paths = []
mf = '/home/user/fnf-bonds/build/tmp/createMinecraftArtifacts/nfrt_artifact_manifest.properties'
for line in open(mf):
    line = line.strip()
    if '=' in line and not line.startswith('#'):
        k, v = line.split('=', 1)
        if v.endswith('.jar'):
            paths.append(v.replace('\\:', ':'))
paths.insert(0, '/home/user/.cache/gradle/caches/neoformruntime/intermediate_results/preProcessJar_dad447fdce426e4e05a84a2eff47da4c9f24f251_output.jar')
open('/home/user/work/vf/cfr_cp_full.txt', 'w').write(':'.join(dict.fromkeys(paths)))
print('cp jars:', len(paths))
PY

# ---- ШАГ 4: батчи (недостающие: 00 03 04 05; ~2 мин) -----------------------
cd $VF && python3 /home/user/work/vf_runner.py 0 3 4 5

# ---- ШАГ 5: CFR-починка BlockStateData (~1 мин) -----------------------------
cd $VF && python3 cfr_fix.py "$PRE"

# ---- ШАГ 6: closure-прогоны для 114 patch-целей (~8-10 мин) -----------------
cd $VF && python3 big_runner.py

# ---- ШАГ 7: сборка финального jar (~10 с) -----------------------------------
cd $VF && python3 merge_final.py "$PRE" $VF/decompile_final2.jar

# ---- ШАГ 8: инъекция в кеш NFRT ---------------------------------------------
IR=$GUH/caches/neoformruntime/intermediate_results
cp $VF/decompile_final2.jar $IR/decompile_7b35e5ff231ac4d752f1f4bfd421f6a745ca2059_output.jar
cp $VF/decompile_7b35e5ff231ac4d752f1f4bfd421f6a745ca2059.txt $IR/decompile_7b35e5ff231ac4d752f1f4bfd421f6a745ca2059.txt
# ВАЖНО: если ключ decompile_... изменился (config другой) — поймать новый ключ
# из verbose-лога (build.gradle: neoFormRuntime.verbose=true печатает "Cache Key:")
# и переименовать оба файла соответственно.

# ---- ШАГ 9: сборка мода ------------------------------------------------------
cd $PROJ && GRADLE_USER_HOME=$GUH JAVA_HOME=/home/user/.cache/jdk25 \
JAVA_TOOL_OPTIONS="-Xmx1100m -XX:+UseSerialGC" \
  ./gradlew build --no-daemon \
  -Dorg.gradle.jvmargs="-Xmx1200m -XX:MaxMetaspaceSize=320m -XX:+UseSerialGC" \
  -Dorg.gradle.workers.max=1 --console=plain
# ОЖИДАНИЕ: decompile/patch/applyNeoforgePatches/transformSources проходят;
# recompile (ECJ) может упасть на GlBuffer.java (JEP513 preview) — см. HANDOFF §"Следующие шаги".
