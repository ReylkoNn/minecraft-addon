#!/usr/bin/env python3
"""Sequentially decompile the 5 closure runs (run_plan.json) with vineflower.
Logs: run_N.log, outputs: big_N.jar. Prints a summary line per run."""
import json, subprocess, os, re, time, sys

WD = '/home/user/work/vf'
SRC = '/home/user/.cache/gradle/caches/neoformruntime/intermediate_results/preProcessJar_dad447fdce426e4e05a84a2eff47da4c9f24f251_output.jar'
VF = '/home/user/.cache/gradle/caches/modules-2/files-2.1/org.vineflower/vineflower/1.12.0/85570609a0a5941a7d2918b6260b209de810f66f/vineflower-1.12.0.jar'
VFP = '/home/user/.cache/gradle/caches/modules-2/files-2.1/net.neoforged/vineflower-plugins/0.1.6/84857083964b98ac94f8d124f401c2b2d86839ab/vineflower-plugins-0.1.6.jar'
FLAGS = ['--decompile-inner', '--remove-bridge', '--decompile-generics', '--ascii-strings',
         '--remove-synthetic', '--include-classpath', '--ignore-invalid-bytecode',
         '--bytecode-source-mapping', '--dump-code-lines', '--indent-string=    ',
         '--log-level=WARN', '--thread-count=1']

def main():
    plan = json.load(open(f'{WD}/run_plan.json'))
    start = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    for i, run in enumerate(plan):
        if i < start:
            continue
        out = f'{WD}/big_{i}.jar'
        log = f'{WD}/run_{i}.log'
        if os.path.exists(out):
            os.remove(out)
        names = run['classes']
        onlys = ['-only=' + ','.join(names[j:j+300]) for j in range(0, len(names), 300)]
        cmd = ['/home/user/.cache/jdk25/bin/java', '-Xmx1200m', '-XX:+UseSerialGC',
               '-cp', f'{VF}:{VFP}',
               'org.jetbrains.java.decompiler.main.decompiler.ConsoleDecompiler',
               *FLAGS, *onlys, '-cfg=./libraries.txt', SRC, out]
        t0 = time.time()
        with open(log, 'w') as lf:
            try:
                rc = subprocess.call(cmd, stdout=lf, stderr=subprocess.STDOUT, cwd=WD, timeout=2400)
            except subprocess.TimeoutExpired:
                rc = 'TIMEOUT'
        dt = time.time() - t0
        txt = open(log, errors='replace').read()
        stubs = re.findall(r"(?:Method \S+ .*? in class|Class) ([\w/$.]+) couldn't be", txt)
        size = os.path.getsize(out) if os.path.exists(out) else -1
        print(f'run {i}: rc={rc} {dt:.0f}s closure={len(names)} targets={len(run["targets"])} out={size}B stubs={len(stubs)}', flush=True)
        for s in sorted(set(stubs)):
            print('   STUB:', s, flush=True)
    print('ALL RUNS DONE', flush=True)

if __name__ == '__main__':
    main()
