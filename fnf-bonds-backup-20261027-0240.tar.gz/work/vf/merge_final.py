#!/usr/bin/env python3
"""Assemble the final decompile jar (= NFRT decompile node output):
  resources (non-.class entries) from preProcessJar
  + .java from batch runs out_00..out_06.jar (7055 outer classes, 1100/batch)
  + CFR-fixed BlockStateData.java (cfr_fix/)
  + closure-run replacements for the 114 patch-reject targets (big_0..big_4.jar per run_plan.json)
Usage: merge_final.py <preProcessJar> <out_final.jar>
Verifies: 7055 .java entries, all 114 targets replaced, no vf stub markers (except CFR banner)."""
import zipfile, json, sys, os, re

WD = '/home/user/work/vf'
SRC, DST = sys.argv[1], sys.argv[2]

batches = json.load(open(f'{WD}/batches.json'))
expected = {c + '.java' for b in batches for c in b}

sources = {}
# 1) CFR override
cfr = f'{WD}/cfr_fix/net/minecraft/util/datafix/fixes/BlockStateData.java'
sources['net/minecraft/util/datafix/fixes/BlockStateData.java'] = open(cfr, 'rb').read()
# 2) batch outputs
for i in range(7):
    f = f'{WD}/out_{i:02d}.jar'
    z = zipfile.ZipFile(f)
    for n in z.namelist():
        if n.endswith('.java') and n not in sources:
            sources[n] = z.read(n)
    z.close()
# 3) closure replacements (114 targets)
plan = json.load(open(f'{WD}/run_plan.json'))
replaced = 0
for i, run in enumerate(plan):
    f = f'{WD}/big_{i}.jar'
    z = zipfile.ZipFile(f)
    have = set(z.namelist())
    for t in run['targets']:
        assert t in have, (i, t)
        sources[t] = z.read(t)
        replaced += 1
    z.close()
print('closure replacements:', replaced)

missing = expected - set(sources)
assert not missing, f'missing {len(missing)}: {sorted(missing)[:5]}'
bad = [n for n, b in sources.items()
       if re.search(rb"Couldn't be decompiled|couldn't be decompiled", b)]
print('stub markers in:', bad)

zin = zipfile.ZipFile(SRC)
with zipfile.ZipFile(DST, 'w', zipfile.ZIP_DEFLATED) as zout:
    for n in zin.namelist():
        if not n.endswith('.class'):
            zout.writestr(n, zin.read(n))
    for n in sorted(sources):
        zout.writestr(n, sources[n])
print('written:', DST, os.path.getsize(DST), 'java entries:', len(sources))
