#!/usr/bin/env python3
"""CFR-fix for BlockStateData (the only class vineflower cannot decompile at <=1.2GB heap).
Produces cfr_fix/net/minecraft/util/datafix/fixes/BlockStateData.java, applies the 3 known
mechanical generic fixes, and javac-verifies it against the full binary classpath.
Run from /home/user/work/vf. Requires: cfr.jar, cfr_cp_full.txt, SRC jar path as argv[1]."""
import zipfile, os, subprocess, sys

WD = '/home/user/work/vf'
SRC = sys.argv[1]  # preProcessJar_..._output.jar
CLS = 'net/minecraft/util/datafix/fixes/BlockStateData'

src = zipfile.ZipFile(SRC)
names = [n for n in src.namelist() if n.startswith(CLS) and n.endswith('.class')]
with zipfile.ZipFile(f'{WD}/bsd_mini.jar', 'w', zipfile.ZIP_STORED) as out:
    for n in names:
        out.writestr(n, src.read(n))
print('mini jar classes:', len(names))

subprocess.run(['rm', '-rf', f'{WD}/cfr_fix'], check=True)
cp = open(f'{WD}/cfr_cp_full.txt').read().strip()
rc = subprocess.call(['/home/user/.cache/jdk25/bin/java', '-Xmx1100m', '-XX:+UseSerialGC',
                      '-jar', f'{WD}/cfr.jar', f'{WD}/bsd_mini.jar',
                      '--extraclasspath', cp, '--outputdir', f'{WD}/cfr_fix',
                      '--comments', 'false'], cwd=WD)
print('cfr rc', rc)

p = f'{WD}/cfr_fix/{CLS}.java'
s = open(p).read()
fixes = [
 ('private static final Object2IntMap<Dynamic<?>> ID_BY_OLD = (Object2IntMap)DataFixUtils.make((Object)new Object2IntOpenHashMap(), map -> map.defaultReturnValue(-1));',
  'private static final Object2IntMap<Dynamic<?>> ID_BY_OLD = DataFixUtils.make(new Object2IntOpenHashMap<Dynamic<?>>(), map -> map.defaultReturnValue(-1));'),
 ('private static final Object2IntMap<String> ID_BY_OLD_NAME = (Object2IntMap)DataFixUtils.make((Object)new Object2IntOpenHashMap(), map -> map.defaultReturnValue(-1));',
  'private static final Object2IntMap<String> ID_BY_OLD_NAME = DataFixUtils.make(new Object2IntOpenHashMap<String>(), map -> map.defaultReturnValue(-1));'),
 ('ID_BY_OLD_NAME.putIfAbsent((Object)name, id);',
  'ID_BY_OLD_NAME.putIfAbsent(name, id);'),
]
for old, new in fixes:
    assert old in s, old[:60]
    s = s.replace(old, new)
open(p, 'w').write(s)
print('3 mechanical fixes applied')

os.makedirs('/tmp/bsdtest', exist_ok=True)
r = subprocess.run(['/home/user/.cache/jdk25/bin/javac', '-J-Xmx512m', '-proc:none', '-nowarn',
                    '-d', '/tmp/bsdtest', '-cp', cp, p], capture_output=True, text=True)
errs = [l for l in r.stdout.splitlines() if 'error:' in l]
print('javac errors:', len(errs))
for l in errs[:10]:
    print(' ', l)
sys.exit(1 if errs else 0)
