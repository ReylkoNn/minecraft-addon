#!/usr/bin/env python3
"""Compute the -only closure for a set of target .java paths:
every MC class whose simple name (outer or nested segment) appears as a
Capitalized token in any target file, plus the targets themselves.
Usage: closure.py <merged_jar> <out_list_file> <target_path>...
Writes sorted outer-class names (jar paths, no .java) to out_list_file.
"""
import zipfile, re, sys

SRC = '/home/user/.cache/gradle/caches/neoformruntime/intermediate_results/preProcessJar_dad447fdce426e4e05a84a2eff47da4c9f24f251_output.jar'

def main():
    merged = sys.argv[1]
    outfile = sys.argv[2]
    targets = sys.argv[3:]
    src = zipfile.ZipFile(SRC)
    # simple name -> outer classes
    simple = {}
    for n in src.namelist():
        if not n.endswith('.class'):
            continue
        base = n[:-6]
        outer = base.split('$')[0]
        segs = outer.split('/')
        names = {segs[-1]}
        for part in base.split('/')[ -1].split('$'):
            names.add(part)
        for nm in names:
            simple.setdefault(nm, set()).add(outer)
    mz = zipfile.ZipFile(merged)
    closure = set()
    tok_re = re.compile(r'[A-Za-z_$][A-Za-z0-9_$]*')
    for t in targets:
        outer = t[:-5] if t.endswith('.java') else t
        if outer.endswith('.java'):
            outer = outer[:-5]
        closure.add(outer)
        text = mz.read(t).decode('utf-8', errors='replace')
        for tok in tok_re.findall(text):
            if not tok[0].isupper() or tok.isupper():
                continue
            closure.update(simple.get(tok, ()))
    out = sorted(closure)
    open(outfile, 'w').write('\n'.join(out) + '\n')
    print('targets:', len(targets), 'closure classes:', len(out))

if __name__ == '__main__':
    main()
