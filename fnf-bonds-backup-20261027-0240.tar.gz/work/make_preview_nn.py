#!/usr/bin/env python3
"""Sheet: NN-processed 16x16 items on inventory slots (x8), same at x4 on dark,
and the hand-drawn fallback set on slots for comparison."""
import pathlib

from PIL import Image, ImageDraw, ImageFont

NN = pathlib.Path('/home/user/work/texnn')
HAND = pathlib.Path('/home/user/work/texhq')
OUT = NN / 'preview_nn.png'

try:
    FONT = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 15)
    TITLE = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 20)
except OSError:
    FONT = TITLE = ImageFont.load_default()

ITEMS = ['beeswax', 'chitin', 'chitin_plate', 'frost_vial', 'wax_seal', 'mead',
         'ledger_book', 'route_map']


def slot(draw, x, y, size):
    draw.rectangle([x, y, x + size - 1, y + size - 1], fill=(139, 139, 139, 255))
    draw.line([x, y, x + size - 1, y], fill=(55, 55, 55, 255))
    draw.line([x, y, x, y + size - 1], fill=(55, 55, 55, 255))
    draw.line([x, y + size - 1, x + size - 1, y + size - 1], fill=(255, 255, 255, 255))
    draw.line([x + size - 1, y, x + size - 1, y + size - 1], fill=(255, 255, 255, 255))


def row(sheet, draw, y, folder, zoom, slots=True, label=''):
    draw.text((30, y - 20), label, fill=(160, 160, 170, 255), font=FONT)
    cell = 16 * zoom
    for i, name in enumerate(ITEMS):
        x = 30 + i * (cell + 22)
        if slots:
            slot(draw, x, y, cell)
        sprite = Image.open(folder / f'item_{name}.png').resize((cell, cell), Image.NEAREST)
        sheet.paste(sprite, (x, y), sprite)
        if slots:
            draw.text((x + 2, y + cell + 6), name, fill=(210, 210, 215, 255), font=FONT)
    return cell


def main():
    width = 8 * (128 + 22) + 40
    height = 52 + (128 + 40) + (64 + 30) + (128 + 30) + 20
    sheet = Image.new('RGBA', (width, height), (38, 38, 42, 255))
    draw = ImageDraw.Draw(sheet)
    draw.text((30, 12), 'fnfbonds items: NN source, post-processed to 16x16',
              fill=(235, 225, 200, 255), font=TITLE)
    y = 52
    c = row(sheet, draw, y, NN, 8, True, 'on inventory slots, x8 (NN)')
    y += c + 46
    c = row(sheet, draw, y, NN, 4, False, 'x4 on dark (NN)')
    y += c + 30
    c = row(sheet, draw, y, HAND, 8, True, 'hand-drawn fallback set, x8')
    sheet.save(OUT)
    print('sheet:', OUT, sheet.size)


if __name__ == '__main__':
    main()
