#!/usr/bin/env python3
"""Draws the 16x16 placeholder-quality-but-legible textures for fnfbonds.
Pixel art is defined as ASCII grids; '.' is transparent."""
import pathlib

from PIL import Image

A = pathlib.Path('/home/user/fnf-bonds/src/main/resources/assets/fnfbonds')
BLOCK_TEX = A / 'textures/block'
ITEM_TEX = A / 'textures/item'


def from_grid(grid, palette, scale=1):
    img = Image.new('RGBA', (16 * scale, 16 * scale), (0, 0, 0, 0))
    px = img.load()
    for y, row in enumerate(grid):
        for x, ch in enumerate(row[:16]):
            if ch == '.' or ch not in palette:
                continue
            for dy in range(scale):
                for dx in range(scale):
                    px[x * scale + dx, y * scale + dy] = palette[ch]
    return img


def save(img, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    img.save(path)
    print('  wrote', path.name)


WOOD = {'d': (86, 54, 28, 255), 'm': (122, 79, 41, 255), 'l': (154, 104, 57, 255),
        'k': (58, 36, 19, 255), '.': None}

# ---------------------------------------------------------------- ledger desk
DESK_GRID = [
    'kkkkkkkkkkkkkkkk',
    'kllllllllllllllk',
    'klmmmmmmmmmmmmlk',
    'klmkkkkkkkkkmmlk',
    'klmkbbbbbbkmmmlk',
    'klmkbggggbkmmmlk',
    'klmkbgyygbkmmmlk',
    'klmkbgyygbkmmmlk',
    'klmkbggggbkmmmlk',
    'klmkbbbbbbkmmmlk',
    'klmkkkkkkkkkmmlk',
    'klmmmmmmmmmmmmlk',
    'kllllllllllllllk',
    'kdddddmmmmdddddk',
    'kdkkdkkkkkdkkkdk',
    'kkkkkkkkkkkkkkkk',
]
DESK_PAL = dict(WOOD)
DESK_PAL.update({'b': (72, 40, 30, 255), 'g': (196, 164, 96, 255), 'y': (238, 208, 120, 255)})

# -------------------------------------------------------------- contract board
BOARD_GRID = [
    'kkkkkkkkkkkkkkkk',
    'kmmmmmmmmmmmmmmk',
    'kmppppppppppppmk',
    'kmpwwwwwpppwwwwk',
    'kmpwggggwprrwwwk',
    'kmpwwwwwppppwwwk',
    'kmppllllppwwwwwk',
    'kmpwwwwwppwwwwwk',
    'kmpwwwwwppwwwwwk',
    'kmppllllppwwwwwk',
    'kmpwwwwwppwwwwwk',
    'kmpwwwwwppwwwwwk',
    'kmmmmmmmmmmmmmmk',
    'kdkkdkkkkkdkkkdk',
    'kdkkdkkkkkdkkkdk',
    'kkkkkkkkkkkkkkkk',
]
BOARD_PAL = dict(WOOD)
BOARD_PAL.update({'p': (120, 84, 48, 255), 'w': (222, 208, 170, 255),
                  'g': (150, 150, 150, 255), 'r': (200, 70, 60, 255)})

# ------------------------------------------------------------------ trade post
POST_GRID = [
    '................',
    '.kkkkkkkkkkkkk..',
    '.kggggggggggk...',
    '.kgemmmmmegk....',
    '.kgemmmmmegk....',
    '.kgggggggggk....',
    '.kkkkkmmkkkk....',
    '......mm........',
    '......mm........',
    '.....kmmk.......',
    '.....kmmk.......',
    '.....kmmk.......',
    '.....kmmk.......',
    '....kkmmkk......',
    '....kllllk......',
    '....kkkkkk......',
]
POST_PAL = dict(WOOD)
POST_PAL.update({'g': (96, 66, 36, 255), 'e': (60, 190, 110, 255)})

# -------------------------------------------------------------------- wax press
PRESS_GRID = [
    'kkkkkkkkkkkkkkkk',
    'kggggggggggggggk',
    'kgssssssssssssgk',
    'kgssddssddssddgk',
    'kgssssssssssssgk',
    'kgssssaaaassssgk',
    'kgsssaayyaasssgk',
    'kgsssaayyaasssgk',
    'kgssssaaaassssgk',
    'kgssssssssssssgk',
    'kgllllllllllllgk',
    'kgllmmmmmmmmllgk',
    'kgllmmmmmmmmllgk',
    'kgssddssddssddgk',
    'kggggggggggggggk',
    'kkkkkkkkkkkkkkkk',
]
PRESS_PAL = {'k': (40, 40, 46, 255), 'g': (126, 128, 138, 255), 's': (168, 172, 182, 255),
             'd': (104, 106, 116, 255), 'a': (170, 120, 50, 255), 'y': (238, 208, 120, 255),
             'l': (122, 79, 41, 255), 'm': (86, 54, 28, 255)}

# ------------------------------------------------------------------ cold cellar
CELLAR_GRID = [
    'kkkkkkkkkkkkkkkk',
    'kllllllllllllllk',
    'klbbbbbbbbbbbblK'.replace('K', 'k'),
    'klbffbbffbbffblk',
    'klbffbbffbbffblk',
    'klbbbbbbbbbbbblk',
    'klmmmmmmmmmmmmLk'.replace('L', 'l'),
    'klbbbbbbbbbbbblk',
    'klbffbbffbbffblk',
    'klbffbbffbbffblk',
    'klbbbbbbbbbbbblk',
    'kllllllllllllllk',
    'kkkkkkkkkkkkkkkk',
    'kdddkkkkkkkdddkk',
    'kdddkkkkkkkdddkk',
    'kkkkkkkkkkkkkkkk',
]
CELLAR_PAL = dict(WOOD)
CELLAR_PAL.update({'b': (150, 205, 235, 255), 'f': (225, 245, 255, 255)})

# ---------------------------------------------------------------- beeswax block
WAXBLOCK_GRID = [
    'aaaaaaaaaaaaaaaa',
    'aabbaaaaaabbaaaa',
    'abyybaaaaabyybaa',
    'abyybaaaaabyybaa',
    'aabbaaaaaabbaaaa',
    'aaaaaaaaaaaaaaaa',
    'aaaaaabbaaaaaaaa',
    'aaaaaabyybaaaaaa',
    'aaaaaabyybaaaaaa',
    'aaaaaabbaaaaaaaa',
    'aaaaaaaaaaaaaaaa',
    'aabbaaaaaabbaaaa',
    'abyybaaaaabyybaa',
    'abyybaaaaabyybaa',
    'aabbaaaaaabbaaaa',
    'aaaaaaaaaaaaaaaa',
]
WAXBLOCK_PAL = {'a': (226, 178, 66, 255), 'b': (196, 148, 48, 255), 'y': (248, 214, 116, 255)}

# ------------------------------------------------------------------------ items
BEESWAX_GRID = [
    '................',
    '................',
    '....aaaaaa......',
    '...ayyyyyya.....',
    '..ayyyyyyyyya...',
    '..ayyyywyyyya...',
    '.ayyyyyyyyyyya..',
    '.ayyywyyyyyyyaa.',
    '.ayyyyyyyyyyyya.',
    '.ayyyyyyyyyyyya.',
    '..ayyyyyyyyyya..',
    '..ayyyyyyyyya...',
    '...abbbbbba.....',
    '....aaaaaa......',
    '................',
    '................',
]
BEESWAX_PAL = {'a': (168, 124, 34, 255), 'y': (240, 202, 96, 255), 'w': (255, 244, 200, 255),
               'b': (140, 100, 24, 255)}

CHITIN_GRID = [
    '................',
    '..........d.....',
    '.........ddd....',
    '........dcdcd...',
    '.......dccccd...',
    '......dccchcd...',
    '.....dcccchcd...',
    '....dcccccchd...',
    '...dccccccchd...',
    '..dcccccchhd....',
    '..dcccchhd......',
    '...dchhd........',
    '....dd..........',
    '................',
    '................',
    '................',
]
CHITIN_PAL = {'d': (30, 44, 44, 255), 'c': (62, 96, 92, 255), 'h': (110, 150, 140, 255)}

CHITIN_PLATE_GRID = [
    '................',
    '..dddddddddddd..',
    '.dccchhhhhhhccd.',
    '.dchhhhhhhhhhcd.',
    '.dchhhggggghhcd.',
    '.dchhgggggghhcd.',
    '.dchhgggggghhcd.',
    '.dchhgggggghhcd.',
    '.dchhgggggghhcd.',
    '.dchhgggggghhcd.',
    '.dchhhgggghhhcd.',
    '.dchhhhhhhhhhcd.',
    '.dccchhhhhhhccd.',
    '..dddddddddddd..',
    '................',
    '................',
]
CHITIN_PLATE_PAL = {'d': (26, 38, 38, 255), 'c': (58, 90, 86, 255), 'h': (92, 132, 124, 255),
                    'g': (140, 184, 172, 255)}

FROST_VIAL_GRID = [
    '................',
    '......ddd.......',
    '......dgd.......',
    '......dgd.......',
    '.....dgggd......',
    '.....dwwwd......',
    '....dwwwwwd.....',
    '....dwffwwd.....',
    '....dwffwwd.....',
    '....dwffwwd.....',
    '....dwffwwd.....',
    '....dwffwwd.....',
    '.....dwwwd......',
    '......ddd.......',
    '................',
    '................',
]
FROST_VIAL_PAL = {'d': (150, 190, 210, 255), 'g': (210, 232, 240, 255), 'w': (238, 248, 255, 255),
                  'f': (128, 198, 236, 255)}

WAX_SEAL_GRID = [
    '................',
    '.....rrrrrr.....',
    '...rrwwwwwwrr...',
    '..rwyyyyyyyywr..',
    '.rwyggrrggyyw r.'.replace(' ', ''),
    '.rwyr rrr ryw r'.replace(' ', ''),
    '.rwyrrrrrrrryw r'.replace(' ', ''),
    '.rwyrrddddrrywr.',
    '.rwyrrddddrrywr.',
    '.rwyrrrrrrrrywr.',
    '.rwyrkkkkkkywr..',
    '.rwyggkkkkggywr.',
    '..rwyyyyyyyywr..',
    '...rrwwwwwwrr...',
    '.....rrrrrr.....',
    '................',
]
WAX_SEAL_PAL = {'r': (110, 26, 26, 255), 'w': (150, 40, 38, 255), 'y': (190, 60, 52, 255),
                'g': (220, 92, 74, 255), 'd': (96, 20, 20, 255), 'k': (70, 14, 14, 255)}

MEAD_GRID = [
    '................',
    '....kkkkkk......',
    '...klllllk......',
    '...klwwwlk......',
    '...klwwwlk......',
    '..kklwwwlkkk....',
    '.klllwwwlllkk...',
    '.klwwwwwlwwlk...',
    '.klwwwwwwwwlk...',
    '.klwwwwwwwwlk...',
    '.klwwwwwwwwlk...',
    '.klwwwwwwwwlk...',
    '.kkllwwwwllkk...',
    '..kkllllllkk....',
    '...kkkkkkkk.....',
    '................',
]
MEAD_PAL = {'k': (72, 44, 20, 255), 'l': (126, 82, 38, 255), 'w': (226, 168, 56, 255)}

LEDGER_BOOK_GRID = [
    '................',
    '..kkkkkkkkkkkk..',
    '.kbbbbbbbbbbbpk.',
    '.kbwwwwwwwwbbpk.',
    '.kbwggggggwbppk.',
    '.kbwgyyyygwbppk.',
    '.kbwgyyyygwbppk.',
    '.kbwggggggwbppk.',
    '.kbwwwwwwwwbppk.',
    '.kbwwwwwwwwbpk..',
    '.kbbbbbbbbbbk...',
    '..kkkkkkkkkk....',
    '................',
    '................',
    '................',
    '................',
]
LEDGER_PAL = {'k': (44, 28, 16, 255), 'b': (110, 62, 32, 255), 'w': (232, 220, 190, 255),
              'g': (196, 164, 96, 255), 'y': (238, 208, 120, 255), 'p': (240, 232, 208, 255)}

ROUTE_MAP_GRID = [
    '................',
    '.pppppppppppppp.',
    '.pwwwwwwwwwwwwp.',
    '.pwwrrrrwwwwwwp.',
    '.pwrrwwrrwwwwwp.',
    '.pwrwwwwrrwwwwp.',
    '.pwrwwwwwrrwwwp.',
    '.pwwwwgwwwwrwwp.',
    '.pwwwwwwwrrwwwp.',
    '.pwbbbbwwwwrwwp.',
    '.pwwwwwwwwwrwwp.',
    '.pwwwwwwwwggggp.',
    '.pwwwwwwwwwwwwp.',
    '.pppppppppppppp.',
    '................',
    '................',
]
MAP_PAL = {'p': (128, 100, 62, 255), 'w': (226, 210, 170, 255), 'r': (196, 66, 52, 255),
           'g': (74, 132, 74, 255), 'b': (86, 120, 170, 255)}

BLOCK_ART = [
    ('ledger_desk', DESK_GRID, DESK_PAL),
    ('contract_board', BOARD_GRID, BOARD_PAL),
    ('trade_post', POST_GRID, POST_PAL),
    ('wax_press', PRESS_GRID, PRESS_PAL),
    ('cold_cellar', CELLAR_GRID, CELLAR_PAL),
    ('beeswax_block', WAXBLOCK_GRID, WAXBLOCK_PAL),
]
ITEM_ART = [
    ('beeswax', BEESWAX_GRID, BEESWAX_PAL),
    ('chitin', CHITIN_GRID, CHITIN_PAL),
    ('chitin_plate', CHITIN_PLATE_GRID, CHITIN_PLATE_PAL),
    ('frost_vial', FROST_VIAL_GRID, FROST_VIAL_PAL),
    ('wax_seal', WAX_SEAL_GRID, WAX_SEAL_PAL),
    ('mead', MEAD_GRID, MEAD_PAL),
    ('ledger_book', LEDGER_BOOK_GRID, LEDGER_PAL),
    ('route_map', ROUTE_MAP_GRID, MAP_PAL),
]

print('block textures:')
for name, grid, pal in BLOCK_ART:
    save(from_grid(grid, pal), BLOCK_TEX / f'{name}.png')
print('item textures:')
for name, grid, pal in ITEM_ART:
    save(from_grid(grid, pal), ITEM_TEX / f'{name}.png')
