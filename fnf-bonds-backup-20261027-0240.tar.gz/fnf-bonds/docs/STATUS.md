# Bonds & Ledger — implementation status (v0.1.0)

What is actually in the jar, what is deliberately deferred, and which Minecraft 26.2 / NeoForge
26.2.0.93 APIs were verified while building it. This document is the bridge between
[`GDD.md`](GDD.md) (design) and the code.

## Build status

```
./gradlew build        BUILD SUCCESSFUL
build/libs/fnfbonds-0.1.0.jar
```

Toolchain: Gradle 9.2.1, ModDevGradle 2.0.148, NeoForge 26.2.0.93, Minecraft 26.2, Java 25.
No mappings are used (Minecraft ships Mojang names from 26.1 onward); every signature in this
project was verified against the patched Minecraft sources.

## Verification

| Level | Result |
|---|---|
| `./gradlew build` | BUILD SUCCESSFUL — `build/libs/fnfbonds-0.1.0.jar` |
| Dedicated server boot (NeoForge 26.2.0.93 + Friends&Foes 5.0.3 + Resourceful Lib) | `[Bonds & Ledger] loaded. Friends&Foes present: true` … `Done`! — no registry, datapack, recipe, tag, advancement or lang errors |
| Headless economy self-test (`debug/SelfTest`, `./gradlew runServer -PselfTest`) | **44 passed / 0 failed**, deterministic (see below) |
| Client boot (Xvfb + llvmpipe, GL 4.5) | mod and F&F load, resources reload, title screen reached, no client-side errors |
| Client GUI (`debug/ClientSelfTest`, `./gradlew runClient -PclientTest`) | **7 screenshots, 0 failures** in `run/screenshots/`: all five ledger tabs, the HUD in a live world and the ledger opened in-world |

### The client self-test

A GUI can compile, boot and still be unusable — overlapping text, a button outside the panel, a tab
that never refreshes. `debug/ClientSelfTest` (gated on `-Dfnfbonds.clienttest=true`) renders the real
thing and writes PNGs of the framebuffer: it waits for the title screen (dismissing the first-run
accessibility screen), opens `LedgerScreen` on each of the five tabs over a hand-built snapshot
(`debug/LedgerFixture`), then opens the newest save — or, when there is none, asks vanilla to build a
flat test world through its own create-world screen — injects a HUD snapshot, shoots the HUD and the
ledger in-world, logs one summary line and stops the client.

Useful details learned the hard way:

* deadlines are wall clock, not ticks — on a software renderer the resource reload alone takes minutes
  while the client still ticks twenty times a second;
* a fresh `run/` directory parks on `AccessibilityOnboardingScreen`, which waits for a click nobody is
  going to make;
* opening an existing save is an order of magnitude cheaper than creating one; creating a world inside
  the client on a 2 GB machine never finished in eight minutes, while a headless dedicated server
  builds the same world in seconds (the harness therefore reuses `run/saves/*` when present);
* screenshots are grabbed from `gameRenderer.mainRenderTarget()` at client-tick time, i.e. the
  framebuffer still holds the last fully drawn frame; the "Loading terrain" overlay covers the first
  seconds in a world, so the HUD is shot again once the world settles (same file name, last copy wins).

### What the screenshots caught (and what was fixed)

* the panel was 252 px wide: Russian localisation strings collided with buttons and overflowed the
  border → the panel is now 288x216 with a status strip and a footer action row;
* per-row action buttons left no room for the row text → lists are selected by clicking a row (or with
  the arrow keys) and acted on from the footer; the footer keeps tab, selection and amount;
* `Component.withStyle(...)` silently overrides the colour argument of `GuiGraphicsExtractor.text`, so
  market prices never turned red/green → styles removed where a dynamic colour is intended;
* contract targets printed as `friendsandfoes:iceologer` → the namespace is stripped on display;
* the HUD ignored the configured corner (`hud.corner`) → it now honours all four corners;
* every server answer replaced the open screen and threw the player back to the first tab →
  `ClientPayloadHandler` now feeds the snapshot to the open screen via `LedgerScreen.update`;
* plain items had no models in 26.2: item models live in `assets/<ns>/items/*.json` now, not only in
  `models/item/*.json` (eight definitions added);
* the economy self-test passed or failed on the luck of the seeded contract roll — it completed
  whichever contract it accepted, but only a DELIVERY contract can be completed from the inventory
  (the others measure live world state) and only a completed contract pays the wax seal the caravan
  dispatch needs → the test now picks (or forges) a deliverable contract and tops up the wheat.

## Module 1 — village economy: implemented

| System | Code | State |
|---|---|---|
| Settlements (found, radius, anchors, routes) | `economy/Settlement`, `economy/EconomyData`, `block/Anchor`, `block/LedgerDeskBlock` | done |
| Bonds / standing, 6 tiers, decay, grudges, kinship | `economy/Standing`, `economy/PlayerRecord`, `economy/Actions` | done |
| Market index: 12 commodities, pressure, decay, drift, clamping | `core/Commodity`, `Settlement.multiplier/price/apply*Pressure` | done |
| Contracts: 8 archetypes, seeded daily roll, tiers, expiry, re-roll for seals | `economy/ContractGenerator`, `economy/Contract`, `economy/ContractType` | done |
| Caravans: travel time by distance, ambushes, escort kills, lost loot | `economy/Caravan`, `EconomyTicker.tickCaravans/spawnAmbush`, `Actions.sendCaravan/collectCaravan/claimLostLoot` | done |
| Projects: 9 shared upgrades paid in contribution | `economy/Project`, `Actions.buildProject` | done |
| Threat: raider/hostile pressure, watchtower, lighting | `EconomyTicker.updateThreat` | done |
| Production: wax press (hopper-friendly), cold cellar | `block/WaxPressBlock(+Entity)`, `block/ColdCellarBlock(+Entity)`, `block/ContainerBlockEntity` | done |
| Items: beeswax, chitin, chitin plate, frost vial, wax seal, mead, ledger book, route map | `registry/ModItems` | done |
| GUI: one screen, five tabs, snapshot-driven | `client/LedgerScreen`, `economy/LedgerSnapshot`, `network/*` | done |
| HUD: bond, contribution, seals, threat, top market movers | `client/BondsHud` | done |
| Commands: `/bonds …` | `command/BondsCommand` | done |
| Config: common + client, per-module switches | `FnfBondsConfig` | done |
| Beekeeper trade injection (data-driven, no code hook) | `data/friendsandfoes/tags/villager_trade/beekeeper/level_1..4.json` + `data/fnfbonds/villager_trade/…` | done |
| Tags: commodities, donations, press inputs, light sources, friendly/hostile/grudge/livestock mobs | `data/fnfbonds/tags/**` | done |
| Recipes (17), loot tables (6), advancements (9), lang EN + RU (197 keys) | `data/fnfbonds/**`, `assets/fnfbonds/lang/**` | done |
| Placeholder 16×16 textures (generated) | `assets/fnfbonds/textures/**` | done — replace with real art |

## Reserved for later modules (v2–v4)

`companion/`, `faction/`, `delve/` packages do not exist yet; the module switches
(`MODULE_COMPANION`, `MODULE_FACTION`, `MODULE_DELVE`) are already in the config so the roadmap in
`GDD.md` can be filled in without touching existing code. Also deferred by decision:

* `sealed_contract` token item (v1.1) — contracts are currently pure data, which is simpler to sync.
* A new villager profession — the beekeeper trade pool is extended through datapack tags instead,
  which needs no code and no mixin.

## Minecraft 26.2 API notes (verified, non-obvious)

These are the places where 26.x differs from the 1.21.x tutorials most mods are written against:

* **Blocks and items must know their own registry id.** `BlockBehaviour.Properties` and
  `Item.Properties` both have `setId(ResourceKey)` and the constructors throw `"Block id not set"` /
  `"Item id not set"` without it. Register custom blocks/items through
  `DeferredRegister.Blocks#registerBlock(name, Factory, props)` and
  `DeferredRegister.Items#registerItem(name, Factory, props)`, which build the `ResourceKey` for you.
  The plain `register(name, supplier)` overload **compiles and then crashes at startup** — this was
  caught only by actually booting a server.
* **No mappings.** Real Mojang names ship in the jar; `Level`, `Identifier`, `BlockPos` etc.
* **`Registry.get(Identifier)` returns `Optional<Holder.Reference<T>>`** — use
  `.map(Holder.Reference::value).orElse(null)`.
* **NBT getters return defaults via `*Or`**: `getIntOr`, `getLongOr`, `getFloatOr`, `getStringOr`,
  `getBooleanOr`, `getCompoundOrEmpty`, `getListOrEmpty`, `ListTag.getCompoundOrEmpty(i)`,
  `ListTag.getIntOr(i, def)`. `CompoundTag.getList(key, type)` no longer takes a type.
* **`SavedData` has no `save()`** — persistence is Codec-driven
  (`SavedDataType<>(Identifier, Supplier, Codec)`); mark changes with `setDirty()`. The storage class
  is now `SavedDataStorage` and has no `setDirty()`.
* **`BlockBehaviour.onRemove` is gone.** Container block entities drop their contents themselves
  through `BlockEntity.preRemoveSideEffects(BlockPos, BlockState)`, so a `Container` BE needs no
  removal override. For side effects on break, override `Block.destroy(LevelAccessor, BlockPos,
  BlockState)`; for placement, `Block.setPlacedBy(...)` is **public**.
* **`ServerPlayer.serverLevel()` is gone** — `level()` is covariant and returns `ServerLevel`.
* **`Entity.moveTo(...)` is gone** — `setPos(x, y, z)` + `setYRot(...)`; spawn with
  `EntityType.create(Level, EntitySpawnReason)`.
* **Items: dyes were grouped.** `Items.RED_DYE` no longer exists; `Items.DYE` is a
  `ColorCollection<Item>` → `Items.DYE.pick(DyeColor.RED)`. Registry ids (`minecraft:red_dye`) are
  unchanged. `FoodProperties` is now a record `(nutrition, saturation, canAlwaysEat)` and effects
  moved to `Consumable`/`Consumables.defaultDrink().onConsume(new ApplyStatusEffectsConsumeEffect(…))`.
  `Item.use(...)` returns a plain `InteractionResult` (no `InteractionResultHolder`).
* **GUI: `GuiGraphics` is gone.** Screens implement
  `extractRenderState(GuiGraphicsExtractor, mouseX, mouseY, partialTick)`; call
  `super.extractRenderState(...)` to let widgets draw. `GuiGraphicsExtractor.fill(x0,y0,x1,y1,c)`
  takes corners but `outline(x, y, width, height, c)` takes a size. The current screen is
  `Minecraft.getInstance().gui.screen()`, and it is opened with `setScreenAndShow(...)`.
  HUD layers are `net.neoforged.neoforge.client.gui.GuiLayer` registered through
  `RegisterGuiLayersEvent`.
* **Commands: `CommandSourceStack.hasPermission(int)` is gone.** Use
  `.requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))` (the new
  `net.minecraft.server.permissions` system).
* **Networking:** `PacketDistributor` is server→client only; client→server is
  `net.neoforged.neoforge.client.network.ClientPacketDistributor.sendToServer(payload)`.
  `IPayloadContext` provides `player()` and `enqueueWork(Runnable)`.
* **No `DistExecutor`.** Client-only entry points are declared as a second
  `@Mod(value = MODID, dist = Dist.CLIENT)` class. Common registration code must not hold a method
  reference to a client class — this project routes the client handler through
  `network/PayloadBridge`, whose field the client entry point replaces at construction time.
* **No `VillagerTradesEvent`/`VillagerProfessionsEvent`.** Trades are data:
  `data/<ns>/villager_trade/<profession>/<level>/<name>.json`
  (`{"gives":{"id":…},"wants":{"count":…,"id":…},"max_uses":…,"xp":…,"reputation_discount":…}`)
  plus tag files `data/<owner-ns>/tags/villager_trade/<profession>/level_N.json` — shipping the tag
  under the *base mod's* namespace merges our trades into its pool.
* **Recipes:** ingredients are plain ids / `#tags` (HolderSet codec), not `{"item": …}` objects;
  results are `{"id": …, "count": n}`.
* **`@EventBusSubscriber(modid = …)`** has no `bus` parameter any more; the bus is resolved per
  event. Client-only subscribers add `value = Dist.CLIENT`.
* **`BlockEntityType`** has no builder: `new BlockEntityType<>(factory, validBlocks…)`.
* **Tags:** `EntityType.builtInRegistryHolder().is(TagKey<EntityType<?>>)`,
  `EntityGetter.getEntitiesOfClass(Class, AABB, Predicate)`.
* **Datapack folders are singular** in 26.x: `recipe/`, `loot_table/`, `advancement/`,
  `tags/item/`, `tags/block/`, `tags/entity_type/`, `villager_trade/`, `trade_set/`.
* `BlockPos.getCenter()` does not exist; use `Vec3i.distToCenterSqr`/`closerThan`.
  `Identifier` accessors are `getNamespace()`/`getPath()`.

## Sandbox build notes

* Minecraft 26.2 needs Java 25 (`JAVA_HOME=…/jdk25`); the sandbox default is Java 11.
* NeoFormRuntime recompiles 7055 patched sources in-process — the Gradle daemon is capped at
  `-Xmx900m` (`org.gradle.jvmargs`) and the child JVM gets its heap from
  `JAVA_TOOL_OPTIONS=-Xmx2200m`. Gradle caches live in `/home/user/.cache/gradle` (never `/tmp`,
  which is tmpfs here) and a 6 GB swapfile is required on a 2 GB box.
* Once the pipeline is warm, `./gradlew build` finishes in ~2 s.

---

## Обновление 2026-10-27 (после перезапуска песочницы)

- Текстуры (8 предметов 32×32 + 6 блоков) УСТАНОВЛЕНЫ в проект; модели cube/cube_all валидны.
- Conquer'd: полный конвейер декомпиляции MC 26.2 в 2 ГБ без swap (батчи + closure-техника + CFR + инъекция в кеш NFRT). Все патчи (144 vanilla + 882 NeoForge) легли с нулём реджектов; ECJ-рекомпайл 7055 файлов падал на РОВНО одной ошибке: GlBuffer.java JEP513 preview (flexible constructor bodies).
- План добивания: closure-прогон для GlBuffer → реинъекция → rebuild (см. /home/user/HANDOFF.md §3).
- ClientSelfTest фазы 08/09 ещё НЕ компилировались.
- Восстановление инфраструктуры с нуля: /home/user/work/vf/REBUILD.sh (пошагово).
