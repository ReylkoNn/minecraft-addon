# Friends&Foes: Bonds & Ledger (`fnfbonds`)

A deep **gameplay** addon for [Friends&Foes](https://modrinth.com/mod/friends-and-foes-forge)
(NeoForge, Minecraft **26.2**). Not a cosmetic pack: it adds a whole progression branch —
**the village economy** — on top of Friends&Foes mobs, items and the beekeeper profession.

> Module 1 of a planned four-module addon: **economy → companions → factions → delves**.
> The package layout (`core`, `economy`, and reserved `companion`, `faction`, `delve`) and the
> module switches in the config exist so the next modules can be added without touching this code.

---

## What it adds

**Settlements.** Place a **Ledger Desk** to found a settlement (radius 80 by default). Every block
inside belongs to it: it has a treasury, a shared reputation, a *threat* level and its own market
index. A settlement with no desk is leaderless.

**Bonds (standing).** Six tiers — Outcast → Stranger → Neighbor → Trusted → Elder → Patron.
Standing is **per settlement**, earned by doing things villagers care about: contracts, deliveries,
killing raiders, donating, trading, sharing mead, herding friendly mobs. It decides your prices
(Patron buys at ×0.70), contract tiers, caravan slots and credit line. It decays if you stop
showing up — and killing a settlement's protected mobs (mooblooms, crabs, penguins, tuff golems,
villagers) creates a **grudge** that can drop you to Outcast.

**A living market.** 12 commodities (grain, produce, honey & wax, livestock, timber, stone, metal,
gems, fish, frost, chitin, nether goods) with prices that move with **supply pressure**: sell 64
wheat and wheat gets cheaper; buy it all back and it gets dearer. Prices decay back toward the base
value and drift a little every day, so no settlement's market looks like another's. The multiplier
is clamped to 0.40–2.50.

**Contracts.** A **Contract Board** posts 3 procedurally rolled contracts every day from 8
archetypes: delivery, hunt, herd, apiary work, construction, lighting, escort and cleanse. Each has
a tier, an expiry (3 days), and rewards in emeralds, standing, contribution and **wax seals**.
Rolls are seeded per settlement per day — everyone in the settlement sees the same board, and
relogging does not re-roll it.

**Caravans.** Load goods at a **Trade Post** and send them to another settlement. Travel time
scales with distance; there is an 8 % base chance of an ambush on the way. Fight the ambushers off
and the cargo is intact; ignore them and it is lost (part of it can be recovered later as *lost
loot*). Escort contracts pay extra for exactly this.

**Projects.** 9 shared settlement upgrades (apiary, warehouse, watchtower, market square, deep
cellar, chitin works, curiosity museum, seal works, embassy) paid with **Contribution** — a second
currency you can only earn, never buy. Each one changes the settlement: bigger caravan capacity,
more contract slots, passive income, cheaper prices, museum payouts.

**Production chains.** The **Wax Press** (hopper-friendly, no GUI): honeycomb → beeswax, crab claw
/ barnacle tooth → **chitin**, chitin + wax → chitin plates, honey + wheat → **mead**, wax + red
dye → **wax seals**. The **Cold Cellar** distils **frost vials** from packed ice and stabilises the
settlement's frost/food prices.

**Beekeeper integration.** The addon extends Friends&Foes' own beekeeper trade pool through the
data-driven `villager_trade` tag system — no code hook, no mixin: beekeepers now buy beeswax,
chitin, chitin plates and frost vials, and sell wax seals, mead, the ledger book and a contract
board.

**HUD & GUI.** One screen (five tabs: overview, contracts, market, caravans, projects) driven by a
single snapshot packet, plus a compact HUD panel (corner configurable) that shows your bond, contribution, seals, threat
and the two commodities that moved the most — only while you are inside a settlement.

---

## Blocks and items

| Block | Purpose |
|---|---|
| Ledger Desk | founds/anchors a settlement, opens the ledger |
| Contract Board | opens the contracts tab, marks the board as built |
| Trade Post | opens the market/caravan tab, enables caravan dispatch |
| Wax Press | hopper-friendly processor (wax, chitin, mead, seals) |
| Cold Cellar | frost vial distillery + price stabiliser |
| Block of Beeswax | 9× storage |

Items: **beeswax**, **chitin**, **chitin plate**, **frost vial**, **wax seal** (contract re-rolls and
premium contracts), **mead** (drinkable; shared with a villager for standing, once a day),
**ledger book** (portable ledger), **route map**.

---

## Commands

`/bonds` (permission level 2):

```
/bonds settlement create|info|delete|rename <name>
/bonds standing <amount> [player]
/bonds threat <amount>
/bonds reroll
/bonds tick          # force the daily settlement tick
```

## Config

Common (`fnfbonds-common.toml`): module switches (`economy`, `companion`, `faction`, `delve`),
settlement radius / minimum distance / per-player limit, standing decay, grudge penalty, contract
slots, expiry, re-roll seal cost, market decay/drift/min/max, caravan base ticks and raid risk,
mob income cap, `requireFnfMobs`.

Client (`fnfbonds-client.toml`): HUD on/off, its corner and whether the HUD shows the market movers.

The GUI is verified by rendering it for real: `./gradlew runClient -PclientTest` boots the client
headlessly, opens every ledger tab and the HUD over a fixture snapshot and saves PNGs to
`run/screenshots/`. Representative frames are checked into `docs/screens/`; what they caught and fixed
is listed in `docs/STATUS.md`.

---

## Building

```bash
JAVA_HOME=<jdk25> ./gradlew build      # → build/libs/fnfbonds-0.1.0.jar
```

Minecraft 26.2 requires **Java 25**. The project uses ModDevGradle 2.0.148 / NeoForge 26.2.0.93.

## Dependencies

* Minecraft 26.2, NeoForge 26.2.0.93+
* **Friends&Foes 5.0.0+ (required)** — declared in `neoforge.mods.toml` with `ordering = AFTER`
* Resourceful Lib (pulled in by Friends&Foes)

For local development put `friendsandfoes-neoforge-*.jar` and `ResourcefulLib-*.jar` into `libs/`
(they are added as `localRuntime`, are **git-ignored** and are **not** redistributed).

### Design note: no linking against Friends&Foes

The addon never imports a Friends&Foes class. Every reference goes through the registries by
`Identifier` (`com.fnfbonds.core.FnfRefs`), guarded by presence checks, and all mob/item wiring is
data-driven through tags. This keeps the addon working when the base mod changes internals, and
keeps it clean with respect to the base mod's license.

## License

* **This addon**: MIT (code) — see `LICENSE`.
* **Friends&Foes** itself is **CC-BY-NC-ND-4.0**. Nothing from that mod is copied, remixed or
  redistributed here; the addon only *references* it by identifier at runtime.
* Placeholder textures were generated for this project and may be replaced freely.
