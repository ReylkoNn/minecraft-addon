package com.fnfbonds.registry;

import com.fnfbonds.FnfBonds;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public final class ModCreativeTabs {
    private ModCreativeTabs() {}

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FnfBonds.MODID);

    public static final Supplier<CreativeModeTab> BONDS = TABS.register("bonds", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.fnfbonds"))
            .icon(() -> new ItemStack(ModItems.LEDGER_BOOK.get()))
            .displayItems((parameters, output) -> {
                output.accept(ModItems.LEDGER_BOOK.get());
                output.accept(ModItems.LEDGER_DESK.get());
                output.accept(ModItems.CONTRACT_BOARD.get());
                output.accept(ModItems.TRADE_POST.get());
                output.accept(ModItems.WAX_PRESS.get());
                output.accept(ModItems.COLD_CELLAR.get());
                output.accept(ModItems.BEESWAX.get());
                output.accept(ModItems.BEESWAX_BLOCK.get());
                output.accept(ModItems.CHITIN.get());
                output.accept(ModItems.CHITIN_PLATE.get());
                output.accept(ModItems.FROST_VIAL.get());
                output.accept(ModItems.WAX_SEAL.get());
                output.accept(ModItems.MEAD.get());
                output.accept(ModItems.ROUTE_MAP.get());
            })
            .build());
}
