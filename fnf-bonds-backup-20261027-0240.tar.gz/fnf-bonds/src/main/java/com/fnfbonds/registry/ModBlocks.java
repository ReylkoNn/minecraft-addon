package com.fnfbonds.registry;

import com.fnfbonds.FnfBonds;
import com.fnfbonds.block.ColdCellarBlock;
import com.fnfbonds.block.ContractBoardBlock;
import com.fnfbonds.block.LedgerDeskBlock;
import com.fnfbonds.block.TradePostBlock;
import com.fnfbonds.block.WaxPressBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Block registration.
 *
 * <p>26.x blocks and items must know their own registry id (the constructor throws
 * "Block id not set" otherwise), so custom blocks go through
 * {@link DeferredRegister.Blocks#registerBlock}, which builds the {@code ResourceKey} and calls
 * {@code Properties.setId} for us. Using the plain {@code register(name, supplier)} overload is a
 * runtime crash, not a compile error — worth remembering.
 */
public final class ModBlocks {
    private ModBlocks() {}

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(FnfBonds.MODID);

    public static final DeferredBlock<LedgerDeskBlock> LEDGER_DESK = BLOCKS.registerBlock("ledger_desk",
            LedgerDeskBlock::new,
            p -> p.mapColor(MapColor.WOOD).strength(2.0F).sound(SoundType.WOOD));

    public static final DeferredBlock<ContractBoardBlock> CONTRACT_BOARD = BLOCKS.registerBlock("contract_board",
            ContractBoardBlock::new,
            p -> p.mapColor(MapColor.WOOD).strength(2.0F).sound(SoundType.WOOD));

    public static final DeferredBlock<TradePostBlock> TRADE_POST = BLOCKS.registerBlock("trade_post",
            TradePostBlock::new,
            p -> p.mapColor(MapColor.WOOD).strength(2.0F).sound(SoundType.WOOD));

    public static final DeferredBlock<WaxPressBlock> WAX_PRESS = BLOCKS.registerBlock("wax_press",
            WaxPressBlock::new,
            p -> p.mapColor(MapColor.METAL).strength(3.0F).sound(SoundType.METAL).requiresCorrectToolForDrops());

    public static final DeferredBlock<ColdCellarBlock> COLD_CELLAR = BLOCKS.registerBlock("cold_cellar",
            ColdCellarBlock::new,
            p -> p.mapColor(MapColor.ICE).strength(2.5F).sound(SoundType.WOOD).lightLevel(state -> 2));

    public static final DeferredBlock<Block> BEESWAX_BLOCK = BLOCKS.registerSimpleBlock("beeswax_block",
            p -> p.mapColor(MapColor.COLOR_YELLOW).strength(1.5F).sound(SoundType.HONEY_BLOCK));
}
