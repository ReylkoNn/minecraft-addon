package com.fnfbonds.registry;

import com.fnfbonds.FnfBonds;
import com.fnfbonds.item.LedgerBookItem;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.Consumables;
import net.minecraft.world.item.consume_effects.ApplyStatusEffectsConsumeEffect;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.List;

/**
 * Item registration. Custom items go through {@link DeferredRegister.Items#registerItem} so their
 * {@code Item.Properties} carries the registry id (26.x throws "Item id not set" otherwise).
 */
public final class ModItems {
    private ModItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(FnfBonds.MODID);

    // ------------------------------------------------------------- block items

    public static final DeferredItem<BlockItem> LEDGER_DESK =
            ITEMS.registerSimpleBlockItem("ledger_desk", ModBlocks.LEDGER_DESK);
    public static final DeferredItem<BlockItem> CONTRACT_BOARD =
            ITEMS.registerSimpleBlockItem("contract_board", ModBlocks.CONTRACT_BOARD);
    public static final DeferredItem<BlockItem> TRADE_POST =
            ITEMS.registerSimpleBlockItem("trade_post", ModBlocks.TRADE_POST);
    public static final DeferredItem<BlockItem> WAX_PRESS =
            ITEMS.registerSimpleBlockItem("wax_press", ModBlocks.WAX_PRESS);
    public static final DeferredItem<BlockItem> COLD_CELLAR =
            ITEMS.registerSimpleBlockItem("cold_cellar", ModBlocks.COLD_CELLAR);
    public static final DeferredItem<BlockItem> BEESWAX_BLOCK =
            ITEMS.registerSimpleBlockItem("beeswax_block", ModBlocks.BEESWAX_BLOCK);

    // -------------------------------------------------------------- commodities

    public static final DeferredItem<Item> BEESWAX = ITEMS.registerSimpleItem("beeswax", p -> p);
    public static final DeferredItem<Item> CHITIN = ITEMS.registerSimpleItem("chitin", p -> p);
    public static final DeferredItem<Item> CHITIN_PLATE = ITEMS.registerSimpleItem("chitin_plate", p -> p);
    public static final DeferredItem<Item> WAX_SEAL = ITEMS.registerSimpleItem("wax_seal", p -> p.stacksTo(16));
    public static final DeferredItem<Item> FROST_VIAL = ITEMS.registerSimpleItem("frost_vial", p -> p.stacksTo(16));
    public static final DeferredItem<Item> ROUTE_MAP = ITEMS.registerSimpleItem("route_map", p -> p.stacksTo(1));

    /** Mead: the social lubricant of the settlement — a cheap, once-per-day standing source. */
    public static final DeferredItem<Item> MEAD = ITEMS.registerItem("mead", Item::new,
            p -> p.stacksTo(16)
                    .craftRemainder(Items.GLASS_BOTTLE)
                    .usingConvertsTo(Items.GLASS_BOTTLE)
                    .food(new FoodProperties(2, 0.2F, false), Consumables.defaultDrink()
                            .consumeSeconds(1.6F)
                            .sound(SoundEvents.HONEY_DRINK)
                            .onConsume(new ApplyStatusEffectsConsumeEffect(List.of(
                                    new MobEffectInstance(MobEffects.HASTE, 600, 0),
                                    new MobEffectInstance(MobEffects.REGENERATION, 200, 0))))
                            .build()));

    /** The portable ledger. */
    public static final DeferredItem<LedgerBookItem> LEDGER_BOOK =
            ITEMS.registerItem("ledger_book", LedgerBookItem::new, p -> p.stacksTo(1).rarity(Rarity.UNCOMMON));
}
