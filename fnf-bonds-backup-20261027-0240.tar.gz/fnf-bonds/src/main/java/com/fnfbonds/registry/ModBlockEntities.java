package com.fnfbonds.registry;

import com.fnfbonds.FnfBonds;
import com.fnfbonds.block.ColdCellarBlockEntity;
import com.fnfbonds.block.WaxPressBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public final class ModBlockEntities {
    private ModBlockEntities() {}

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, FnfBonds.MODID);

    public static final Supplier<BlockEntityType<WaxPressBlockEntity>> WAX_PRESS =
            BLOCK_ENTITIES.register("wax_press",
                    () -> new BlockEntityType<>(WaxPressBlockEntity::new, ModBlocks.WAX_PRESS.get()));

    public static final Supplier<BlockEntityType<ColdCellarBlockEntity>> COLD_CELLAR =
            BLOCK_ENTITIES.register("cold_cellar",
                    () -> new BlockEntityType<>(ColdCellarBlockEntity::new, ModBlocks.COLD_CELLAR.get()));
}
