package com.fnfbonds;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * All tuning knobs of the addon. Split into a server-authoritative COMMON config and a
 * purely cosmetic CLIENT config.
 */
public final class FnfBondsConfig {
    private FnfBondsConfig() {}

    // ---------------------------------------------------------------- common

    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    public static final ModConfigSpec.BooleanValue MODULE_ECONOMY;
    public static final ModConfigSpec.BooleanValue MODULE_COMPANION;
    public static final ModConfigSpec.BooleanValue MODULE_FACTION;
    public static final ModConfigSpec.BooleanValue MODULE_DELVE;

    public static final ModConfigSpec.IntValue SETTLEMENT_RADIUS;
    public static final ModConfigSpec.IntValue SETTLEMENT_MIN_DISTANCE;
    public static final ModConfigSpec.IntValue SETTLEMENT_MAX_PER_PLAYER;

    public static final ModConfigSpec.BooleanValue STANDING_DECAY;
    public static final ModConfigSpec.IntValue GRUDGE_PENALTY;
    public static final ModConfigSpec.DoubleValue CONTRACT_REWARD_SCALE;
    public static final ModConfigSpec.IntValue CONTRACT_SLOTS;
    public static final ModConfigSpec.IntValue CONTRACT_EXPIRY_DAYS;
    public static final ModConfigSpec.IntValue CONTRACT_REROLL_SEALS;

    public static final ModConfigSpec.DoubleValue MARKET_DECAY;
    public static final ModConfigSpec.DoubleValue MARKET_DRIFT;
    public static final ModConfigSpec.DoubleValue MARKET_MIN;
    public static final ModConfigSpec.DoubleValue MARKET_MAX;

    public static final ModConfigSpec.IntValue CARAVAN_BASE_TICKS;
    public static final ModConfigSpec.DoubleValue CARAVAN_BASE_RISK;
    public static final ModConfigSpec.DoubleValue CARAVAN_RAID_LOSS;

    public static final ModConfigSpec.IntValue MOB_INCOME_CAP;
    public static final ModConfigSpec.BooleanValue REQUIRE_FNF_MOBS;

    public static final ModConfigSpec SPEC;

    // ---------------------------------------------------------------- client

    private static final ModConfigSpec.Builder C = new ModConfigSpec.Builder();
    public static final ModConfigSpec.BooleanValue HUD_ENABLED;
    public static final ModConfigSpec.EnumValue<HudCorner> HUD_CORNER;
    public static final ModConfigSpec.BooleanValue HUD_SHOW_MARKET;
    public static final ModConfigSpec CLIENT_SPEC;

    public enum HudCorner { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }

    static {
        B.push("modules");
        MODULE_ECONOMY = B.comment("Module 1: village economy (settlements, market, contracts, caravans).")
                .define("economy", true);
        MODULE_COMPANION = B.comment("Module 2 (planned): companions & kinship. Reserved switch.")
                .define("companion", false);
        MODULE_FACTION = B.comment("Module 3 (planned): factions & sieges. Reserved switch.")
                .define("faction", false);
        MODULE_DELVE = B.comment("Module 4 (planned): delves & guild contracts. Reserved switch.")
                .define("delve", false);
        B.pop();

        B.push("settlement");
        SETTLEMENT_RADIUS = B.comment("Radius of a settlement around its Ledger Desk, in blocks.")
                .defineInRange("radius", 80, 16, 256);
        SETTLEMENT_MIN_DISTANCE = B.comment("Minimum distance between two settlement centres.")
                .defineInRange("minDistance", 120, 32, 2048);
        SETTLEMENT_MAX_PER_PLAYER = B.comment("How many settlements a single player may found.")
                .defineInRange("maxPerPlayer", 5, 1, 64);
        B.pop();

        B.push("standing");
        STANDING_DECAY = B.comment("Slow decay of standing above 400 so reputation has to be maintained.")
                .define("decay", true);
        GRUDGE_PENALTY = B.comment("Standing lost for killing a friendly Friends&Foes mob inside a settlement.")
                .defineInRange("grudgePenalty", 10, 0, 200);
        MOB_INCOME_CAP = B.comment("Maximum number of mobs of one species that still yield passive standing income.")
                .defineInRange("mobIncomeCap", 8, 1, 64);
        B.pop();

        B.push("market");
        MARKET_DECAY = B.comment("How fast price pressure relaxes back to equilibrium each in-game day (0..1).")
                .defineInRange("decay", 0.85D, 0.1D, 1.0D);
        MARKET_DRIFT = B.comment("Random daily drift of price pressure (standard deviation).")
                .defineInRange("drift", 0.02D, 0.0D, 0.5D);
        MARKET_MIN = B.defineInRange("minMultiplier", 0.40D, 0.05D, 1.0D);
        MARKET_MAX = B.defineInRange("maxMultiplier", 2.50D, 1.0D, 10.0D);
        B.pop();

        B.push("contracts");
        CONTRACT_SLOTS = B.defineInRange("slots", 3, 1, 12);
        CONTRACT_EXPIRY_DAYS = B.defineInRange("expiryDays", 3, 1, 30);
        CONTRACT_REROLL_SEALS = B.comment("Wax seals spent to reroll the contract board manually.")
                .defineInRange("rerollSeals", 1, 0, 64);
        CONTRACT_REWARD_SCALE = B.defineInRange("rewardScale", 1.0D, 0.1D, 10.0D);
        B.pop();

        B.push("caravan");
        CARAVAN_BASE_TICKS = B.defineInRange("baseTicks", 1200, 200, 72000);
        CARAVAN_BASE_RISK = B.defineInRange("baseRisk", 0.08D, 0.0D, 1.0D);
        CARAVAN_RAID_LOSS = B.comment("Share of the payout lost when a caravan raid is not repelled in time.")
                .defineInRange("raidLoss", 0.55D, 0.0D, 1.0D);
        B.pop();

        B.push("compat");
        REQUIRE_FNF_MOBS = B.comment(
                "If true, contracts and herd goals that reference Friends&Foes mobs are skipped when the base mod "
                        + "is missing. The addon degrades gracefully instead of crashing.")
                .define("requireFnfMobs", true);
        B.pop();

        SPEC = B.build();

        C.push("hud");
        HUD_ENABLED = C.comment("Show the compact settlement HUD while standing inside a settlement.")
                .define("enabled", true);
        // top-right is where vanilla parks its tutorial toasts, so the left corner is the calmer default
        HUD_CORNER = C.defineEnum("corner", HudCorner.TOP_LEFT);
        HUD_SHOW_MARKET = C.comment("Show market price lines in the HUD (can be noisy).")
                .define("showMarket", true);
        C.pop();
        CLIENT_SPEC = C.build();
    }
}
