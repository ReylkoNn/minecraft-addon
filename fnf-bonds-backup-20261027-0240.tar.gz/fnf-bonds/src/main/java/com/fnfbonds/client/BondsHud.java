package com.fnfbonds.client;

import com.fnfbonds.FnfBondsConfig;
import com.fnfbonds.economy.Standing;
import net.minecraft.ChatFormatting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.gui.GuiLayer;

/**
 * A small always-on panel in the top-left corner while the player is inside a settlement: bond tier,
 * standing, contribution, threat and — optionally — the three market commodities that moved the most.
 */
public final class BondsHud implements GuiLayer {
    private static final int MARGIN = 4;
    private static final int WIDTH = 122;
    private static final int BG = 0x90101018;
    private static final int BORDER = 0xC06B5A2E;
    private static final int GOLD = 0xFFE8C86A;
    private static final int TEXT = 0xFFDDDDDD;
    private static final int DIM = 0xFF999999;
    private static final int GREEN = 0xFF7ED97E;
    private static final int RED = 0xFFE07A6A;
    private static final long STALE_MS = 3000L;

    @Override
    public void render(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
        CompoundTag hud = ClientPayloadHandler.hud;
        if (hud == null || !FnfBondsConfig.HUD_ENABLED.get()) return;
        if (System.currentTimeMillis() - ClientPayloadHandler.hudReceivedAt > STALE_MS) return;

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null) return;
        if (minecraft.gui.screen() instanceof LedgerScreen) return;

        boolean showMarket = FnfBondsConfig.HUD_SHOW_MARKET.get();
        int height = showMarket ? 62 : 40;
        // honour the configured corner instead of always sitting in the top-left
        FnfBondsConfig.HudCorner corner = FnfBondsConfig.HUD_CORNER.get();
        int x = corner == FnfBondsConfig.HudCorner.TOP_RIGHT || corner == FnfBondsConfig.HudCorner.BOTTOM_RIGHT
                ? minecraft.getWindow().getGuiScaledWidth() - WIDTH - MARGIN
                : MARGIN;
        int top = corner == FnfBondsConfig.HudCorner.BOTTOM_LEFT || corner == FnfBondsConfig.HudCorner.BOTTOM_RIGHT
                ? minecraft.getWindow().getGuiScaledHeight() - height - MARGIN
                : MARGIN;
        graphics.fill(x, top, x + WIDTH, top + height, BG);
        graphics.outline(x, top, WIDTH, height, BORDER);

        int y = top + 4;
        Standing tier = Standing.values()[Math.clamp(hud.getIntOr("tier", 1), 0, Standing.values().length - 1)];
        graphics.text(minecraft.font, Component.translatable("hud.fnfbonds.settlement",
                        Component.literal(hud.getStringOr("name", "?")))
                .withStyle(ChatFormatting.GOLD), x + 4, y, GOLD);
        y += 10;

        graphics.text(minecraft.font, Component.translatable(tier.translationKey())
                .append(Component.literal("  " + hud.getIntOr("standing", 0)).withStyle(ChatFormatting.GRAY)),
                x + 4, y, TEXT);
        y += 10;

        graphics.text(minecraft.font, Component.translatable("hud.fnfbonds.contribution",
                        hud.getIntOr("contribution", 0))
                .append(Component.literal("   ").withStyle(ChatFormatting.DARK_GRAY))
                .append(Component.translatable("hud.fnfbonds.seals", hud.getIntOr("seals", 0))
                        .withStyle(ChatFormatting.DARK_GRAY)),
                x + 4, y, DIM);
        y += 10;

        int threat = hud.getIntOr("threat", 0);
        int contracts = hud.getIntOr("contracts", 0);
        int mine = hud.getIntOr("contractsMine", 0);
        graphics.text(minecraft.font, Component.translatable("hud.fnfbonds.contracts", mine, contracts)
                        .withStyle(ChatFormatting.GRAY)
                        .append(Component.literal("  "))
                        .append(threatComponent(threat)),
                x + 4, y, DIM);

        if (!showMarket) return;
        y += 12;
        ListTag multipliers = hud.getListOrEmpty("multipliers");
        if (multipliers.isEmpty()) return;
        int best = 0;
        int worst = 0;
        for (int i = 1; i < multipliers.size(); i++) {
            if (multipliers.getFloatOr(i, 1f) > multipliers.getFloatOr(best, 1f)) best = i;
            if (multipliers.getFloatOr(i, 1f) < multipliers.getFloatOr(worst, 1f)) worst = i;
        }
        graphics.text(minecraft.font, marketLine(multipliers, best, true), x + 4, y, GREEN);
        graphics.text(minecraft.font, marketLine(multipliers, worst, false), x + 4, y + 9, RED);
    }

    private static Component marketLine(ListTag multipliers, int index, boolean up) {
        com.fnfbonds.core.Commodity commodity = com.fnfbonds.core.Commodity.byOrdinal(index);
        float mult = multipliers.getFloatOr(index, 1f);
        return Component.literal(up ? "▲ " : "▼ ")
                .withStyle(up ? ChatFormatting.GREEN : ChatFormatting.RED)
                .append(commodity == null ? Component.literal("?") : Component.translatable(commodity.translationKey()))
                .append(Component.literal(String.format(" x%.2f", mult)).withStyle(ChatFormatting.DARK_GRAY));
    }

    private static Component threatComponent(int threat) {
        String band = threat < 5 ? "calm" : threat < 15 ? "wary" : threat < 30 ? "tense" : "besieged";
        ChatFormatting colour = threat < 5 ? ChatFormatting.GREEN
                : threat < 15 ? ChatFormatting.YELLOW
                : threat < 30 ? ChatFormatting.GOLD : ChatFormatting.RED;
        return Component.translatable("threat.fnfbonds." + band).withStyle(colour);
    }
}
