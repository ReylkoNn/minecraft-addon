package com.fnfbonds.client;

import com.fnfbonds.FnfBonds;
import com.fnfbonds.core.ModTags;
import com.fnfbonds.network.PayloadBridge;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;

/**
 * Client-only entry point. Declared with {@code @Mod(dist = CLIENT)}, so this class — and everything
 * it pulls in, including {@code net.minecraft.client.Minecraft} — is never loaded on a dedicated
 * server.
 */
@Mod(value = FnfBonds.MODID, dist = Dist.CLIENT)
@EventBusSubscriber(modid = FnfBonds.MODID, value = Dist.CLIENT)
public final class FnfBondsClient {
    public FnfBondsClient() {
        // swap the common no-op handler for the real one before payloads are registered
        PayloadBridge.onSync = ClientPayloadHandler::handleSync;
    }

    @SubscribeEvent
    static void onClientSetup(FMLClientSetupEvent event) {
        FnfBonds.LOGGER.debug("[Bonds & Ledger] client setup complete");
    }

    @SubscribeEvent
    static void onRegisterGuiLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(ModTags.id("bonds_hud"), new BondsHud());
    }
}
