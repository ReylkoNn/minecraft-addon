package com.fnfbonds.client;

import com.fnfbonds.network.LedgerSyncPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import org.jspecify.annotations.Nullable;

/** Client side of the ledger protocol. Only ever loaded on a physical client. */
public final class ClientPayloadHandler {
    private ClientPayloadHandler() {}

    /** Last HUD snapshot, or {@code null} when the player is outside every settlement. */
    public static @Nullable CompoundTag hud;
    public static long hudReceivedAt;

    public static void handleSync(LedgerSyncPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (payload.mode() == LedgerSyncPayload.MODE_OPEN) {
                Minecraft minecraft = Minecraft.getInstance();
                // the server answers every action with a fresh snapshot: feed it to the open screen
                // instead of replacing it, or the player loses the tab, the row and the amount
                if (minecraft.gui.screen() instanceof LedgerScreen ledger) {
                    ledger.update(payload.data());
                } else {
                    minecraft.setScreenAndShow(new LedgerScreen(payload.data()));
                }
            } else {
                hud = payload.data();
                hudReceivedAt = System.currentTimeMillis();
            }
        });
    }

    public static void clearHud() {
        hud = null;
    }
}
