package com.fnfbonds.client;

import com.fnfbonds.core.Commodity;
import com.fnfbonds.economy.ContractType;
import com.fnfbonds.economy.Project;
import com.fnfbonds.economy.Standing;
import com.fnfbonds.network.LedgerActionPayload;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import org.jspecify.annotations.Nullable;

/**
 * The ledger: one screen, five tabs, driven entirely by the snapshot the server pushed.
 *
 * <p>In 26.x screens no longer implement {@code render(GuiGraphics, …)} — they extract a render
 * state instead — and there is no container menu behind this GUI. Every button is a request: the
 * server validates it, applies it and answers with a fresh snapshot, so the client is never
 * authoritative. {@link #update(CompoundTag)} applies that answer to the open screen instead of
 * replacing it, which keeps the current tab, the row selection and the amount selector.
 *
 * <p>Layout rules, all of them earned from the screenshots this screen produces under
 * {@code debug.ClientSelfTest}:
 * <ul>
 *   <li>the panel is 288x216 GUI pixels — wide enough for the long Russian strings the localisation
 *       ships with, tall enough for twelve commodity rows plus a status strip and an action row;</li>
 *   <li>lists are selected by clicking a row (or with the arrow keys) and acted on from the footer,
 *       because a button on every row leaves no room for the row's own text;</li>
 *   <li>right-aligned values are measured with {@code font.width} first and left-hand text is
 *       shortened when the two would meet — nothing may overlap.</li>
 * </ul>
 */
public class LedgerScreen extends Screen {
    private static final int W = 288;
    private static final int H = 216;
    private static final int HEADER = 24;
    /** First list row, relative to the panel top. */
    private static final int CONTENT = HEADER + 4;
    /** Status strip: two lines of context about the current selection. */
    private static final int STATUS = H - 40;
    /** Action row: buttons that act on the selection. */
    private static final int FOOTER = H - 18;
    private static final int PAD = 8;
    private static final int RIGHT = W - PAD;

    private static final int BG = 0xF2141420;
    private static final int BORDER = 0xFF6B5A2E;
    private static final int ROW = 0x28FFFFFF;
    private static final int BUILT = 0x2A408040;
    private static final int SELECTED = 0x44E8C86A;
    private static final int GOLD = 0xFFE8C86A;
    private static final int TEXT = 0xFFD8D8D8;
    private static final int DIM = 0xFF9A9A9A;
    private static final int GREEN = 0xFF7ED97E;
    private static final int RED = 0xFFE07A6A;
    private static final int AQUA = 0xFF8AD8E8;

    private static final String[] TABS = {"overview", "contracts", "market", "caravans", "projects"};
    private static final int MAX_CONTRACT_ROWS = 9;
    private static final int MAX_CARAVAN_ROWS = 5;
    private static final int MAX_ROUTE_ROWS = 3;

    private CompoundTag data;
    private int tab;
    private int amount = 8;
    private int selected = -1;
    private int routeCommodity = Commodity.HONEY.ordinal();

    public LedgerScreen(CompoundTag data) {
        super(Component.translatable("screen.fnfbonds.ledger"));
        this.data = data;
        this.tab = Math.clamp(data.getIntOr("tab", 0), 0, TABS.length - 1);
        this.selected = data.getIntOr("sel", -1);
    }

    /** Applies a fresh server snapshot to the already open ledger, keeping tab and selection. */
    public void update(CompoundTag data) {
        this.data = data;
        if (this.selected >= rowCount()) this.selected = -1;
        this.rebuildWidgets();
    }

    @Override
    public boolean isPauseScreen() {
        // the world keeps turning while you read the ledger: caravans and threats must not freeze
        return false;
    }

    private int left() {
        return (this.width - W) / 2;
    }

    private int top() {
        return (this.height - H) / 2;
    }

    // ------------------------------------------------------------------ widgets

    @Override
    protected void init() {
        int left = left();
        int top = top();
        for (int i = 0; i < TABS.length; i++) {
            final int index = i;
            this.addRenderableWidget(Button
                    .builder(Component.translatable("tab.fnfbonds." + TABS[i]), button -> {
                        this.tab = index;
                        this.selected = -1;
                        this.rebuildWidgets();
                    })
                    .bounds(left + 4 + i * 56, top + 5, 54, 14)
                    .build());
        }
        switch (this.tab) {
            case 0 -> initOverview();
            case 1 -> initContracts();
            case 2 -> initMarket();
            case 3 -> initCaravans(left, top);
            case 4 -> initProjects();
            default -> {
            }
        }
    }

    private void send(int action, int a1, int a2, int a3) {
        ClientPacketDistributor.sendToServer(new LedgerActionPayload(action, a1, a2, a3));
    }

    private Button button(String label, int x, int y, int w, int h, int action, int a1, int a2, int a3) {
        return Button.builder(Component.translatable(label), button -> send(action, a1, a2, a3))
                .bounds(x, y, w, h)
                .build();
    }

    private Button footer(String label, int x, int w, int action, int a1, int a2, int a3) {
        return button(label, left() + x, top() + FOOTER, w, 14, action, a1, a2, a3);
    }

    private void initOverview() {
        this.addRenderableWidget(footer("button.fnfbonds.donate", 6, 66,
                LedgerActionPayload.DONATE, 16, 0, 0));
        this.addRenderableWidget(footer("button.fnfbonds.credit", 76, 66,
                LedgerActionPayload.TAKE_CREDIT, 32, 0, 0));
        this.addRenderableWidget(footer("button.fnfbonds.repay", 146, 66,
                LedgerActionPayload.REPAY_CREDIT, 32, 0, 0));
        Button loot = footer("button.fnfbonds.loot", 216, 66, LedgerActionPayload.CLAIM_LOOT, 0, 0, 0);
        loot.active = !this.data.getListOrEmpty("lostLoot").isEmpty();
        this.addRenderableWidget(loot);
    }

    private void initContracts() {
        this.addRenderableWidget(footer("button.fnfbonds.reroll", 6, 100,
                LedgerActionPayload.REROLL, 0, 0, 0));
        CompoundTag contract = selectedContract();
        if (contract == null) return;
        int id = contract.getIntOr("id", -1);
        if (contract.getBooleanOr("mine", false)) {
            this.addRenderableWidget(footer("button.fnfbonds.turn_in", 112, 84,
                    LedgerActionPayload.TURN_IN_CONTRACT, id, 0, 0));
            this.addRenderableWidget(footer("button.fnfbonds.abandon", 200, 82,
                    LedgerActionPayload.ABANDON_CONTRACT, id, 0, 0));
        } else if (!contract.getBooleanOr("anyOwner", false)) {
            Button accept = footer("button.fnfbonds.accept", 112, 84,
                    LedgerActionPayload.ACCEPT_CONTRACT, id, 0, 0);
            accept.active = this.data.getIntOr("tier", 0) >= contract.getIntOr("tier", 0);
            this.addRenderableWidget(accept);
        }
    }

    private void initMarket() {
        int left = left();
        int top = top();
        int index = 0;
        for (int value : new int[] {1, 8, 32}) {
            final int picked = value;
            Button toggle = Button
                    .builder(Component.literal("x" + value), button -> {
                        this.amount = picked;
                        this.rebuildWidgets();
                    })
                    .bounds(left + 6 + index * 26, top + FOOTER, 24, 14)
                    .build();
            this.addRenderableWidget(toggle);
            index++;
        }
        int commodity = Math.max(0, this.selected);
        Button sell = footer("button.fnfbonds.sell", 112, 84, LedgerActionPayload.SELL, commodity, this.amount, 0);
        Button buy = footer("button.fnfbonds.buy", 200, 82, LedgerActionPayload.BUY, commodity, this.amount, 0);
        sell.active = this.selected >= 0;
        buy.active = this.selected >= 0;
        this.addRenderableWidget(sell);
        this.addRenderableWidget(buy);
    }

    private void initCaravans(int left, int top) {
        CompoundTag caravan = selectedCaravan();
        Button collect = footer("button.fnfbonds.collect", 6, 100, LedgerActionPayload.COLLECT_CARAVAN,
                caravan == null ? -1 : caravan.getIntOr("id", -1), 0, 0);
        collect.active = caravan != null
                && caravan.getBooleanOr("mine", false)
                && caravan.getBooleanOr("arrived", false);
        this.addRenderableWidget(collect);

        int routes = top + 100;
        this.addRenderableWidget(Button
                .builder(Component.translatable("button.fnfbonds.cycle_commodity"), button -> {
                    this.routeCommodity = (this.routeCommodity + 1) % Commodity.ALL.length;
                    this.rebuildWidgets();
                })
                .bounds(left + 6, routes, 110, 14)
                .build());

        ListTag routeList = this.data.getListOrEmpty("routes");
        for (int i = 0; i < routeList.size() && i < MAX_ROUTE_ROWS; i++) {
            this.addRenderableWidget(button("button.fnfbonds.dispatch", left + 6, routes + 18 + i * 15,
                    110, 14, LedgerActionPayload.SEND_CARAVAN, this.routeCommodity, this.amount, i));
        }
    }

    private void initProjects() {
        ListTag built = this.data.getListOrEmpty("projectsBuilt");
        boolean buildable = this.selected >= 0
                && this.selected < Project.ALL.length
                && (this.selected >= built.size() || built.getIntOr(this.selected, 0) == 0);
        Button build = footer("button.fnfbonds.build", 6, 100, LedgerActionPayload.BUILD_PROJECT,
                Math.max(0, this.selected), 0, 0);
        build.active = buildable;
        this.addRenderableWidget(build);
    }

    // ---------------------------------------------------------------- selection

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true;
        if (event.button() != 0) return false;
        int row = rowAt(event.x(), event.y());
        if (row < 0) return false;
        this.selected = this.selected == row ? -1 : row;
        this.rebuildWidgets();
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (super.keyPressed(event)) return true;
        int count = rowCount();
        if (count == 0) return false;
        if (event.isUp()) {
            this.selected = this.selected <= 0 ? count - 1 : this.selected - 1;
            this.rebuildWidgets();
            return true;
        }
        if (event.isDown()) {
            this.selected = this.selected + 1 >= count ? 0 : this.selected + 1;
            this.rebuildWidgets();
            return true;
        }
        return false;
    }

    private int rowHeight() {
        return this.tab == 2 ? 12 : 13;
    }

    private int rowCount() {
        return switch (this.tab) {
            case 1 -> Math.min(this.data.getListOrEmpty("contracts").size(), MAX_CONTRACT_ROWS);
            case 2 -> Commodity.ALL.length;
            case 3 -> Math.min(this.data.getListOrEmpty("caravans").size(), MAX_CARAVAN_ROWS);
            case 4 -> Project.ALL.length;
            default -> 0;
        };
    }

    private int rowAt(double mouseX, double mouseY) {
        int count = rowCount();
        if (count == 0) return -1;
        int left = left();
        int first = top() + CONTENT;
        if (mouseX < left + 4 || mouseX > left + W - 4) return -1;
        if (mouseY < first || mouseY >= first + count * rowHeight()) return -1;
        return (int) ((mouseY - first) / rowHeight());
    }

    private @Nullable CompoundTag selectedContract() {
        ListTag contracts = this.data.getListOrEmpty("contracts");
        return this.selected >= 0 && this.selected < contracts.size()
                ? contracts.getCompoundOrEmpty(this.selected)
                : null;
    }

    private @Nullable CompoundTag selectedCaravan() {
        ListTag caravans = this.data.getListOrEmpty("caravans");
        return this.selected >= 0 && this.selected < caravans.size()
                ? caravans.getCompoundOrEmpty(this.selected)
                : null;
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        int left = left();
        int top = top();
        graphics.fill(left, top, left + W, top + H, BG);
        graphics.outline(left, top, W, H, BORDER);
        graphics.centeredText(this.font, Component.translatable("screen.fnfbonds.ledger.title",
                Component.literal(this.data.getStringOr("name", "?"))), left + W / 2, top - 12, GOLD);

        // widgets are extracted on top of the panel, so they must come after the background
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);

        switch (this.tab) {
            case 0 -> drawOverview(graphics, left, top);
            case 1 -> drawContracts(graphics, left, top);
            case 2 -> drawMarket(graphics, left, top);
            case 3 -> drawCaravans(graphics, left, top);
            case 4 -> drawProjects(graphics, left, top);
            default -> {
            }
        }
        if (rowCount() > 0) drawStatus(graphics, left, top);
    }

    /** One list row: band, plus a gold edge and a brighter fill when it is the selected one. */
    private void band(GuiGraphicsExtractor g, int left, int index, int y, int rowHeight, int tint) {
        boolean isSelected = index == this.selected;
        g.fill(left + 4, y - 1, left + W - 4, y + rowHeight - 2, isSelected ? SELECTED : (tint == 0 ? ROW : tint));
        if (isSelected) g.fill(left + 4, y - 1, left + 6, y + rowHeight - 2, GOLD);
    }

    /** Right-aligned text whose right edge sits {@code limit} pixels from the panel's left edge. */
    private void right(GuiGraphicsExtractor g, int left, int limit, int y, Component text, int colour) {
        g.text(this.font, text, left + limit - this.font.width(text), y, colour);
    }

    private void drawOverview(GuiGraphicsExtractor g, int left, int top) {
        Standing tier = tier(this.data.getIntOr("tier", 1));
        int standing = this.data.getIntOr("standing", 0);
        Standing[] all = Standing.values();
        int next = tier.ordinal() + 1 < all.length ? all[tier.ordinal() + 1].threshold : standing;

        int x = left + PAD;
        int y = top + CONTENT + 2;
        line(g, x, y, "label.fnfbonds.tier", Component.translatable(tier.translationKey()).withStyle(ChatFormatting.GOLD));
        y += 11;
        line(g, x, y, "label.fnfbonds.standing", Component.literal(standing + " / " + next));
        y += 11;
        line(g, x, y, "label.fnfbonds.contribution", Component.literal("" + this.data.getIntOr("contribution", 0)));
        y += 11;
        line(g, x, y, "label.fnfbonds.emeralds", Component.literal("" + this.data.getIntOr("emeralds", 0)));
        y += 11;
        line(g, x, y, "label.fnfbonds.seals", Component.literal("" + this.data.getIntOr("seals", 0)));
        y += 11;
        line(g, x, y, "label.fnfbonds.bank", Component.literal(String.format("%.1f", this.data.getFloatOr("bank", 0f))));
        y += 11;
        line(g, x, y, "label.fnfbonds.credit", Component.literal(String.format("%.1f / %d",
                this.data.getFloatOr("credit", 0f), this.data.getIntOr("creditLimit", 0))));

        int x2 = left + 156;
        int y2 = top + CONTENT + 2;
        line(g, x2, y2, "label.fnfbonds.threat", threatText(this.data.getIntOr("threat", 0)));
        y2 += 11;
        line(g, x2, y2, "label.fnfbonds.day", Component.literal("" + this.data.getLongOr("day", 0L)));
        y2 += 11;
        line(g, x2, y2, "label.fnfbonds.radius", Component.literal("" + this.data.getIntOr("radius", 0)));
        y2 += 11;
        line(g, x2, y2, "label.fnfbonds.contracts_done", Component.literal("" + this.data.getIntOr("contractsDone", 0)));
        y2 += 11;
        line(g, x2, y2, "label.fnfbonds.contracts_failed", Component.literal("" + this.data.getIntOr("contractsFailed", 0)));
        y2 += 11;
        line(g, x2, y2, "label.fnfbonds.caravans_done", Component.literal("" + this.data.getIntOr("caravansDone", 0)));
        y2 += 11;
        line(g, x2, y2, "label.fnfbonds.streak", Component.literal("" + this.data.getIntOr("streak", 0)));

        int hints = top + CONTENT + 84;
        if (!this.data.getBooleanOr("anchored", false)) {
            g.text(this.font, Component.translatable("hint.fnfbonds.no_desk").withStyle(ChatFormatting.RED), x, hints, RED);
            hints += 11;
        }
        ListTag loot = this.data.getListOrEmpty("lostLoot");
        if (!loot.isEmpty()) {
            g.text(this.font, Component.translatable("hint.fnfbonds.loot", loot.size()).withStyle(ChatFormatting.AQUA),
                    x, hints, AQUA);
        }
    }

    private void drawContracts(GuiGraphicsExtractor g, int left, int top) {
        ListTag contracts = this.data.getListOrEmpty("contracts");
        int y = top + CONTENT;
        if (contracts.isEmpty()) {
            g.text(this.font, Component.translatable("hint.fnfbonds.no_contracts").withStyle(ChatFormatting.GRAY),
                    left + PAD, y + 16, DIM);
        }
        Standing playerTier = tier(this.data.getIntOr("tier", 0));
        for (int i = 0; i < contracts.size() && i < MAX_CONTRACT_ROWS; i++) {
            CompoundTag c = contracts.getCompoundOrEmpty(i);
            band(g, left, i, y, 13, 0);
            boolean mine = c.getBooleanOr("mine", false);
            boolean taken = c.getBooleanOr("anyOwner", false);
            ContractType type = ContractType.byOrdinal(c.getIntOr("type", 0));
            Component title = Component.translatable(type.titleKey());
            g.text(this.font, title, left + PAD, y + 1, mine ? GREEN : taken ? DIM : TEXT);

            Component reward = Component.translatable("label.fnfbonds.reward", c.getIntOr("em", 0), c.getIntOr("st", 0));
            int rewardX = left + RIGHT - this.font.width(reward);
            g.text(this.font, reward, rewardX, y + 1, AQUA);

            int detailX = left + PAD + this.font.width(title) + 6;
            Component detail = Component.literal(shortTarget(c.getStringOr("target", "")) + " "
                    + c.getIntOr("progress", 0) + "/" + c.getIntOr("amount", 1));
            if (!mine && !taken) {
                Standing required = tier(c.getIntOr("tier", 0));
                if (required.ordinal() > playerTier.ordinal()) {
                    detail = detail.copy()
                            .append(Component.literal("  "))
                            .append(Component.translatable("label.fnfbonds.tier_req",
                                    Component.translatable(required.translationKey())).withStyle(ChatFormatting.RED));
                }
            }
            if (detailX + this.font.width(detail) > rewardX - 4) {
                // the localisation is too long for the row: keep the numbers, drop the prose
                detail = Component.literal(c.getIntOr("progress", 0) + "/" + c.getIntOr("amount", 1));
            }
            g.text(this.font, detail, detailX, y + 1, DIM);
            y += 13;
        }
    }

    private void drawMarket(GuiGraphicsExtractor g, int left, int top) {
        ListTag prices = this.data.getListOrEmpty("prices");
        ListTag multipliers = this.data.getListOrEmpty("multipliers");
        ListTag holdings = this.data.getListOrEmpty("holdings");
        Commodity[] all = Commodity.ALL;
        int y = top + CONTENT;
        for (int i = 0; i < all.length; i++) {
            band(g, left, i, y, 12, 0);
            float price = i < prices.size() ? prices.getFloatOr(i, 1f) : 1f;
            float mult = i < multipliers.size() ? multipliers.getFloatOr(i, 1f) : 1f;
            int have = i < holdings.size() ? holdings.getIntOr(i, 0) : 0;
            g.text(this.font, Component.translatable(all[i].translationKey()), left + PAD, y + 1, TEXT);
            int priceColour = mult > 1.15f ? RED : mult < 0.9f ? GREEN : TEXT;
            g.text(this.font, Component.literal(String.format("%.1f", price)), left + 104, y + 1, priceColour);
            g.text(this.font, Component.literal("x" + String.format("%.2f", mult)), left + 138, y + 1, DIM);
            right(g, left, RIGHT, y + 1, Component.translatable("label.fnfbonds.have", have), DIM);
            y += 12;
        }
        // the amount the footer will act with, ringed where its button sits
        int chosen = this.amount == 1 ? 0 : this.amount == 8 ? 1 : 2;
        g.outline(left + 6 + chosen * 26 - 1, top + FOOTER - 1, 26, 16, GOLD);
    }

    private void drawCaravans(GuiGraphicsExtractor g, int left, int top) {
        ListTag caravans = this.data.getListOrEmpty("caravans");
        int y = top + CONTENT;
        if (caravans.isEmpty()) {
            g.text(this.font, Component.translatable("hint.fnfbonds.no_caravans").withStyle(ChatFormatting.GRAY),
                    left + PAD, y + 8, DIM);
        }
        long now = this.data.getLongOr("gameTime", 0L);
        for (int i = 0; i < caravans.size() && i < MAX_CARAVAN_ROWS; i++) {
            CompoundTag c = caravans.getCompoundOrEmpty(i);
            boolean raided = c.getBooleanOr("raided", false);
            band(g, left, i, y, 13, raided ? 0x2AE07A6A : 0);
            Commodity commodity = Commodity.byOrdinal(c.getIntOr("commodity", 0));
            Component cargo = Component.literal(c.getIntOr("amount", 0) + "x ").withStyle(ChatFormatting.GRAY)
                    .append(commodity == null ? Component.literal("?") : Component.translatable(commodity.translationKey()));
            boolean arrived = c.getBooleanOr("arrived", false);
            Component status = arrived
                    ? Component.translatable("label.fnfbonds.arrived").withStyle(ChatFormatting.GREEN)
                    : Component.translatable("label.fnfbonds.eta",
                            (int) Math.max(0, (c.getLongOr("arrive", 0L) - now) / 20L)).withStyle(ChatFormatting.GRAY);
            int statusX = left + RIGHT - this.font.width(status);

            Component name = cargo.copy()
                    .append(Component.literal(" → " + c.getStringOr("destName", "?")).withStyle(ChatFormatting.GRAY));
            if (raided) {
                name = name.copy().append(Component.literal("  ⚔ " + c.getIntOr("escortKills", 0) + "/"
                        + c.getIntOr("escortNeeded", 0)).withStyle(ChatFormatting.RED));
            }
            if (left + PAD + this.font.width(name) > statusX - 4) {
                name = cargo.copy();   // no room for the destination: the row keeps cargo and status
                if (raided) {
                    name = name.copy().append(Component.literal("  ⚔").withStyle(ChatFormatting.RED));
                }
            }
            g.text(this.font, name, left + PAD, y + 1, arrived ? GREEN : TEXT);
            g.text(this.font, status, statusX, y + 1, arrived ? GREEN : DIM);
            y += 13;
        }

        int routes = top + 100;
        Commodity cargo = Commodity.byOrdinal(this.routeCommodity);
        g.text(this.font, Component.translatable("label.fnfbonds.cargo",
                        cargo == null ? Component.literal("?") : Component.translatable(cargo.translationKey()))
                .withStyle(ChatFormatting.GOLD), left + 122, routes + 3, GOLD);

        ListTag routeList = this.data.getListOrEmpty("routes");
        if (routeList.isEmpty()) {
            g.text(this.font, Component.translatable("hint.fnfbonds.no_routes").withStyle(ChatFormatting.GRAY),
                    left + 122, routes + 21, DIM);
        }
        for (int i = 0; i < routeList.size() && i < MAX_ROUTE_ROWS; i++) {
            CompoundTag r = routeList.getCompoundOrEmpty(i);
            g.text(this.font, Component.literal(r.getStringOr("name", "?") + "  ·  " + r.getIntOr("distance", 0) + " m")
                    .withStyle(ChatFormatting.GRAY), left + 122, routes + 21 + i * 15, DIM);
        }
    }

    private void drawProjects(GuiGraphicsExtractor g, int left, int top) {
        ListTag built = this.data.getListOrEmpty("projectsBuilt");
        int y = top + CONTENT;
        Project[] all = Project.ALL;
        for (int i = 0; i < all.length; i++) {
            boolean done = i < built.size() && built.getIntOr(i, 0) != 0;
            band(g, left, i, y, 13, done ? BUILT : 0);
            g.text(this.font, Component.translatable(all[i].translationKey())
                    .withStyle(done ? ChatFormatting.GREEN : ChatFormatting.YELLOW), left + PAD, y + 1, done ? GREEN : TEXT);
            if (done) {
                right(g, left, RIGHT, y + 1, Component.translatable("label.fnfbonds.built")
                        .withStyle(ChatFormatting.GREEN), GREEN);
            } else {
                right(g, left, RIGHT, y + 1, Component.translatable("label.fnfbonds.cost",
                        all[i].contributionCost, all[i].emeraldCost).withStyle(ChatFormatting.GRAY), DIM);
            }
            y += 13;
        }
    }

    /** Two lines under the list: what the selection means, and what the buttons will do. */
    private void drawStatus(GuiGraphicsExtractor g, int left, int top) {
        int y1 = top + STATUS;
        int y2 = top + STATUS + 11;
        Component nothing = Component.translatable("label.fnfbonds.selected_none").withStyle(ChatFormatting.DARK_GRAY);
        switch (this.tab) {
            case 1 -> {
                ListTag contracts = this.data.getListOrEmpty("contracts");
                int mine = 0;
                for (int i = 0; i < contracts.size(); i++) {
                    if (contracts.getCompoundOrEmpty(i).getBooleanOr("mine", false)) mine++;
                }
                g.text(this.font, Component.translatable("label.fnfbonds.contract_slots", mine,
                        this.data.getIntOr("contractSlots", 3)).withStyle(ChatFormatting.GRAY), left + PAD, y1, DIM);
                CompoundTag c = selectedContract();
                if (c == null) {
                    g.text(this.font, nothing, left + PAD, y2, DIM);
                } else if (c.getBooleanOr("anyOwner", false) && !c.getBooleanOr("mine", false)) {
                    g.text(this.font, Component.translatable("label.fnfbonds.taken").withStyle(ChatFormatting.RED),
                            left + PAD, y2, RED);
                } else {
                    g.text(this.font, Component.translatable("label.fnfbonds.reward",
                                    c.getIntOr("em", 0), c.getIntOr("st", 0)).withStyle(ChatFormatting.AQUA),
                            left + PAD, y2, AQUA);
                    right(g, left, RIGHT, y2, Component.translatable("label.fnfbonds.expires",
                                    Math.max(0, c.getLongOr("exp", 0L) - this.data.getLongOr("day", 0L)))
                            .withStyle(ChatFormatting.GRAY), DIM);
                }
            }
            case 2 -> {
                g.text(this.font, Component.translatable("label.fnfbonds.amount_value", this.amount)
                        .withStyle(ChatFormatting.GRAY), left + PAD, y1, DIM);
                if (this.selected < 0 || this.selected >= Commodity.ALL.length) {
                    g.text(this.font, nothing, left + PAD, y2, DIM);
                    return;
                }
                ListTag holdings = this.data.getListOrEmpty("holdings");
                ListTag prices = this.data.getListOrEmpty("prices");
                int have = this.selected < holdings.size() ? holdings.getIntOr(this.selected, 0) : 0;
                float price = this.selected < prices.size() ? prices.getFloatOr(this.selected, 0f) : 0f;
                g.text(this.font, Component.translatable("label.fnfbonds.have", have).withStyle(ChatFormatting.GRAY),
                        left + PAD, y2, DIM);
                right(g, left, RIGHT, y2, Component.translatable("label.fnfbonds.sell_value",
                                String.format("%.1f", price * this.amount)).withStyle(ChatFormatting.GOLD), GOLD);
            }
            case 3 -> {
                ListTag caravans = this.data.getListOrEmpty("caravans");
                int mine = 0;
                for (int i = 0; i < caravans.size(); i++) {
                    if (caravans.getCompoundOrEmpty(i).getBooleanOr("mine", false)) mine++;
                }
                g.text(this.font, Component.translatable("label.fnfbonds.caravan_slots", mine,
                                this.data.getIntOr("caravanSlots", 1)).withStyle(ChatFormatting.GRAY),
                        left + PAD, y1, DIM);
                right(g, left, RIGHT, y1, Component.translatable("label.fnfbonds.cargo_capacity",
                        this.data.getIntOr("caravanCapacity", 0)).withStyle(ChatFormatting.GRAY), DIM);
                CompoundTag c = selectedCaravan();
                if (c == null) {
                    g.text(this.font, nothing, left + PAD, y2, DIM);
                } else {
                    boolean raided = c.getBooleanOr("raided", false);
                    Component info = Component.translatable("label.fnfbonds.payout",
                            String.format("%.1f", c.getFloatOr("payout", 0f))).withStyle(ChatFormatting.GOLD);
                    if (raided) {
                        info = info.copy()
                                .append(Component.literal("   "))
                                .append(Component.translatable("label.fnfbonds.raided",
                                                c.getIntOr("escortKills", 0), c.getIntOr("escortNeeded", 0))
                                        .withStyle(ChatFormatting.RED));
                    }
                    g.text(this.font, info, left + PAD, y2, raided ? RED : GOLD);
                }
            }
            case 4 -> {
                g.text(this.font, Component.translatable("hint.fnfbonds.projects").withStyle(ChatFormatting.DARK_GRAY),
                        left + PAD, y1, DIM);
                if (this.selected >= 0 && this.selected < Project.ALL.length) {
                    Project project = Project.ALL[this.selected];
                    g.text(this.font, Component.translatable(project.translationKey()).withStyle(ChatFormatting.GOLD),
                            left + PAD, y2, GOLD);
                    right(g, left, RIGHT, y2, Component.translatable("label.fnfbonds.cost",
                                    project.contributionCost, project.emeraldCost).withStyle(ChatFormatting.GRAY),
                            DIM);
                } else {
                    g.text(this.font, nothing, left + PAD, y2, DIM);
                }
            }
            default -> {
            }
        }
    }

    private static Standing tier(int ordinal) {
        return Standing.values()[Math.clamp(ordinal, 0, Standing.values().length - 1)];
    }

    private static Component threatText(int threat) {
        String band = threat < 5 ? "calm" : threat < 15 ? "wary" : threat < 30 ? "tense" : "besieged";
        ChatFormatting colour = threat < 5 ? ChatFormatting.GREEN
                : threat < 15 ? ChatFormatting.YELLOW
                : threat < 30 ? ChatFormatting.GOLD : ChatFormatting.RED;
        return Component.literal(threat + " ").withStyle(ChatFormatting.WHITE)
                .append(Component.translatable("threat.fnfbonds." + band).withStyle(colour));
    }

    /** {@code friendsandfoes:iceologer} reads better as {@code iceologer} on a 288 pixel wide panel. */
    private static String shortTarget(String target) {
        if (target.isEmpty()) return "";
        int separator = Math.max(target.lastIndexOf(':'), target.lastIndexOf('.'));
        String name = separator >= 0 && separator + 1 < target.length() ? target.substring(separator + 1) : target;
        return name.replace('_', ' ');
    }

    private void line(GuiGraphicsExtractor g, int x, int y, String label, Component value) {
        g.text(this.font, Component.translatable(label).withStyle(ChatFormatting.GRAY)
                .append(Component.literal(": ").withStyle(ChatFormatting.DARK_GRAY))
                .append(value), x, y, TEXT);
    }
}
