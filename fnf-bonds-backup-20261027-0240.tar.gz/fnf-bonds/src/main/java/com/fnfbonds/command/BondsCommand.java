package com.fnfbonds.command;

import com.fnfbonds.economy.Actions;
import com.fnfbonds.economy.EconomyData;
import com.fnfbonds.FnfBonds;
import com.fnfbonds.economy.ContractGenerator;
import com.fnfbonds.economy.EconomyTicker;
import com.fnfbonds.economy.Project;
import com.fnfbonds.economy.PlayerRecord;
import com.fnfbonds.economy.Settlement;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/** /bonds — debugging and pack-author tooling. All subcommands need game-master level 2. */
public final class BondsCommand {
    private BondsCommand() {}

    public static void register(RegisterCommandsEvent event) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("bonds")
                .requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                .then(Commands.literal("settlement")
                        .then(Commands.literal("create").executes(BondsCommand::createSettlement))
                        .then(Commands.literal("info").executes(BondsCommand::settlementInfo))
                        .then(Commands.literal("delete").executes(BondsCommand::deleteSettlement))
                        .then(Commands.literal("rename")
                                .then(Commands.argument("name", com.mojang.brigadier.arguments.StringArgumentType.greedyString())
                                        .executes(BondsCommand::renameSettlement))))
                .then(Commands.literal("standing")
                        .then(Commands.argument("amount", IntegerArgumentType.integer(-10000, 10000))
                                .executes(ctx -> standing(ctx, null))
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(ctx -> standing(ctx, EntityArgument.getPlayer(ctx, "player"))))))
                .then(Commands.literal("threat")
                        .then(Commands.argument("amount", IntegerArgumentType.integer(-500, 500))
                                .executes(BondsCommand::setThreat)))
                .then(Commands.literal("reroll").executes(BondsCommand::reroll))
                .then(Commands.literal("tick").executes(BondsCommand::forceTick));
        event.getDispatcher().register(root);
    }

    /** Mirrors the HUD bands: 0-4 calm, 5-14 wary, 15-29 tense, 30+ besieged. */
    private static String threatBand(int threat) {
        return threat < 5 ? "calm" : threat < 15 ? "wary" : threat < 30 ? "tense" : "besieged";
    }

    private static ServerPlayer self(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        return ctx.getSource().getPlayerOrException();
    }

    private static int createSettlement(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = self(ctx);
        ServerLevel level = player.level();
        Settlement settlement = EconomyData.get(level).createSettlement(level, player.blockPosition(), "", player.getUUID());
        if (settlement == null) {
            ctx.getSource().sendFailure(Component.translatable("chat.fnfbonds.error.cannot_found"));
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.translatable("chat.fnfbonds.settlement.founded",
                settlement.name, settlement.radius), true);
        return settlement.id;
    }

    private static int settlementInfo(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = self(ctx);
        Settlement settlement = EconomyData.at(player);
        if (settlement == null) {
            ctx.getSource().sendFailure(Component.translatable("chat.fnfbonds.error.not_in_settlement"));
            return 0;
        }
        PlayerRecord record = settlement.record(player.getUUID());
        ctx.getSource().sendSuccess(() -> Component.literal(settlement.name)
                .withStyle(ChatFormatting.GOLD)
                .append(Component.literal(" | " + Component.translatable(record.tier().translationKey()).getString()
                        + " " + record.standing + " | threat " + settlement.threat + " (" + threatBand(settlement.threat) + ")"
                        + " | contracts " + settlement.contracts.size()
                        + " | caravans " + settlement.caravans.size()
                        + " | projects " + settlement.projects.size() + "/"
                        + Project.ALL.length
                        + " | radius " + settlement.radius)
                        .withStyle(ChatFormatting.GRAY)), false);
        return 1;
    }

    private static int deleteSettlement(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = self(ctx);
        Settlement settlement = EconomyData.at(player);
        if (settlement == null) {
            ctx.getSource().sendFailure(Component.translatable("chat.fnfbonds.error.not_in_settlement"));
            return 0;
        }
        int id = settlement.id;
        EconomyData.get(player.level()).removeSettlement(id);
        ctx.getSource().sendSuccess(() -> Component.translatable("chat.fnfbonds.settlement.removed", id), true);
        return id;
    }

    private static int renameSettlement(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = self(ctx);
        Settlement settlement = EconomyData.at(player);
        if (settlement == null) {
            ctx.getSource().sendFailure(Component.translatable("chat.fnfbonds.error.not_in_settlement"));
            return 0;
        }
        String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
        settlement.name = name;
        ctx.getSource().sendSuccess(() -> Component.translatable("chat.fnfbonds.settlement.renamed", name), true);
        return 1;
    }

    private static int standing(CommandContext<CommandSourceStack> ctx, ServerPlayer target) throws CommandSyntaxException {
        ServerPlayer player = target != null ? target : self(ctx);
        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        Settlement settlement = EconomyData.at(player);
        if (settlement == null) {
            ctx.getSource().sendFailure(Component.translatable("chat.fnfbonds.error.not_in_settlement"));
            return 0;
        }
        PlayerRecord record = settlement.record(player.getUUID());
        record.addStanding(amount);
        ctx.getSource().sendSuccess(() -> Component.translatable("chat.fnfbonds.standing.changed",
                player.getScoreboardName(), amount, record.standing), true);
        return record.standing;
    }

    private static int setThreat(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = self(ctx);
        int amount = IntegerArgumentType.getInteger(ctx, "amount");
        Settlement settlement = EconomyData.at(player);
        if (settlement == null) {
            ctx.getSource().sendFailure(Component.translatable("chat.fnfbonds.error.not_in_settlement"));
            return 0;
        }
        settlement.threat = Math.clamp(settlement.threat + amount, 0, 500);
        EconomyTicker.updateThreat(player.level(), settlement);
        int threat = settlement.threat;
        ctx.getSource().sendSuccess(() -> Component.translatable("chat.fnfbonds.threat.set", threat,
                Component.translatable("threat.fnfbonds." + threatBand(threat))), true);
        return settlement.threat;
    }

    private static int reroll(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = self(ctx);
        Settlement settlement = EconomyData.at(player);
        if (settlement == null) {
            ctx.getSource().sendFailure(Component.translatable("chat.fnfbonds.error.not_in_settlement"));
            return 0;
        }
        ContractGenerator.roll(player.level(), settlement, true);
        ctx.getSource().sendSuccess(() -> Component.translatable("chat.fnfbonds.contracts.rolled"), true);
        return settlement.contracts.size();
    }

    private static int forceTick(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = self(ctx);
        ServerLevel level = player.level();
        int rolled = 0;
        for (Settlement settlement : EconomyData.get(level).settlements()) {
            if (EconomyTicker.playersInside(settlement, level.players()).isEmpty()) continue;
            EconomyTicker.updateThreat(level, settlement);
            if (ContractGenerator.roll(level, settlement, true)) rolled++;
        }
        final int count = rolled;
        FnfBonds.LOGGER.info("[bonds] forced a contract roll for {} occupied settlement(s)", count);
        ctx.getSource().sendSuccess(() -> Component.translatable("chat.fnfbonds.tick.forced"), true);
        return count;
    }
}
