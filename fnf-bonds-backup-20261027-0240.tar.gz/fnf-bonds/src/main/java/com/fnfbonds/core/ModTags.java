package com.fnfbonds.core;

import com.fnfbonds.FnfBonds;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;

/**
 * Tag keys owned by the addon. Contents live in {@code data/fnfbonds/tags/...} and may be
 * overridden by any datapack.
 */
public final class ModTags {
    private ModTags() {}

    private static TagKey<Item> item(String path) {
        return TagKey.create(Registries.ITEM, id(path));
    }

    private static TagKey<EntityType<?>> entity(String path) {
        return TagKey.create(Registries.ENTITY_TYPE, id(path));
    }

    private static TagKey<Block> block(String path) {
        return TagKey.create(Registries.BLOCK, id(path));
    }

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(FnfBonds.MODID, path);
    }

    /** Friendly Friends&amp;Foes species: herding targets, passive income, grudge on kill. */
    public static final TagKey<EntityType<?>> FRIENDLY_MOBS = entity("friendly_mobs");
    /** Hostile Friends&amp;Foes species: hunt contracts and settlement threat. */
    public static final TagKey<EntityType<?>> HOSTILE_MOBS = entity("hostile_mobs");
    /** Species whose death inside a settlement creates a grudge and costs standing. */
    public static final TagKey<EntityType<?>> GRUDGE_MOBS = entity("grudge_mobs");
    /** Species that count towards apiary/pasture contracts. */
    public static final TagKey<EntityType<?>> LIVESTOCK_MOBS = entity("livestock_mobs");

    /** Items accepted as a donation to the ledger desk. */
    public static final TagKey<Item> DONATIONS = item("donations");
    /** Fuel accepted by the wax press. */
    public static final TagKey<Item> PRESS_INPUTS = item("press_inputs");

    /** Blocks that count as a light source for LIGHT contracts. */
    public static final TagKey<Block> LIGHT_SOURCES = block("light_sources");
}
