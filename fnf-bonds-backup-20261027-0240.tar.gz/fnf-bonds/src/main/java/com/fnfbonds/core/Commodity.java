package com.fnfbonds.core;

import com.fnfbonds.FnfBonds;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.jspecify.annotations.Nullable;

/**
 * The twelve commodity groups traded by settlements. Membership is data-driven: every group is an
 * item tag ({@code data/fnfbonds/tags/item/commodity/<name>.json}) so packs can extend or replace
 * it without touching code. Friends&amp;Foes items (buttercup, crab claw, barnacle tooth, penguin
 * feather, wildfire crown fragment) are shipped inside those tags — that is what wires the base mod
 * into the economy.
 */
public enum Commodity {
    GRAIN("grain", 0.50f, 0.020f, "minecraft:wheat"),
    PRODUCE("produce", 0.60f, 0.020f, "minecraft:apple"),
    HONEY("honey", 1.20f, 0.016f, "minecraft:honeycomb"),
    LIVESTOCK("livestock", 1.00f, 0.016f, "minecraft:leather"),
    TIMBER("timber", 0.40f, 0.010f, "minecraft:oak_log"),
    STONE("stone", 0.30f, 0.006f, "minecraft:cobblestone"),
    METAL("metal", 2.00f, 0.020f, "minecraft:iron_ingot"),
    GEM("gem", 6.00f, 0.030f, "minecraft:emerald"),
    FISH("fish", 1.10f, 0.018f, "minecraft:cod"),
    FROST("frost", 1.50f, 0.020f, "minecraft:ice"),
    CHITIN("chitin", 2.50f, 0.022f, "friendsandfoes:crab_claw"),
    NETHER("nether", 4.00f, 0.026f, "minecraft:quartz");

    public static final Commodity[] ALL = values();

    public final String path;
    /** Emeralds per unit at a neutral market with neutral standing. */
    public final float basePrice;
    /** How strongly one traded unit pushes the local price pressure. */
    public final float weight;
    /** Item handed to the player when buying this commodity from the trade post. */
    public final Identifier unitItem;
    public final TagKey<Item> tag;

    Commodity(String path, float basePrice, float weight, String unitItem) {
        this.path = path;
        this.basePrice = basePrice;
        this.weight = weight;
        this.unitItem = Identifier.parse(unitItem);
        this.tag = ItemTags.create(Identifier.fromNamespaceAndPath(FnfBonds.MODID, "commodity/" + path));
    }

    public String translationKey() {
        return "commodity.fnfbonds." + this.path;
    }

    /** @return the commodity a stack belongs to, or {@code null} when the market does not deal in it. */
    public static @Nullable Commodity of(ItemStack stack) {
        if (stack.isEmpty()) return null;
        for (Commodity c : ALL) {
            if (stack.is(c.tag)) return c;
        }
        return null;
    }

    public static @Nullable Commodity byPath(String path) {
        for (Commodity c : ALL) {
            if (c.path.equals(path)) return c;
        }
        return null;
    }

    public static @Nullable Commodity byOrdinal(int ordinal) {
        return ordinal >= 0 && ordinal < ALL.length ? ALL[ordinal] : null;
    }
}
