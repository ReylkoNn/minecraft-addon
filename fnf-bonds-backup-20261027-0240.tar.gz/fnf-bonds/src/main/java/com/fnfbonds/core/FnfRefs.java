package com.fnfbonds.core;

import com.fnfbonds.FnfBonds;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.neoforged.fml.ModList;
import org.jspecify.annotations.Nullable;

/**
 * The single place that knows about Friends&amp;Foes content.
 *
 * <p>Everything is resolved lazily through the game registries by {@link Identifier}; we never
 * reference a class from the base mod. If Friends&amp;Foes is absent, renamed an id or was updated,
 * lookups simply return {@code null}/{@link Items#AIR} and the calling system skips that branch.
 */
public final class FnfRefs {
    private FnfRefs() {}

    public static Identifier fnf(String path) {
        return Identifier.fromNamespaceAndPath(FnfBonds.FNF_MODID, path);
    }

    public static boolean fnfLoaded() {
        return ModList.get() != null && ModList.get().isLoaded(FnfBonds.FNF_MODID);
    }

    // ------------------------------------------------------------- entities

    public static final Identifier MAULER = fnf("mauler");
    public static final Identifier BARNACLE = fnf("barnacle");
    public static final Identifier ICEOLOGER = fnf("iceologer");
    public static final Identifier ILLUSIONER = fnf("illusioner");
    public static final Identifier WILDFIRE = fnf("wildfire");
    public static final Identifier RASCAL = fnf("rascal");

    public static final Identifier MOOBLOOM = fnf("moobloom");
    public static final Identifier CRAB = fnf("crab");
    public static final Identifier GLARE = fnf("glare");
    public static final Identifier PENGUIN = fnf("penguin");
    public static final Identifier TUFF_GOLEM = fnf("tuff_golem");
    public static final Identifier COPPER_GOLEM = Identifier.withDefaultNamespace("copper_golem");

    public static @Nullable EntityType<?> entityType(Identifier id) {
        return BuiltInRegistries.ENTITY_TYPE.get(id).map(Holder.Reference::value).orElse(null);
    }

    public static boolean has(Identifier id) {
        return BuiltInRegistries.ENTITY_TYPE.containsKey(id);
    }

    // ---------------------------------------------------------------- items

    public static final Identifier CRAB_CLAW = fnf("crab_claw");
    public static final Identifier BARNACLE_TOOTH = fnf("barnacle_tooth");
    public static final Identifier BUTTERCUP = fnf("buttercup");
    public static final Identifier PENGUIN_FEATHER = fnf("penguin_feather");
    public static final Identifier WILDFIRE_CROWN_FRAGMENT = fnf("wildfire_crown_fragment");
    public static final Identifier TOTEM_OF_FREEZING = fnf("totem_of_freezing");
    public static final Identifier MUSIC_DISC = fnf("music_disc_around_the_corner");

    /** @return the registered item, or {@link Items#AIR} when it is not present at runtime. */
    public static Item item(Identifier id) {
        return BuiltInRegistries.ITEM.get(id).map(Holder.Reference::value).orElse(Items.AIR);
    }

    public static boolean hasItem(Identifier id) {
        return BuiltInRegistries.ITEM.get(id).map(Holder.Reference::value)
                .filter(item -> item != Items.AIR).isPresent();
    }

    // ------------------------------------------------------------ villagers

    /** The Friends&amp;Foes beekeeper profession id, used for trade injection bookkeeping. */
    public static final Identifier BEEKEEPER = fnf("beekeeper");
}
