package com.fnfbonds.item;

import com.fnfbonds.block.Anchor;
import com.fnfbonds.economy.Settlement;
import com.fnfbonds.network.Network;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * The portable ledger. Opens the same GUI as the desk when the player is inside (or close to) a
 * settlement, so a trader on the road can still check prices before committing to a caravan.
 */
public class LedgerBookItem extends Item {
    public static final double RANGE = 128.0;

    public LedgerBookItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer serverPlayer)) return InteractionResult.PASS;

        Settlement settlement = Anchor.findForPlayer(serverPlayer, RANGE);
        if (settlement == null) {
            serverPlayer.sendSystemMessage(Component.translatable("chat.fnfbonds.error.no_settlement_near",
                    (int) RANGE).withStyle(ChatFormatting.RED));
            return InteractionResult.FAIL;
        }
        Network.openLedger(serverPlayer, settlement, Anchor.TAB_OVERVIEW);
        return InteractionResult.CONSUME;
    }
}
