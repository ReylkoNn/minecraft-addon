package com.fnfbonds;

import com.fnfbonds.command.BondsCommand;
import com.fnfbonds.network.Network;
import com.fnfbonds.registry.ModBlockEntities;
import com.fnfbonds.registry.ModBlocks;
import com.fnfbonds.registry.ModCreativeTabs;
import com.fnfbonds.registry.ModItems;
import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import org.slf4j.Logger;

/**
 * Friends&Foes: Bonds &amp; Ledger — a deep gameplay addon for Friends&amp;Foes.
 *
 * <p>Module 1 (this release): the village economy — settlements, standing/bonds, a living market
 * index, procedural contracts, caravans and production chains built on top of Friends&amp;Foes
 * mobs and items.
 *
 * <p>The addon never links against Friends&amp;Foes classes: every reference goes through the game
 * registries by {@link net.minecraft.resources.Identifier} (see {@link com.fnfbonds.core.FnfRefs}),
 * which keeps us compatible with the CC-BY-NC-ND license of the base mod and resilient to its
 * updates.
 */
@Mod(FnfBonds.MODID)
public class FnfBonds {
    public static final String MODID = "fnfbonds";
    public static final String FNF_MODID = "friendsandfoes";
    public static final Logger LOGGER = LogUtils.getLogger();

    public FnfBonds(IEventBus modEventBus, ModContainer modContainer) {
        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);
        ModCreativeTabs.TABS.register(modEventBus);

        modEventBus.addListener(Network::register);

        NeoForge.EVENT_BUS.addListener(BondsCommand::register);

        modContainer.registerConfig(ModConfig.Type.COMMON, FnfBondsConfig.SPEC);
        modContainer.registerConfig(ModConfig.Type.CLIENT, FnfBondsConfig.CLIENT_SPEC);

        LOGGER.info("[Bonds & Ledger] loaded. Friends&Foes present: {}", ModList.get().isLoaded(FNF_MODID));
    }
}
