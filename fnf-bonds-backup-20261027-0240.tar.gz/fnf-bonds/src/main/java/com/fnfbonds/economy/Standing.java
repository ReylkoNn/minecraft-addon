package com.fnfbonds.economy;

/**
 * Standing tiers ("Bonds"). Standing is earned per settlement and drives prices, contract tiers,
 * the credit line and the number of caravan slots.
 */
public enum Standing {
    OUTCAST(-1000, "outcast", 1.25f, 0, 0),
    STRANGER(0, "stranger", 1.00f, 1, 0),
    NEIGHBOR(100, "neighbor", 0.95f, 1, 4),
    TRUSTED(300, "trusted", 0.88f, 2, 16),
    ELDER(600, "elder", 0.80f, 3, 32),
    PATRON(1000, "patron", 0.70f, 4, 64);

    public final int threshold;
    public final String key;
    /** Multiplied into market prices: below 1.0 is a discount, above 1.0 a surcharge. */
    public final float priceMultiplier;
    public final int caravanSlots;
    public final int creditLimit;

    Standing(int threshold, String key, float priceMultiplier, int caravanSlots, int creditLimit) {
        this.threshold = threshold;
        this.key = key;
        this.priceMultiplier = priceMultiplier;
        this.caravanSlots = caravanSlots;
        this.creditLimit = creditLimit;
    }

    public String translationKey() {
        return "standing.fnfbonds." + this.key;
    }

    /** Contract tier unlocked by this standing: 0 (outcast, none) .. 5 (patron). */
    public int contractTier() {
        return this == OUTCAST ? 0 : this.ordinal();
    }

    public boolean canBuildProjects() {
        return this.ordinal() >= TRUSTED.ordinal();
    }

    public static Standing of(int standing) {
        Standing result = OUTCAST;
        for (Standing s : values()) {
            if (standing >= s.threshold) result = s;
        }
        return result;
    }

    public static Standing byOrdinal(int ordinal) {
        Standing[] all = values();
        return ordinal >= 0 && ordinal < all.length ? all[ordinal] : STRANGER;
    }
}
