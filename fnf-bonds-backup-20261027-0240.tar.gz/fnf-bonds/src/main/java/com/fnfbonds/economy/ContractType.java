package com.fnfbonds.economy;

/**
 * Contract archetypes. Each one is fed by a different game event, which is what makes the board
 * feel alive instead of being a fetch-quest dispenser.
 */
public enum ContractType {
    /** Hand in N units of a commodity at the ledger desk. */
    DELIVERY("delivery", 1),
    /** Kill N mobs of a species (mostly hostile Friends&amp;Foes species). */
    HUNT("hunt", 2),
    /** Get N friendly Friends&amp;Foes mobs inside the settlement bounds. */
    HERD("herd", 2),
    /** Keep N beehives full / collect N honeycomb inside the settlement. */
    APIARY("apiary", 1),
    /** Place N blocks of a kind inside the settlement. */
    BUILD("build", 1),
    /** Light up N dark spots inside the settlement (glare synergy). */
    LIGHT("light", 2),
    /** Complete a caravan delivery. */
    ESCORT("escort", 3),
    /** Repel a raid / purge N undead or raiders inside the settlement. */
    CLEANSE("cleanse", 3);

    public static final ContractType[] ALL = values();

    public final String path;
    public final int minTier;

    ContractType(String path, int minTier) {
        this.path = path;
        this.minTier = minTier;
    }

    public String titleKey() {
        return "contract.fnfbonds." + this.path;
    }

    public String goalKey() {
        return "contract.fnfbonds." + this.path + ".goal";
    }

    public static ContractType byOrdinal(int ordinal) {
        return ordinal >= 0 && ordinal < ALL.length ? ALL[ordinal] : DELIVERY;
    }
}
