package com.fnfbonds.economy;

import com.fnfbonds.FnfBonds;
import com.fnfbonds.FnfBondsConfig;
import com.fnfbonds.core.Commodity;
import com.fnfbonds.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;


/**
 * Server-side implementation of everything the ledger GUI can ask for. Every entry point
 * re-validates distance, standing tier and inventory, because the client is never trusted.
 */
public final class Actions {
    private Actions() {}

    // ------------------------------------------------------------- small utils

    public static void tell(ServerPlayer player, String key, Object... args) {
        player.sendSystemMessage(Component.translatable(key, args));
    }

    public static void warn(ServerPlayer player, String key, Object... args) {
        player.sendSystemMessage(Component.translatable(key, args).withStyle(ChatFormatting.RED));
    }

    public static void giveEmeralds(ServerPlayer player, PlayerRecord record, float amount) {
        int whole = record.bank(amount);
        if (whole > 0) giveItem(player, new ItemStack(Items.EMERALD, whole));
    }

    public static void giveItem(ServerPlayer player, ItemStack stack) {
        if (stack.isEmpty()) return;
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
    }

    public static int countCommodity(ServerPlayer player, Commodity commodity) {
        int count = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (!stack.isEmpty() && stack.is(commodity.tag)) count += stack.getCount();
        }
        return count;
    }

    public static int takeCommodity(ServerPlayer player, Commodity commodity, int amount) {
        int taken = 0;
        for (int i = 0; i < player.getInventory().getContainerSize() && taken < amount; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.isEmpty() || !stack.is(commodity.tag)) continue;
            int want = Math.min(amount - taken, stack.getCount());
            player.getInventory().removeItem(i, want);
            taken += want;
        }
        return taken;
    }

    public static int countItem(ServerPlayer player, Item item) {
        int count = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.is(item)) count += stack.getCount();
        }
        return count;
    }

    public static int takeItem(ServerPlayer player, Item item, int amount) {
        int taken = 0;
        for (int i = 0; i < player.getInventory().getContainerSize() && taken < amount; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (!stack.is(item)) continue;
            int want = Math.min(amount - taken, stack.getCount());
            player.getInventory().removeItem(i, want);
            taken += want;
        }
        return taken;
    }

    public static boolean takeSeals(ServerPlayer player, int amount) {
        return takeItem(player, ModItems.WAX_SEAL.get(), amount) >= amount;
    }

    public static void giveSeals(ServerPlayer player, PlayerRecord record, int amount) {
        if (amount <= 0) return;
        record.seals += amount;
        giveItem(player, new ItemStack(ModItems.WAX_SEAL.get(), amount));
    }

    private static boolean inside(ServerPlayer player, Settlement s) {
        return s.contains(player.blockPosition());
    }

    // ---------------------------------------------------------------- contracts

    public static void acceptContract(ServerLevel level, Settlement s, ServerPlayer player, int contractId) {
        PlayerRecord record = s.record(player.getUUID());
        if (!inside(player, s)) {
            warn(player, "chat.fnfbonds.error.far");
            return;
        }
        Contract contract = findById(s, contractId);
        if (contract == null) return;
        if (contract.owner != null) {
            warn(player, "chat.fnfbonds.error.taken");
            return;
        }
        if (record.tier() == Standing.OUTCAST) {
            warn(player, "chat.fnfbonds.error.outcast");
            return;
        }
        if (record.tier().contractTier() < contract.tier) {
            warn(player, "chat.fnfbonds.error.tier", contract.tier,
                    Component.translatable(record.tier().translationKey()));
            return;
        }
        contract.owner = player.getUUID();
        record.taken.add(contract.id);
        // live-counted contracts get an immediate progress snapshot
        refreshLiveProgress(level, s, contract);
        tell(player, "chat.fnfbonds.contract.accepted", contract.title());
        EconomyData.get(level).setDirty();
    }

    public static void turnInContract(ServerLevel level, Settlement s, ServerPlayer player, int contractId) {
        PlayerRecord record = s.record(player.getUUID());
        if (!inside(player, s)) {
            warn(player, "chat.fnfbonds.error.far");
            return;
        }
        Contract contract = findById(s, contractId);
        if (contract == null || !player.getUUID().equals(contract.owner)) return;

        if (contract.type == ContractType.DELIVERY) {
            Commodity commodity = Commodity.byPath(contract.target);
            if (commodity == null) return;
            int have = countCommodity(player, commodity);
            if (have < contract.amount - contract.progress) {
                warn(player, "chat.fnfbonds.error.not_enough", commodityName(commodity),
                        contract.amount - contract.progress);
                return;
            }
            int taken = takeCommodity(player, commodity, contract.amount - contract.progress);
            contract.progress += taken;
            s.applySellPressure(commodity, taken);
        } else {
            refreshLiveProgress(level, s, contract);
        }

        if (!contract.isComplete()) {
            tell(player, "chat.fnfbonds.contract.progress", contract.progress, contract.amount);
            EconomyData.get(level).setDirty();
            return;
        }
        complete(level, s, player, record, contract);
    }

    public static void complete(ServerLevel level, Settlement s, ServerPlayer player, PlayerRecord record, Contract contract) {
        float streakBonus = 1.0f + 0.1f * Math.min(10, record.streak);
        if (s.has(Project.MARKET_SQUARE)) streakBonus += 0.1f;

        giveEmeralds(player, record, contract.rewardEmeralds * streakBonus);
        record.addStanding(contract.rewardStanding);
        record.contribution += contract.rewardContribution;
        giveSeals(player, record, contract.rewardSeals);
        record.streak++;
        record.contractsCompleted++;
        record.addKinship(contract.target, 4);

        s.contracts.remove(contract);
        record.taken.remove(Integer.valueOf(contract.id));

        player.sendSystemMessage(Component.translatable("chat.fnfbonds.contract.done", contract.title(),
                        Component.literal(String.valueOf(Math.round(contract.rewardEmeralds * streakBonus))),
                        Component.literal("+" + contract.rewardStanding))
                .withStyle(ChatFormatting.GREEN));
        EconomyData.get(level).setDirty();
    }

    public static void abandonContract(ServerLevel level, Settlement s, ServerPlayer player, int contractId) {
        PlayerRecord record = s.record(player.getUUID());
        Contract contract = findById(s, contractId);
        if (contract == null || !player.getUUID().equals(contract.owner)) return;
        contract.owner = null;
        contract.progress = 0;
        record.taken.remove(Integer.valueOf(contract.id));
        record.streak = 0;
        record.addStanding(-3);
        tell(player, "chat.fnfbonds.contract.abandoned", contract.title());
        EconomyData.get(level).setDirty();
    }

    public static void reroll(ServerLevel level, Settlement s, ServerPlayer player) {
        PlayerRecord record = s.record(player.getUUID());
        int cost = FnfBondsConfig.CONTRACT_REROLL_SEALS.get();
        if (cost > 0 && !takeSeals(player, cost)) {
            warn(player, "chat.fnfbonds.error.seals", cost);
            return;
        }
        s.contracts.removeIf(c -> c.owner == null);
        for (Contract c : s.contracts) {
            if (c.owner != null) record.taken.remove(Integer.valueOf(c.id));
        }
        s.contracts.clear();
        record.taken.clear();
        s.contractDay = -1;
        ContractGenerator.roll(level, s, true);
        tell(player, "chat.fnfbonds.contract.rerolled");
        EconomyData.get(level).setDirty();
    }

    /** @return the contract with that id, or {@code null}. */
    public static Contract findById(Settlement s, int id) {
        for (Contract c : s.contracts) {
            if (c.id == id) return c;
        }
        return null;
    }

    /**
     * Recomputes progress of contracts whose state lives in the world rather than in an event
     * counter: herded mobs, beehive inhabitants, escort deliveries, purged raiders.
     */
    public static void refreshLiveProgress(ServerLevel level, Settlement s, Contract contract) {
        switch (contract.type) {
            case HERD -> {
                Identifier target = parse(contract.target);
                if (target == null) return;
                net.minecraft.world.entity.EntityType<?> type = BuiltInRegistries.ENTITY_TYPE.get(target)
                .map(net.minecraft.core.Holder.Reference::value).orElse(null);
                int count = level.getEntitiesOfClass(Mob.class, EconomyTicker.area(s), e -> e.getType() == type).size();
                contract.progress = Math.min(contract.amount, count);
            }
            case APIARY -> {
                int bees = level.getEntitiesOfClass(Mob.class, EconomyTicker.area(s),
                        e -> e.getType().builtInRegistryHolder().is(EntityTypeTags.BEEHIVE_INHABITORS)).size();
                contract.progress = Math.min(contract.amount, bees);
            }
            case ESCORT -> {
                if (contract.owner == null) return;
                PlayerRecord record = s.record(contract.owner);
                contract.progress = Math.min(contract.amount, record.caravansDelivered);
            }
            default -> {
            }
        }
    }

    private static Identifier parse(String raw) {
        try {
            return Identifier.parse(raw);
        } catch (Exception e) {
            return null;
        }
    }

    private static Component commodityName(Commodity c) {
        return Component.translatable(c.translationKey());
    }

    // ------------------------------------------------------------------ market

    public static void sell(ServerLevel level, Settlement s, ServerPlayer player, Commodity commodity, int units) {
        if (!inside(player, s)) {
            warn(player, "chat.fnfbonds.error.far");
            return;
        }
        units = Math.min(units, countCommodity(player, commodity));
        if (units <= 0) {
            warn(player, "chat.fnfbonds.error.nothing_to_sell", commodityName(commodity));
            return;
        }
        PlayerRecord record = s.record(player.getUUID());
        int taken = takeCommodity(player, commodity, units);
        float price = s.price(commodity, record.tier());
        giveEmeralds(player, record, taken * price);
        s.applySellPressure(commodity, taken);
        tell(player, "chat.fnfbonds.market.sold", taken, commodityName(commodity),
                Component.literal(String.format(java.util.Locale.ROOT, "%.2f", taken * price)));
        EconomyData.get(level).setDirty();
    }

    public static void buy(ServerLevel level, Settlement s, ServerPlayer player, Commodity commodity, int units) {
        if (!inside(player, s)) {
            warn(player, "chat.fnfbonds.error.far");
            return;
        }
        PlayerRecord record = s.record(player.getUUID());
        float price = s.price(commodity, record.tier());
        float cost = units * price;
        int emeralds = countItem(player, Items.EMERALD);
        float available = emeralds + record.bank;
        if (available + 0.001f < cost) {
            warn(player, "chat.fnfbonds.error.poor",
                    Component.literal(String.format(java.util.Locale.ROOT, "%.2f", cost)));
            return;
        }
        Item unit = BuiltInRegistries.ITEM.get(commodity.unitItem)
                .map(net.minecraft.core.Holder.Reference::value).orElse(net.minecraft.world.item.Items.AIR);
        if (unit == null || unit == Items.AIR) {
            warn(player, "chat.fnfbonds.error.no_unit", commodityName(commodity));
            return;
        }
        int spentItems = Math.min(emeralds, (int) Math.ceil(cost - record.bank));
        takeItem(player, Items.EMERALD, spentItems);
        record.bank = Math.max(0f, record.bank + spentItems - cost);
        giveItem(player, new ItemStack(unit, units));
        s.applyBuyPressure(commodity, units);
        tell(player, "chat.fnfbonds.market.bought", units, commodityName(commodity),
                Component.literal(String.format(java.util.Locale.ROOT, "%.2f", cost)));
        EconomyData.get(level).setDirty();
    }

    // ----------------------------------------------------------------- caravan

    public static void sendCaravan(ServerLevel level, Settlement s, ServerPlayer player,
                                  Commodity commodity, int units, int routeIndex) {
        if (!inside(player, s)) {
            warn(player, "chat.fnfbonds.error.far");
            return;
        }
        PlayerRecord record = s.record(player.getUUID());
        int active = 0;
        for (Caravan c : s.caravans) {
            if (player.getUUID().equals(c.owner)) active++;
        }
        if (active >= s.caravanSlots(player.getUUID())) {
            warn(player, "chat.fnfbonds.error.caravan_slots", s.caravanSlots(player.getUUID()));
            return;
        }
        if (routeIndex < 0 || routeIndex >= s.routes.size()) {
            warn(player, "chat.fnfbonds.error.no_route");
            return;
        }
        Settlement destination = EconomyData.get(level).settlement(s.routes.get(routeIndex));
        if (destination == null) {
            warn(player, "chat.fnfbonds.error.no_route");
            return;
        }
        units = Math.min(units, Math.min(s.caravanCapacity(), countCommodity(player, commodity)));
        if (units <= 0) {
            warn(player, "chat.fnfbonds.error.nothing_to_send", commodityName(commodity));
            return;
        }
        if (!takeSeals(player, 1)) {
            warn(player, "chat.fnfbonds.error.seals", 1);
            return;
        }

        int taken = takeCommodity(player, commodity, units);
        Caravan caravan = new Caravan();
        caravan.id = s.nextCaravanId++;
        caravan.commodity = commodity;
        caravan.amount = taken;
        caravan.destination = destination.id;
        caravan.departAt = level.getGameTime();
        double distance = Math.max(64, Math.sqrt(s.center.distSqr(destination.center)));
        long travel = FnfBondsConfig.CARAVAN_BASE_TICKS.get() + (long) (distance / 8.0 * 100.0);
        if (s.has(Project.WAREHOUSE)) travel = (long) (travel * 0.9);
        caravan.arriveAt = caravan.departAt + Math.max(1200L, travel);
        caravan.owner = player.getUUID();

        float destPrice = destination.price(commodity, record.tier());
        caravan.payout = taken * destPrice * 0.95f;
        if (destination.has(Project.WAREHOUSE)) caravan.payout *= 1.1f;
        s.applySellPressure(commodity, taken);
        destination.applyBuyPressure(commodity, taken);
        s.caravans.add(caravan);

        player.sendSystemMessage(Component.translatable("chat.fnfbonds.caravan.sent", destination.name,
                        Component.literal(String.format(java.util.Locale.ROOT, "%.1f", caravan.payout)))
                .withStyle(ChatFormatting.AQUA));
        EconomyData.get(level).setDirty();
    }

    public static void collectCaravan(ServerLevel level, Settlement s, ServerPlayer player, int caravanId) {
        Caravan caravan = null;
        for (Caravan c : s.caravans) {
            if (c.id == caravanId) caravan = c;
        }
        if (caravan == null || !player.getUUID().equals(caravan.owner)) return;
        if (caravan.raided) {
            warn(player, "chat.fnfbonds.error.caravan_raided");
            return;
        }
        if (!caravan.hasArrived(level.getGameTime())) {
            warn(player, "chat.fnfbonds.error.caravan_traveling");
            return;
        }
        PlayerRecord record = s.record(player.getUUID());
        giveEmeralds(player, record, caravan.payout);
        record.addStanding(5);
        record.contribution += 6;
        record.caravansDelivered++;
        record.addKinship("caravan", 1);
        s.caravans.remove(caravan);

        for (Contract contract : s.contracts) {
            if (contract.type == ContractType.ESCORT && player.getUUID().equals(contract.owner)) {
                contract.progress++;
                if (contract.isComplete()) complete(level, s, player, record, contract);
            }
        }
        player.sendSystemMessage(Component.translatable("chat.fnfbonds.caravan.collected",
                        Component.literal(String.format(java.util.Locale.ROOT, "%.2f", caravan.payout)))
                .withStyle(ChatFormatting.GREEN));
        EconomyData.get(level).setDirty();
    }

    // ---------------------------------------------------------------- projects

    public static void buildProject(ServerLevel level, Settlement s, ServerPlayer player, Project project) {
        if (!inside(player, s)) {
            warn(player, "chat.fnfbonds.error.far");
            return;
        }
        PlayerRecord record = s.record(player.getUUID());
        if (!record.tier().canBuildProjects()) {
            warn(player, "chat.fnfbonds.error.need_trusted");
            return;
        }
        if (s.has(project)) {
            warn(player, "chat.fnfbonds.error.built");
            return;
        }
        if (record.contribution < project.contributionCost) {
            warn(player, "chat.fnfbonds.error.contribution", project.contributionCost, record.contribution);
            return;
        }
        if (countItem(player, Items.EMERALD) < project.emeraldCost) {
            warn(player, "chat.fnfbonds.error.poor", Component.literal(String.valueOf(project.emeraldCost)));
            return;
        }
        takeItem(player, Items.EMERALD, project.emeraldCost);
        record.contribution -= project.contributionCost;
        s.projects.add(project);
        record.addStanding(25);

        player.sendSystemMessage(Component.translatable("chat.fnfbonds.project.built",
                Component.translatable(project.translationKey())).withStyle(ChatFormatting.GOLD));
        for (ServerPlayer other : level.players()) {
            if (other.getUUID().equals(player.getUUID())) continue;
            if (s.contains(other.blockPosition())) {
                other.sendSystemMessage(Component.translatable("chat.fnfbonds.project.announcement",
                        player.getDisplayName(), Component.translatable(project.translationKey())));
            }
        }
        EconomyData.get(level).setDirty();
    }

    // ------------------------------------------------------------------- misc

    public static void donate(ServerLevel level, Settlement s, ServerPlayer player, int emeralds) {
        PlayerRecord record = s.record(player.getUUID());
        long day = EconomyData.day(level);
        if (record.lastDonateDay != day) {
            record.lastDonateDay = day;
            record.donatedToday = 0;
        }
        int room = 64 - record.donatedToday;
        if (room <= 0) {
            warn(player, "chat.fnfbonds.error.donate_limit");
            return;
        }
        int amount = Math.min(Math.min(emeralds, room), countItem(player, Items.EMERALD));
        if (amount <= 0) {
            warn(player, "chat.fnfbonds.error.poor", Component.literal("1"));
            return;
        }
        takeItem(player, Items.EMERALD, amount);
        record.donatedToday += amount;
        record.contribution += amount * 2;
        record.addStanding(amount);
        tell(player, "chat.fnfbonds.donate.done", amount);
        EconomyData.get(level).setDirty();
    }

    public static void takeCredit(ServerLevel level, Settlement s, ServerPlayer player, int amount) {
        PlayerRecord record = s.record(player.getUUID());
        int limit = record.tier().creditLimit;
        if (record.credit + amount > limit) {
            warn(player, "chat.fnfbonds.error.credit_limit", limit);
            return;
        }
        record.credit += amount;
        giveItem(player, new ItemStack(Items.EMERALD, amount));
        tell(player, "chat.fnfbonds.credit.taken", amount);
        EconomyData.get(level).setDirty();
    }

    public static void repayCredit(ServerLevel level, Settlement s, ServerPlayer player, int amount) {
        PlayerRecord record = s.record(player.getUUID());
        int pay = Math.min(amount, countItem(player, Items.EMERALD));
        pay = (int) Math.min(pay, Math.ceil(record.credit));
        if (pay <= 0) return;
        takeItem(player, Items.EMERALD, pay);
        record.credit = Math.max(0f, record.credit - pay);
        record.addStanding(pay / 2);
        tell(player, "chat.fnfbonds.credit.repaid", pay);
        EconomyData.get(level).setDirty();
    }

    public static void claimLostLoot(ServerLevel level, Settlement s, ServerPlayer player) {
        if (!inside(player, s)) {
            warn(player, "chat.fnfbonds.error.far");
            return;
        }
        if (s.lostLoot.isEmpty()) {
            warn(player, "chat.fnfbonds.error.no_loot");
            return;
        }
        PlayerRecord record = s.record(player.getUUID());
        for (Settlement.LostItem lost : s.lostLoot) {
            Item item = BuiltInRegistries.ITEM.get(lost.item())
                    .map(net.minecraft.core.Holder.Reference::value).orElse(net.minecraft.world.item.Items.AIR);
            if (item == null || item == Items.AIR) continue;
            giveItem(player, new ItemStack(item, lost.count()));
        }
        int count = s.lostLoot.size();
        s.lostLoot.clear();
        record.addStanding(2);
        tell(player, "chat.fnfbonds.loot.claimed", count);
        EconomyData.get(level).setDirty();
    }

    // ------------------------------------------------------- mob-driven income

    /** Standing granted when a player herds a friendly Friends&amp;Foes mob into the settlement. */
    public static void onFriendlyMobEntered(ServerLevel level, Settlement s, ServerPlayer player, Mob mob) {
        PlayerRecord record = s.record(player.getUUID());
        Identifier species = BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType());
        record.addStanding(3);
        record.addKinship(species.toString(), 6);
        record.grudges.remove(species.toString());
        for (Contract contract : s.contracts) {
            if (contract.type == ContractType.HERD && contract.target.equals(species.toString())
                    && player.getUUID().equals(contract.owner)) {
                refreshLiveProgress(level, s, contract);
            }
        }
        EconomyData.get(level).setDirty();
    }

    /** Standing lost for killing a friendly species inside a settlement — the grudge mechanic. */
    public static void onGrudge(ServerLevel level, Settlement s, ServerPlayer player, Mob victim) {
        PlayerRecord record = s.record(player.getUUID());
        Identifier species = BuiltInRegistries.ENTITY_TYPE.getKey(victim.getType());
        int penalty = FnfBondsConfig.GRUDGE_PENALTY.get();
        record.addStanding(-penalty);
        record.addGrudge(species.toString(), 1);
        record.addKinship(species.toString(), -4);
        player.sendSystemMessage(Component.translatable("chat.fnfbonds.grudge",
                        Component.translatable("entity." + species.getNamespace() + "." + species.getPath()), penalty)
                .withStyle(ChatFormatting.DARK_RED));
        EconomyData.get(level).setDirty();
    }

    public static void logMissing(String what) {
        FnfBonds.LOGGER.warn("[Bonds & Ledger] {} is not available - is Friends&Foes installed?", what);
    }

    /** Commodity pressures clamped after config reloads, so a tightened config cannot be cheated. */
    public static void clampAll(Settlement s) {
        for (Commodity c : Commodity.ALL) {
            s.pressure[c.ordinal()] = Math.clamp(s.pressure[c.ordinal()], -1.6f, 1.6f);
        }
    }
}
