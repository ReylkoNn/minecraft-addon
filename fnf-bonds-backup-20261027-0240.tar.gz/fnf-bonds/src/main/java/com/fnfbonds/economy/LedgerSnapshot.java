package com.fnfbonds.economy;

import com.fnfbonds.core.Commodity;
import com.fnfbonds.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.FloatTag;
import net.minecraft.nbt.IntTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Items;

/**
 * Builds the client-side snapshot of a settlement. The GUI is a pure function of this tag: the
 * server sends it on open and after every action, the client never queries world state directly.
 */
public final class LedgerSnapshot {
    private LedgerSnapshot() {}

    public static CompoundTag build(ServerPlayer player, Settlement s) {
        return build(player, s, 0);
    }

    public static CompoundTag build(ServerPlayer player, Settlement s, int tab) {
        ServerLevel level = player.level();
        PlayerRecord record = s.record(player.getUUID());

        CompoundTag tag = new CompoundTag();
        tag.putInt("tab", tab);
        tag.putInt("id", s.id);
        tag.putString("name", s.name);
        tag.putInt("radius", s.radius);
        tag.putInt("threat", s.threat);
        tag.putLong("day", EconomyData.day(level));
        tag.putInt("tier", record.tier().ordinal());
        tag.putInt("standing", record.standing);
        tag.putInt("contribution", record.contribution);
        tag.putInt("streak", record.streak);
        tag.putInt("contractsDone", record.contractsCompleted);
        tag.putInt("contractsFailed", record.contractsFailed);
        tag.putInt("caravansDone", record.caravansDelivered);
        tag.putFloat("bank", record.bank);
        tag.putFloat("credit", record.credit);
        tag.putInt("creditLimit", record.tier().creditLimit);
        tag.putInt("seals", Actions.countItem(player, ModItems.WAX_SEAL.get()));
        tag.putInt("emeralds", Actions.countItem(player, Items.EMERALD));
        tag.putBoolean("board", s.hasBoard());
        tag.putBoolean("post", s.hasPost());
        tag.putBoolean("anchored", s.isAnchored());
        tag.putInt("contractSlots", s.contractSlots());
        tag.putInt("caravanSlots", s.caravanSlots(player.getUUID()));
        tag.putInt("caravanCapacity", s.caravanCapacity());
        tag.putLong("gameTime", level.getGameTime());

        ListTag prices = new ListTag();
        ListTag multipliers = new ListTag();
        ListTag pressures = new ListTag();
        ListTag holdings = new ListTag();
        for (Commodity c : Commodity.ALL) {
            prices.add(FloatTag.valueOf(s.price(c, record.tier())));
            multipliers.add(FloatTag.valueOf(s.multiplier(c)));
            pressures.add(FloatTag.valueOf(s.pressure[c.ordinal()]));
            holdings.add(IntTag.valueOf(Actions.countCommodity(player, c)));
        }
        tag.put("prices", prices);
        tag.put("multipliers", multipliers);
        tag.put("pressures", pressures);
        tag.put("holdings", holdings);

        ListTag projects = new ListTag();
        for (Project p : Project.ALL) projects.add(StringTag.valueOf(p.path));
        tag.put("projectOrder", projects);
        ListTag built = new ListTag();
        for (Project p : Project.ALL) built.add(IntTag.valueOf(s.has(p) ? 1 : 0));
        tag.put("projectsBuilt", built);

        ListTag contracts = new ListTag();
        for (Contract c : s.contracts) {
            CompoundTag entry = c.write();
            entry.putBoolean("mine", player.getUUID().equals(c.owner));
            entry.putBoolean("anyOwner", c.owner != null);
            contracts.add(entry);
        }
        tag.put("contracts", contracts);

        ListTag caravans = new ListTag();
        for (Caravan c : s.caravans) {
            CompoundTag entry = c.write();
            entry.putBoolean("mine", player.getUUID().equals(c.owner));
            entry.putBoolean("arrived", c.hasArrived(level.getGameTime()));
            Settlement dest = EconomyData.get(level).settlement(c.destination);
            entry.putString("destName", dest == null ? "?" : dest.name);
            caravans.add(entry);
        }
        tag.put("caravans", caravans);

        ListTag routes = new ListTag();
        for (int routeId : s.routes) {
            Settlement dest = EconomyData.get(level).settlement(routeId);
            if (dest == null) continue;
            CompoundTag entry = new CompoundTag();
            entry.putInt("id", dest.id);
            entry.putString("name", dest.name);
            entry.putInt("distance", (int) Math.sqrt(s.center.distSqr(dest.center)));
            routes.add(entry);
        }
        tag.put("routes", routes);

        ListTag loot = new ListTag();
        for (Settlement.LostItem item : s.lostLoot) {
            CompoundTag entry = new CompoundTag();
            entry.putString("item", item.item().toString());
            entry.putInt("count", item.count());
            loot.add(entry);
        }
        tag.put("lostLoot", loot);
        return tag;
    }

    /** Lightweight variant pushed to the HUD a few times per second. */
    public static CompoundTag buildHud(ServerPlayer player, Settlement s) {
        PlayerRecord record = s.record(player.getUUID());
        CompoundTag tag = new CompoundTag();
        tag.putString("name", s.name);
        tag.putInt("tier", record.tier().ordinal());
        tag.putInt("standing", record.standing);
        tag.putInt("contribution", record.contribution);
        tag.putInt("seals", Actions.countItem(player, ModItems.WAX_SEAL.get()));
        tag.putInt("threat", s.threat);
        int open = 0;
        int mine = 0;
        for (Contract c : s.contracts) {
            open++;
            if (player.getUUID().equals(c.owner)) mine++;
        }
        tag.putInt("contracts", open);
        tag.putInt("contractsMine", mine);
        ListTag prices = new ListTag();
        for (Commodity c : Commodity.ALL) prices.add(FloatTag.valueOf(s.multiplier(c)));
        tag.put("multipliers", prices);
        return tag;
    }
}
