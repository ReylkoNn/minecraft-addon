package com.fnfbonds.economy;

import com.fnfbonds.FnfBondsConfig;
import com.fnfbonds.core.Commodity;
import com.fnfbonds.core.FnfRefs;
import com.fnfbonds.core.ModTags;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The economic heartbeat: market relaxation, threat assessment, contract expiry, caravan travel and
 * the daily passive income that Friends&amp;Foes mobs produce for a settlement.
 *
 * <p>Only settlements with a player inside are processed, and only every 100 game ticks, so the
 * cost stays flat no matter how many settlements exist.
 */
public final class EconomyTicker {
    private EconomyTicker() {}

    public static AABB area(Settlement s) {
        int r = s.radius;
        BlockPos c = s.center;
        return new AABB(c.getX() - r, c.getY() - r, c.getZ() - r, c.getX() + 1 + r, c.getY() + 1 + r, c.getZ() + 1 + r);
    }

    public static List<ServerPlayer> playersInside(Settlement s, List<ServerPlayer> players) {
        List<ServerPlayer> out = new ArrayList<>();
        for (ServerPlayer p : players) {
            if (s.contains(p.blockPosition())) out.add(p);
        }
        return out;
    }

    public static void onLevelTick(ServerLevel level) {
        long gameTime = level.getGameTime();
        if (gameTime % 100L != 0L) return;

        EconomyData data = EconomyData.get(level);
        if (data.settlements().isEmpty()) return;

        List<ServerPlayer> players = level.players();
        if (players.isEmpty()) return;
        RandomSource random = level.getRandom();
        boolean dirty = false;

        for (Settlement s : new ArrayList<>(data.settlements())) {
            List<ServerPlayer> present = playersInside(s, players);
            if (present.isEmpty()) continue;

            if (gameTime % 200L == 0L) updateThreat(level, s);
            if (ContractGenerator.roll(level, s, false)) dirty = true;
            dirty |= expireContracts(level, s, present);
            dirty |= tickCaravans(level, s, present, gameTime, random);
            if (gameTime - s.lastDailyTick >= 24000L) {
                daily(level, s, present, random);
                dirty = true;
            }
        }
        if (dirty) data.setDirty();
    }

    // ----------------------------------------------------------------- threat

    public static void updateThreat(ServerLevel level, Settlement s) {
        Map<Identifier, Integer> hostile = countSpecies(level, s, ModTags.HOSTILE_MOBS);
        int threat = 0;
        for (Map.Entry<Identifier, Integer> e : hostile.entrySet()) {
            threat += weight(e.getKey()) * e.getValue();
        }
        // vanilla raiders count too, at a flat weight
        int raiders = countTag(level, s, net.minecraft.tags.EntityTypeTags.RAIDERS);
        threat += 3 * raiders;

        Map<Identifier, Integer> friendly = countSpecies(level, s, ModTags.FRIENDLY_MOBS);
        threat -= 2 * friendly.getOrDefault(FnfRefs.GLARE, 0);
        if (s.has(Project.WATCHTOWER)) threat -= 8;
        if (s.has(Project.EMBASSY)) threat -= 4;
        s.threat = Math.max(0, Math.min(60, threat));
    }

    private static int weight(Identifier id) {
        if (id.equals(FnfRefs.WILDFIRE)) return 8;
        if (id.equals(FnfRefs.ILLUSIONER)) return 5;
        if (id.equals(FnfRefs.ICEOLOGER)) return 4;
        if (id.equals(FnfRefs.MAULER)) return 3;
        if (id.equals(FnfRefs.BARNACLE)) return 2;
        return 2;
    }

    private static int countTag(ServerLevel level, Settlement s, TagKey<EntityType<?>> tag) {
        return level.getEntitiesOfClass(Mob.class, area(s), e -> e.getType().builtInRegistryHolder().is(tag)).size();
    }

    public static Map<Identifier, Integer> countSpecies(ServerLevel level, Settlement s, TagKey<EntityType<?>> tag) {
        Map<Identifier, Integer> counts = new HashMap<>();
        for (Mob mob : level.getEntitiesOfClass(Mob.class, area(s), e -> e.getType().builtInRegistryHolder().is(tag))) {
            Identifier id = net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType());
            counts.merge(id, 1, Integer::sum);
        }
        return counts;
    }

    // -------------------------------------------------------------- contracts

    private static boolean expireContracts(ServerLevel level, Settlement s, List<ServerPlayer> present) {
        long day = EconomyData.day(level);
        boolean changed = false;
        for (int i = s.contracts.size() - 1; i >= 0; i--) {
            Contract c = s.contracts.get(i);
            if (!c.isExpired(day)) continue;
            s.contracts.remove(i);
            changed = true;
            if (c.owner == null) continue;
            for (ServerPlayer p : present) {
                if (!p.getUUID().equals(c.owner)) continue;
                PlayerRecord record = s.record(p.getUUID());
                record.taken.remove(Integer.valueOf(c.id));
                record.streak = 0;
                record.contractsFailed++;
                record.addStanding(-(4 + 3 * c.tier));
                p.sendSystemMessage(Component.translatable("chat.fnfbonds.contract.expired", c.title())
                        .withStyle(ChatFormatting.RED));
            }
        }
        return changed;
    }

    // ---------------------------------------------------------------- caravans

    private static boolean tickCaravans(ServerLevel level, Settlement s, List<ServerPlayer> present, long gameTime, RandomSource random) {
        boolean changed = false;
        for (Caravan caravan : new ArrayList<>(s.caravans)) {
            if (!caravan.raidRolled && gameTime >= caravan.departAt + (caravan.arriveAt - caravan.departAt) / 2L) {
                caravan.raidRolled = true;
                double risk = raidRisk(s);
                if (random.nextDouble() < risk) {
                    caravan.raided = true;
                    caravan.raidUntil = gameTime + 6000L;
                    caravan.escortNeeded = 2 + caravan.amount / 32;
                    caravan.escortKills = 0;
                    notify(s, present, caravan.owner,
                            Component.translatable("chat.fnfbonds.caravan.raided", caravanName(caravan))
                                    .withStyle(ChatFormatting.GOLD));
                    spawnAmbush(level, s, random);
                    changed = true;
                }
            }

            if (caravan.raided && gameTime > caravan.raidUntil) {
                if (caravan.escortKills >= caravan.escortNeeded) {
                    caravan.raided = false;
                    caravan.payout *= 1.15f;
                    notify(s, present, caravan.owner,
                            Component.translatable("chat.fnfbonds.caravan.saved", caravanName(caravan))
                                    .withStyle(ChatFormatting.GREEN));
                } else {
                    caravan.raided = false;
                    caravan.payout *= (1.0f - FnfBondsConfig.CARAVAN_RAID_LOSS.get().floatValue());
                    PlayerRecord record = s.record(caravan.owner);
                    record.addStanding(-4);
                    notify(s, present, caravan.owner,
                            Component.translatable("chat.fnfbonds.caravan.lost", caravanName(caravan))
                                    .withStyle(ChatFormatting.RED));
                }
                changed = true;
            }

            if (caravan.hasArrived(gameTime) && !caravan.raided) {
                notify(s, present, caravan.owner,
                        Component.translatable("chat.fnfbonds.caravan.arrived", caravanName(caravan))
                                .withStyle(ChatFormatting.AQUA));
            }
        }
        return changed;
    }

    public static double raidRisk(Settlement s) {
        double risk = FnfBondsConfig.CARAVAN_BASE_RISK.get();
        if (s.has(Project.WATCHTOWER)) risk *= 0.5;
        risk += s.threat * 0.005;
        return Math.clamp(risk, 0.0, 0.75);
    }

    private static String caravanName(Caravan caravan) {
        return Component.translatable(caravan.commodity.translationKey()).getString() + " x" + caravan.amount;
    }

    private static void notify(Settlement s, List<ServerPlayer> present, java.util.UUID owner, Component message) {
        for (ServerPlayer p : present) {
            if (owner == null || p.getUUID().equals(owner)) p.sendSystemMessage(message);
        }
    }

    /**
     * A caravan ambush: a small war band of hostile Friends&amp;Foes mobs spawns at the settlement
     * edge. Killing them within the escort window saves the cargo — this is the hook the faction
     * module later turns into full sieges.
     */
    private static void spawnAmbush(ServerLevel level, Settlement s, RandomSource random) {
        List<Identifier> candidates = new ArrayList<>();
        for (Identifier id : new Identifier[]{FnfRefs.MAULER, FnfRefs.BARNACLE, FnfRefs.ICEOLOGER}) {
            if (FnfRefs.has(id)) candidates.add(id);
        }
        if (candidates.isEmpty()) return;

        EntityType<?> type = net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.get(candidates.get(random.nextInt(candidates.size())))
                .map(net.minecraft.core.Holder.Reference::value).orElse(null);
        int count = 2 + random.nextInt(3);
        for (int i = 0; i < count; i++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double dist = s.radius * 0.5;
            BlockPos pos = s.center.offset(
                    (int) Math.round(Math.cos(angle) * dist), 0, (int) Math.round(Math.sin(angle) * dist));
            pos = level.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING, pos);
            if (type == null) continue;
            if (type.create(level, net.minecraft.world.entity.EntitySpawnReason.MOB_SUMMONED) instanceof Mob mob) {
                mob.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
                mob.setYRot(random.nextFloat() * 360f);
                mob.setPersistenceRequired();
                level.addFreshEntity(mob);
            }
        }
    }

    // ------------------------------------------------------------------ daily

    private static void daily(ServerLevel level, Settlement s, List<ServerPlayer> present, RandomSource random) {
        s.lastDailyTick = level.getGameTime();
        long day = EconomyData.day(level);

        // 1. market relaxation + drift
        float decay = FnfBondsConfig.MARKET_DECAY.get().floatValue();
        float drift = FnfBondsConfig.MARKET_DRIFT.get().floatValue();
        float threatDrift = s.threat >= 15 ? -0.05f : 0f;
        for (Commodity c : Commodity.ALL) {
            float p = s.pressure[c.ordinal()] * decay;
            p += (random.nextFloat() * 2f - 1f) * drift;
            if (c != Commodity.METAL && c != Commodity.CHITIN && c != Commodity.FROST) p += threatDrift;
            s.pressure[c.ordinal()] = Math.clamp(p, -1.6f, 1.6f);
        }

        // 2. mob-driven passive income for the players currently in the settlement
        Map<Identifier, Integer> friendly = countSpecies(level, s, ModTags.FRIENDLY_MOBS);
        int cap = FnfBondsConfig.MOB_INCOME_CAP.get();
        float mobStanding = 0f;
        for (Map.Entry<Identifier, Integer> e : friendly.entrySet()) {
            mobStanding += Math.min(cap, e.getValue()) * 0.5f;
        }
        int bees = countTag(level, s, net.minecraft.tags.EntityTypeTags.BEEHIVE_INHABITORS);
        mobStanding += Math.min(cap, bees) * 0.5f;

        // 3. crab scavenging fills the lost & found
        int crabs = friendly.getOrDefault(FnfRefs.CRAB, 0);
        if (crabs > 0 && s.lostLoot.size() < 9 && random.nextFloat() < Math.min(0.85f, 0.25f * crabs)) {
            s.lostLoot.add(ContractGenerator.randomLostLoot(random));
        }

        // 4. apply income / decay to everybody present
        for (ServerPlayer p : present) {
            PlayerRecord record = s.record(p.getUUID());
            if (mobStanding > 0f) {
                record.addStanding(Math.round(mobStanding));
                if (random.nextFloat() < 0.15f) {
                    p.sendSystemMessage(Component.translatable("chat.fnfbonds.settlement.income",
                                    Component.translatable("standing.fnfbonds." + record.tier().key))
                            .withStyle(ChatFormatting.GRAY));
                }
            }
            if (FnfBondsConfig.STANDING_DECAY.get() && record.standing > 400 && day % 2 == 0) {
                record.addStanding(-1);
            }
            record.donatedToday = 0;
        }

        // 5. tuff golem museum income
        if (s.has(Project.MUSEUM)) {
            int golems = friendly.getOrDefault(FnfRefs.TUFF_GOLEM, 0);
            if (golems > 0 && day % 3 == 0) {
                for (ServerPlayer p : present) {
                    PlayerRecord record = s.record(p.getUUID());
                    record.addStanding(2 * Math.min(cap, golems));
                    Actions.giveEmeralds(p, record, Math.min(cap, golems));
                }
            }
        }
    }
}
