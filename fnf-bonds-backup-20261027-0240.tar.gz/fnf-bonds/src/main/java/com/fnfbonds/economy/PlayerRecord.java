package com.fnfbonds.economy;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntTag;
import net.minecraft.nbt.ListTag;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Everything the settlement remembers about one player: bonds, ledger, seals, credit and grudges.
 *
 * <p>{@link #grudges} and {@link #kinship} are the hooks the later modules pick up: grudges decide
 * whether a species will ever accept the player as a companion, kinship is the companion module's
 * experience pool.
 */
public final class PlayerRecord {
    public int standing;
    public int contribution;
    public int streak;
    public int seals;
    /** Fractional emerald balance so sub-emerald market prices still pay out exactly. */
    public float bank;
    public float credit;
    public long lastDonateDay = -1;
    public long lastMeadDay = -1;
    public int donatedToday;
    public int contractsCompleted;
    public int contractsFailed;
    public int caravansDelivered;

    /** species id ("friendsandfoes:moobloom") -> kills inside settlements. */
    public final Map<String, Integer> grudges = new HashMap<>();
    /** species id -> kinship points (reserved for the companion module). */
    public final Map<String, Integer> kinship = new HashMap<>();
    /** species id -> last day the player was credited for herding/interacting with it. */
    public final Map<String, Long> herdDays = new HashMap<>();
    /** contract ids this player has taken. */
    public final List<Integer> taken = new ArrayList<>();

    public Standing tier() {
        return Standing.of(this.standing);
    }

    public void addStanding(int delta) {
        this.standing = Math.max(-1000, Math.min(2000, this.standing + delta));
    }

    /** Adds a fractional emerald amount to the balance and returns whole emeralds to pay out. */
    public int bank(float amount) {
        this.bank += amount;
        int whole = (int) Math.floor(this.bank);
        if (whole > 0) this.bank -= whole;
        return Math.max(0, whole);
    }

    public int grudge(String species) {
        return this.grudges.getOrDefault(species, 0);
    }

    public void addGrudge(String species, int amount) {
        this.grudges.merge(species, amount, Integer::sum);
    }

    public int kinship(String species) {
        return this.kinship.getOrDefault(species, 0);
    }

    public void addKinship(String species, int amount) {
        this.kinship.merge(species, Math.max(0, this.kinship.getOrDefault(species, 0) + amount), Integer::sum);
    }

    // ------------------------------------------------------------------- nbt

    public CompoundTag write() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("standing", this.standing);
        tag.putInt("contribution", this.contribution);
        tag.putInt("streak", this.streak);
        tag.putInt("seals", this.seals);
        tag.putFloat("bank", this.bank);
        tag.putFloat("credit", this.credit);
        tag.putLong("lastDonateDay", this.lastDonateDay);
        tag.putLong("lastMeadDay", this.lastMeadDay);
        tag.putInt("donatedToday", this.donatedToday);
        tag.putInt("contractsCompleted", this.contractsCompleted);
        tag.putInt("contractsFailed", this.contractsFailed);
        tag.putInt("caravansDelivered", this.caravansDelivered);
        writeMap(tag, "grudges", this.grudges);
        writeMap(tag, "herdDays", this.herdDays);
        writeMap(tag, "kinship", this.kinship);
        ListTag taken = new ListTag();
        for (int id : this.taken) taken.add(IntTag.valueOf(id));
        tag.put("taken", taken);
        return tag;
    }

    /** Values are stored as longs so one writer serves both the int and the long maps. */
    private static void writeMap(CompoundTag tag, String key, Map<String, ? extends Number> map) {
        ListTag list = new ListTag();
        map.forEach((k, v) -> {
            CompoundTag entry = new CompoundTag();
            entry.putString("k", k);
            entry.putLong("v", v.longValue());
            list.add(entry);
        });
        tag.put(key, list);
    }

    private static void readIntMap(CompoundTag tag, String key, Map<String, Integer> into) {
        into.clear();
        ListTag list = tag.getListOrEmpty(key);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompoundOrEmpty(i);
            into.put(entry.getStringOr("k", ""), (int) entry.getLongOr("v", 0L));
        }
    }

    private static void readLongMap(CompoundTag tag, String key, Map<String, Long> into) {
        into.clear();
        ListTag list = tag.getListOrEmpty(key);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompoundOrEmpty(i);
            into.put(entry.getStringOr("k", ""), entry.getLongOr("v", 0L));
        }
    }

    public static PlayerRecord read(CompoundTag tag) {
        PlayerRecord r = new PlayerRecord();
        r.standing = tag.getIntOr("standing", 0);
        r.contribution = tag.getIntOr("contribution", 0);
        r.streak = tag.getIntOr("streak", 0);
        r.seals = tag.getIntOr("seals", 0);
        r.bank = tag.getFloatOr("bank", 0F);
        r.credit = tag.getFloatOr("credit", 0F);
        r.lastDonateDay = tag.getLongOr("lastDonateDay", 0L);
        r.lastMeadDay = tag.getLongOr("lastMeadDay", 0L);
        r.donatedToday = tag.getIntOr("donatedToday", 0);
        r.contractsCompleted = tag.getIntOr("contractsCompleted", 0);
        r.contractsFailed = tag.getIntOr("contractsFailed", 0);
        r.caravansDelivered = tag.getIntOr("caravansDelivered", 0);
        readIntMap(tag, "grudges", r.grudges);
        readLongMap(tag, "herdDays", r.herdDays);
        readIntMap(tag, "kinship", r.kinship);
        r.taken.clear();
        ListTag taken = tag.getListOrEmpty("taken");
        for (int i = 0; i < taken.size(); i++) r.taken.add(taken.getIntOr(i, 0));
        return r;
    }
}
