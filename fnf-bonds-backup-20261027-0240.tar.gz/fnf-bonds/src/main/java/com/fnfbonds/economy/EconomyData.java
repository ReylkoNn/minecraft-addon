package com.fnfbonds.economy;

import com.fnfbonds.core.ModTags;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Per-dimension storage of every settlement and every player's ledger inside it.
 *
 * <p>Serialised as plain NBT wrapped in a {@link Codec} — 26.x {@link SavedData} is codec based, and
 * manual NBT keeps the schema trivially migratable ({@link #SCHEMA}).
 */
public final class EconomyData extends SavedData {
    public static final int SCHEMA = 1;
    public static final Identifier ID = ModTags.id("economy");
    public static final Codec<EconomyData> CODEC = CompoundTag.CODEC.xmap(EconomyData::read, EconomyData::write);
    public static final SavedDataType<EconomyData> TYPE = new SavedDataType<>(ID, EconomyData::new, CODEC);

    private final Map<Integer, Settlement> settlements = new HashMap<>();
    private int nextSettlementId = 1;

    public static EconomyData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(TYPE);
    }

    // ------------------------------------------------------------- settlements

    public Collection<Settlement> settlements() {
        return this.settlements.values();
    }

    public @Nullable Settlement settlement(int id) {
        return this.settlements.get(id);
    }

    public @Nullable Settlement settlementAt(BlockPos pos) {
        Settlement best = null;
        double bestDist = Double.MAX_VALUE;
        for (Settlement s : this.settlements.values()) {
            if (!s.contains(pos)) continue;
            double d = s.distanceTo(pos);
            if (d < bestDist) {
                bestDist = d;
                best = s;
            }
        }
        return best;
    }

    public @Nullable Settlement nearest(BlockPos pos, double maxDistance) {
        return this.settlements.values().stream()
                .filter(s -> s.distanceTo(pos) <= maxDistance)
                .min(Comparator.comparingDouble(s -> s.distanceTo(pos)))
                .orElse(null);
    }

    /** Settlements founded by a given player. */
    public List<Settlement> ownedBy(UUID playerId) {
        List<Settlement> out = new ArrayList<>();
        for (Settlement s : this.settlements.values()) {
            if (playerId.equals(s.owner)) out.add(s);
        }
        return out;
    }

    /**
     * Creates a settlement anchored at {@code center}.
     *
     * @return the new settlement, or {@code null} when it would violate the distance or
     *         per-player limits from the config.
     */
    public @Nullable Settlement createSettlement(ServerLevel level, BlockPos center, String name, UUID owner) {
        int radius = com.fnfbonds.FnfBondsConfig.SETTLEMENT_RADIUS.get();
        int minDistance = com.fnfbonds.FnfBondsConfig.SETTLEMENT_MIN_DISTANCE.get();
        int maxPerPlayer = com.fnfbonds.FnfBondsConfig.SETTLEMENT_MAX_PER_PLAYER.get();

        if (this.ownedBy(owner).size() >= maxPerPlayer) return null;
        for (Settlement other : this.settlements.values()) {
            if (other.center.distSqr(center) < (double) minDistance * minDistance) return null;
        }

        Settlement s = new Settlement();
        s.id = this.nextSettlementId++;
        s.name = name == null || name.isBlank() ? defaultName(level, s.id) : name;
        s.center = center.immutable();
        s.radius = radius;
        s.owner = owner;
        s.foundedDay = day(level);
        s.lastDailyTick = level.getGameTime();
        s.contractDay = -1;
        this.settlements.put(s.id, s);

        // Two-way routes between all known settlements: caravans need somewhere to go.
        for (Settlement other : this.settlements.values()) {
            if (other.id == s.id) continue;
            if (!s.routes.contains(other.id)) s.routes.add(other.id);
            if (!other.routes.contains(s.id)) other.routes.add(s.id);
        }

        this.setDirty();
        return s;
    }

    public void removeSettlement(int id) {
        if (this.settlements.remove(id) != null) {
            for (Settlement s : this.settlements.values()) s.routes.remove(Integer.valueOf(id));
            this.setDirty();
        }
    }

    private static String defaultName(ServerLevel level, int id) {
        return "Settlement #" + id;
    }

    public static long day(ServerLevel level) {
        return Math.floorDiv(level.getOverworldClockTime(), 24000L);
    }

    // --------------------------------------------------------------------- nbt

    private static CompoundTag write(EconomyData data) {
        CompoundTag tag = new CompoundTag();
        tag.putInt("schema", SCHEMA);
        tag.putInt("nextId", data.nextSettlementId);
        ListTag list = new ListTag();
        for (Settlement s : data.settlements.values()) list.add(s.write());
        tag.put("settlements", list);
        return tag;
    }

    private static EconomyData read(CompoundTag tag) {
        EconomyData data = new EconomyData();
        data.nextSettlementId = Math.max(1, tag.getIntOr("nextId", 1));
        ListTag list = tag.getListOrEmpty("settlements");
        for (int i = 0; i < list.size(); i++) {
            Settlement s = Settlement.read(list.getCompoundOrEmpty(i));
            data.settlements.put(s.id, s);
            data.nextSettlementId = Math.max(data.nextSettlementId, s.id + 1);
        }
        return data;
    }

    /** Convenience for event handlers: the settlement a player currently stands in, if any. */
    public static @Nullable Settlement at(ServerPlayer player) {
        if (player.level() instanceof ServerLevel level) {
            return get(level).settlementAt(player.blockPosition());
        }
        return null;
    }
}
