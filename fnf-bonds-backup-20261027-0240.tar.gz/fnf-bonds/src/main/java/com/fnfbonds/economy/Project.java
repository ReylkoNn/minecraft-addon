package com.fnfbonds.economy;

/**
 * Settlement upgrades. Paid with Contribution (earned, never spent anywhere else) plus emeralds,
 * and shared by every member of the settlement — a cooperative progression track.
 */
public enum Project {
    APIARY("apiary", 150, 24),
    WAREHOUSE("warehouse", 200, 32),
    WATCHTOWER("watchtower", 250, 40),
    MARKET_SQUARE("market_square", 300, 48),
    CELLAR("cellar", 180, 20),
    CHITIN_WORKS("chitin_works", 220, 36),
    MUSEUM("museum", 260, 44),
    SEAL_WORKS("seal_works", 320, 56),
    EMBASSY("embassy", 400, 64);

    public static final Project[] ALL = values();

    public final String path;
    public final int contributionCost;
    public final int emeraldCost;

    Project(String path, int contributionCost, int emeraldCost) {
        this.path = path;
        this.contributionCost = contributionCost;
        this.emeraldCost = emeraldCost;
    }

    public String translationKey() {
        return "project.fnfbonds." + this.path;
    }

    public String descriptionKey() {
        return "project.fnfbonds." + this.path + ".desc";
    }

    public static Project byOrdinal(int ordinal) {
        return ordinal >= 0 && ordinal < ALL.length ? ALL[ordinal] : null;
    }

    public static Project byPath(String path) {
        for (Project p : ALL) {
            if (p.path.equals(path)) return p;
        }
        return null;
    }
}
