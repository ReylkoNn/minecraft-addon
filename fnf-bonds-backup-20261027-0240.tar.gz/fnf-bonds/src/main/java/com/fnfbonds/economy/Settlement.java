package com.fnfbonds.economy;

import com.fnfbonds.FnfBondsConfig;
import com.fnfbonds.core.Commodity;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * A player-founded settlement: the anchor of the whole economy module.
 *
 * <p>Everything economic lives here — market pressure per commodity, threat level, built projects,
 * the contract board, caravans in transit, the "lost &amp; found" pool that crabs fill, and one
 * {@link PlayerRecord} per player who ever dealt with this settlement.
 */
public final class Settlement {
    public int id;
    public String name = "";
    public BlockPos center = BlockPos.ZERO;
    public int radius = 80;
    public @Nullable UUID owner;
    public long foundedDay;

    public final Map<UUID, PlayerRecord> players = new HashMap<>();
    public final float[] pressure = new float[Commodity.ALL.length];
    public int threat;
    public final Set<Project> projects = EnumSet.noneOf(Project.class);
    public final List<Contract> contracts = new ArrayList<>();
    public final List<Caravan> caravans = new ArrayList<>();
    public final List<LostItem> lostLoot = new ArrayList<>();
    /** Settlement ids this one may send caravans to. */
    public final List<Integer> routes = new ArrayList<>();

    /** Positions of the anchor blocks; {@link BlockPos#ZERO} means "not built". */
    public BlockPos deskPos = BlockPos.ZERO;
    public BlockPos boardPos = BlockPos.ZERO;
    public BlockPos postPos = BlockPos.ZERO;

    public long lastDailyTick;
    public long contractDay = -1;
    public int nextContractId = 1;
    public int nextCaravanId = 1;

    /** One entry of the "lost &amp; found" pool a crab scavenges into. */
    public record LostItem(Identifier item, int count) {
        public CompoundTag write() {
            CompoundTag tag = new CompoundTag();
            tag.putString("item", this.item.toString());
            tag.putInt("count", this.count);
            return tag;
        }

        public static LostItem read(CompoundTag tag) {
            Identifier id;
            try {
                id = Identifier.parse(tag.getStringOr("item", ""));
            } catch (Exception e) {
                id = Identifier.withDefaultNamespace("stick");
            }
            return new LostItem(id, Math.max(1, tag.getIntOr("count", 0)));
        }
    }

    // ----------------------------------------------------------------- queries

    public boolean contains(BlockPos pos) {
        return pos.closerThan(this.center, this.radius + 0.5D);
    }

    public double distanceTo(BlockPos pos) {
        return Math.sqrt(pos.distSqr(this.center));
    }

    public PlayerRecord record(UUID playerId) {
        return this.players.computeIfAbsent(playerId, id -> new PlayerRecord());
    }

    public @Nullable PlayerRecord recordIfPresent(UUID playerId) {
        return this.players.get(playerId);
    }

    public boolean hasBoard() {
        return !this.boardPos.equals(BlockPos.ZERO);
    }

    public boolean hasPost() {
        return !this.postPos.equals(BlockPos.ZERO);
    }

    public boolean isAnchored() {
        return !this.deskPos.equals(BlockPos.ZERO);
    }

    public boolean has(Project project) {
        return this.projects.contains(project);
    }

    public int contractSlots() {
        int slots = FnfBondsConfig.CONTRACT_SLOTS.get();
        if (this.has(Project.MARKET_SQUARE)) slots++;
        return slots;
    }

    public int caravanSlots(UUID playerId) {
        int slots = this.record(playerId).tier().caravanSlots;
        if (this.has(Project.WAREHOUSE)) slots++;
        return slots;
    }

    /** Cargo capacity of one caravan, boosted by the warehouse project. */
    public int caravanCapacity() {
        int base = 64;
        return this.has(Project.WAREHOUSE) ? base + base / 2 : base;
    }

    // ------------------------------------------------------------------ market

    /** Situational threat modifier applied on top of raw supply/demand pressure. */
    private float threatModifier(Commodity c) {
        if (this.threat >= 30) {
            return switch (c) {
                case METAL, CHITIN, FROST, NETHER -> 1.35f;
                case GRAIN, PRODUCE, LIVESTOCK, FISH -> 0.75f;
                default -> 0.90f;
            };
        }
        if (this.threat >= 15) {
            return switch (c) {
                case METAL, CHITIN, FROST -> 1.25f;
                case GRAIN, PRODUCE -> 0.80f;
                default -> 1.0f;
            };
        }
        return 1.0f;
    }

    public float multiplier(Commodity c) {
        float raw = 1.0f + this.pressure[c.ordinal()] * (this.has(Project.MARKET_SQUARE) ? 0.5f : 1.0f);
        raw *= threatModifier(c);
        if (this.has(Project.CELLAR) && (c == Commodity.FISH || c == Commodity.PRODUCE || c == Commodity.FROST)) {
            raw = Math.max(0.8f, raw);
        }
        float min = FnfBondsConfig.MARKET_MIN.get().floatValue();
        float max = FnfBondsConfig.MARKET_MAX.get().floatValue();
        return Mth.clamp(raw, min, max);
    }

    /** Emeralds per unit for a player of the given standing tier. */
    public float price(Commodity c, Standing standing) {
        return c.basePrice * multiplier(c) * standing.priceMultiplier;
    }

    public void applySellPressure(Commodity c, int units) {
        this.pressure[c.ordinal()] = Mth.clamp(this.pressure[c.ordinal()] - units * c.weight, -1.6f, 1.6f);
    }

    public void applyBuyPressure(Commodity c, int units) {
        this.pressure[c.ordinal()] = Mth.clamp(this.pressure[c.ordinal()] + units * c.weight, -1.6f, 1.6f);
    }

    // ------------------------------------------------------------------- nbt

    public CompoundTag write() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("id", this.id);
        tag.putString("name", this.name);
        tag.putLong("center", this.center.asLong());
        tag.putInt("radius", this.radius);
        tag.putString("owner", this.owner == null ? "" : this.owner.toString());
        tag.putLong("foundedDay", this.foundedDay);
        tag.putInt("threat", this.threat);
        tag.putLong("deskPos", this.deskPos.asLong());
        tag.putLong("boardPos", this.boardPos.asLong());
        tag.putLong("postPos", this.postPos.asLong());
        tag.putLong("lastDailyTick", this.lastDailyTick);
        tag.putLong("contractDay", this.contractDay);
        tag.putInt("nextContractId", this.nextContractId);
        tag.putInt("nextCaravanId", this.nextCaravanId);

        ListTag pressures = new ListTag();
        for (float p : this.pressure) pressures.add(net.minecraft.nbt.FloatTag.valueOf(p));
        tag.put("pressure", pressures);

        ListTag built = new ListTag();
        for (Project p : this.projects) built.add(net.minecraft.nbt.StringTag.valueOf(p.path));
        tag.put("projects", built);

        ListTag playerList = new ListTag();
        this.players.forEach((uuid, record) -> {
            CompoundTag entry = record.write();
            entry.putString("uuid", uuid.toString());
            playerList.add(entry);
        });
        tag.put("players", playerList);

        tag.put("contracts", writeList(this.contracts, Contract::write));
        tag.put("caravans", writeList(this.caravans, Caravan::write));
        tag.put("lostLoot", writeList(this.lostLoot, LostItem::write));

        ListTag routes = new ListTag();
        for (int route : this.routes) routes.add(net.minecraft.nbt.IntTag.valueOf(route));
        tag.put("routes", routes);
        return tag;
    }

    private static <T> ListTag writeList(List<T> list, java.util.function.Function<T, CompoundTag> writer) {
        ListTag out = new ListTag();
        for (T entry : list) out.add(writer.apply(entry));
        return out;
    }

    public static Settlement read(CompoundTag tag) {
        Settlement s = new Settlement();
        s.id = tag.getIntOr("id", 0);
        s.name = tag.getStringOr("name", "");
        s.center = BlockPos.of(tag.getLongOr("center", 0L));
        s.radius = tag.getIntOr("radius", 0) <= 0 ? 80 : tag.getIntOr("radius", 0);
        String owner = tag.getStringOr("owner", "");
        if (!owner.isEmpty()) {
            try {
                s.owner = UUID.fromString(owner);
            } catch (IllegalArgumentException ignored) {
                s.owner = null;
            }
        }
        s.foundedDay = tag.getLongOr("foundedDay", 0L);
        s.threat = tag.getIntOr("threat", 0);
        s.deskPos = BlockPos.of(tag.getLongOr("deskPos", 0L));
        s.boardPos = BlockPos.of(tag.getLongOr("boardPos", 0L));
        s.postPos = BlockPos.of(tag.getLongOr("postPos", 0L));
        s.lastDailyTick = tag.getLongOr("lastDailyTick", 0L);
        s.contractDay = tag.getLongOr("contractDay", 0L);
        s.nextContractId = Math.max(1, tag.getIntOr("nextContractId", 0));
        s.nextCaravanId = Math.max(1, tag.getIntOr("nextCaravanId", 0));

        ListTag pressures = tag.getListOrEmpty("pressure");
        for (int i = 0; i < pressures.size() && i < s.pressure.length; i++) s.pressure[i] = pressures.getFloatOr(i, 0F);

        s.projects.clear();
        ListTag built = tag.getListOrEmpty("projects");
        for (int i = 0; i < built.size(); i++) {
            Project p = Project.byPath(built.getStringOr(i, ""));
            if (p != null) s.projects.add(p);
        }

        s.players.clear();
        ListTag playerList = tag.getListOrEmpty("players");
        for (int i = 0; i < playerList.size(); i++) {
            CompoundTag entry = playerList.getCompoundOrEmpty(i);
            try {
                s.players.put(UUID.fromString(entry.getStringOr("uuid", "")), PlayerRecord.read(entry));
            } catch (IllegalArgumentException ignored) {
                // stale record, drop it
            }
        }

        s.contracts.clear();
        ListTag contracts = tag.getListOrEmpty("contracts");
        for (int i = 0; i < contracts.size(); i++) s.contracts.add(Contract.read(contracts.getCompoundOrEmpty(i)));

        s.caravans.clear();
        ListTag caravans = tag.getListOrEmpty("caravans");
        for (int i = 0; i < caravans.size(); i++) s.caravans.add(Caravan.read(caravans.getCompoundOrEmpty(i)));

        s.lostLoot.clear();
        ListTag loot = tag.getListOrEmpty("lostLoot");
        for (int i = 0; i < loot.size(); i++) s.lostLoot.add(LostItem.read(loot.getCompoundOrEmpty(i)));

        s.routes.clear();
        ListTag routes = tag.getListOrEmpty("routes");
        for (int i = 0; i < routes.size(); i++) s.routes.add(routes.getIntOr(i, 0));
        return s;
    }
}
