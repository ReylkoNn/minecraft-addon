package com.fnfbonds.economy;

import com.fnfbonds.core.Commodity;
import net.minecraft.nbt.CompoundTag;

import java.util.UUID;

/**
 * A caravan in transit between two settlements. Progress is measured in game time, so caravans keep
 * moving while the player is offline.
 */
public final class Caravan {
    public int id;
    public Commodity commodity = Commodity.GRAIN;
    public int amount;
    public int destination;
    public long departAt;
    public long arriveAt;
    public UUID owner;
    /** Set when the caravan was ambushed and the escort window is running. */
    public boolean raided;
    public boolean raidRolled;
    public long raidUntil;
    /** Mobs killed while defending this caravan; clearing the raid saves the cargo. */
    public int escortKills;
    public int escortNeeded;
    /** Payout locked in when the caravan departs, recomputed on arrival. */
    public float payout;

    public boolean hasArrived(long gameTime) {
        return gameTime >= this.arriveAt;
    }

    public float progress(long gameTime) {
        if (this.arriveAt <= this.departAt) return 1.0f;
        return Math.clamp((float) (gameTime - this.departAt) / (float) (this.arriveAt - this.departAt), 0.0f, 1.0f);
    }

    public CompoundTag write() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("id", this.id);
        tag.putInt("commodity", this.commodity.ordinal());
        tag.putInt("amount", this.amount);
        tag.putInt("dest", this.destination);
        tag.putLong("depart", this.departAt);
        tag.putLong("arrive", this.arriveAt);
        tag.putString("owner", this.owner == null ? "" : this.owner.toString());
        tag.putBoolean("raided", this.raided);
        tag.putBoolean("raidRolled", this.raidRolled);
        tag.putLong("raidUntil", this.raidUntil);
        tag.putInt("escortKills", this.escortKills);
        tag.putInt("escortNeeded", this.escortNeeded);
        tag.putFloat("payout", this.payout);
        return tag;
    }

    public static Caravan read(CompoundTag tag) {
        Caravan c = new Caravan();
        c.id = tag.getIntOr("id", 0);
        c.commodity = Commodity.byOrdinal(tag.getIntOr("commodity", 0));
        if (c.commodity == null) c.commodity = Commodity.GRAIN;
        c.amount = tag.getIntOr("amount", 0);
        c.destination = tag.getIntOr("dest", 0);
        c.departAt = tag.getLongOr("depart", 0L);
        c.arriveAt = tag.getLongOr("arrive", 0L);
        String owner = tag.getStringOr("owner", "");
        if (!owner.isEmpty()) {
            try {
                c.owner = UUID.fromString(owner);
            } catch (IllegalArgumentException ignored) {
                c.owner = null;
            }
        }
        c.raided = tag.getBooleanOr("raided", false);
        c.raidRolled = tag.getBooleanOr("raidRolled", false);
        c.raidUntil = tag.getLongOr("raidUntil", 0L);
        c.escortKills = tag.getIntOr("escortKills", 0);
        c.escortNeeded = tag.getIntOr("escortNeeded", 0);
        c.payout = tag.getFloatOr("payout", 0F);
        return c;
    }
}
