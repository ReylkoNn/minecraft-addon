package com.fnfbonds.economy;

import com.fnfbonds.FnfBondsConfig;
import com.fnfbonds.core.Commodity;
import com.fnfbonds.core.FnfRefs;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Deterministic daily contract rolls.
 *
 * <p>The seed is {@code levelSeed ^ settlementId ^ day}, so every player of a settlement sees the
 * same board on the same day, and the board is stable across restarts. Which contracts can appear
 * depends on the settlement context: threat unlocks purge orders, routes unlock escort orders, and
 * Friends&amp;Foes species unlock hunt/herd orders (skipped when the base mod is not installed).
 */
public final class ContractGenerator {
    private ContractGenerator() {}

    private static final Identifier[] HUNT_TARGETS = {
            FnfRefs.MAULER, FnfRefs.BARNACLE, FnfRefs.ICEOLOGER, FnfRefs.ILLUSIONER, FnfRefs.WILDFIRE
    };

    private static final Identifier[] HERD_TARGETS = {
            FnfRefs.MOOBLOOM, FnfRefs.CRAB, FnfRefs.PENGUIN, FnfRefs.GLARE, FnfRefs.TUFF_GOLEM
    };

    private static final String[] BUILD_TARGETS = {
            "minecraft:oak_planks", "minecraft:cobblestone", "minecraft:stone_bricks",
            "minecraft:oak_stairs", "minecraft:cobblestone_wall", "minecraft:glass",
            "minecraft:polished_andesite", "minecraft:deepslate_bricks"
    };

    private static final Settlement.LostItem[] LOST_LOOT_POOL = {
            new Settlement.LostItem(Identifier.withDefaultNamespace("stick"), 6),
            new Settlement.LostItem(Identifier.withDefaultNamespace("leather"), 2),
            new Settlement.LostItem(Identifier.withDefaultNamespace("iron_nugget"), 5),
            new Settlement.LostItem(Identifier.withDefaultNamespace("gold_nugget"), 3),
            new Settlement.LostItem(Identifier.withDefaultNamespace("wheat_seeds"), 8),
            new Settlement.LostItem(Identifier.withDefaultNamespace("fishing_rod"), 1),
            new Settlement.LostItem(Identifier.withDefaultNamespace("compass"), 1),
            new Settlement.LostItem(Identifier.withDefaultNamespace("emerald"), 1),
            new Settlement.LostItem(Identifier.withDefaultNamespace("book"), 2),
            new Settlement.LostItem(Identifier.withDefaultNamespace("amethyst_shard"), 2),
    };

    /** @return true when the board changed. */
    public static boolean roll(ServerLevel level, Settlement s, boolean force) {
        long day = EconomyData.day(level);
        if (!force && s.contractDay == day) return false;
        s.contractDay = day;

        s.contracts.removeIf(c -> c.isExpired(day));
        int slots = s.contractSlots();
        RandomSource random = RandomSource.create(level.getSeed() ^ ((long) s.id * 7919L + day * 104729L));

        int attempts = 0;
        while (s.contracts.size() < slots && attempts++ < 24) {
            Contract contract = generate(level, s, day, random);
            if (contract == null) continue;
            boolean duplicate = s.contracts.stream()
                    .anyMatch(c -> c.type == contract.type && c.target.equals(contract.target));
            if (!duplicate) s.contracts.add(contract);
        }
        return true;
    }

    private static @Nullable Contract generate(ServerLevel level, Settlement s, long day, RandomSource random) {
        List<ContractType> pool = new ArrayList<>();
        int maxTier = 1 + s.projects.size() / 2;
        maxTier = Math.min(5, Math.max(1, maxTier));

        pool.add(ContractType.DELIVERY);
        pool.add(ContractType.DELIVERY);
        pool.add(ContractType.APIARY);
        pool.add(ContractType.BUILD);
        pool.add(ContractType.LIGHT);
        if (hasAny(HUNT_TARGETS)) {
            pool.add(ContractType.HUNT);
            pool.add(ContractType.HUNT);
        }
        if (hasAny(HERD_TARGETS)) pool.add(ContractType.HERD);
        if (!s.routes.isEmpty()) pool.add(ContractType.ESCORT);
        if (s.threat >= 5) pool.add(ContractType.CLEANSE);

        ContractType type = pool.get(random.nextInt(pool.size()));
        int tier = 1 + random.nextInt(maxTier);
        if (tier < type.minTier) tier = type.minTier;
        if (tier > 5) return null;

        Contract c = new Contract();
        c.id = s.nextContractId++;
        c.type = type;
        c.tier = tier;
        c.expiresAtDay = day + FnfBondsConfig.CONTRACT_EXPIRY_DAYS.get();

        switch (type) {
            case DELIVERY -> {
                Commodity commodity = Commodity.ALL[random.nextInt(Commodity.ALL.length)];
                c.target = commodity.path;
                c.amount = (8 + random.nextInt(12)) * tier;
            }
            case HUNT -> {
                Identifier target = pickAvailable(HUNT_TARGETS, random);
                if (target == null) return null;
                c.target = target.toString();
                c.amount = target.equals(FnfRefs.WILDFIRE) ? 1 : Math.max(1, 6 - tier + random.nextInt(3));
                if (target.equals(FnfRefs.WILDFIRE) || target.equals(FnfRefs.ILLUSIONER)) c.tier = Math.max(c.tier, 4);
            }
            case HERD -> {
                Identifier target = pickAvailable(HERD_TARGETS, random);
                if (target == null) return null;
                c.target = target.toString();
                c.amount = 1 + random.nextInt(2) + tier / 3;
            }
            case APIARY -> {
                c.target = "";
                c.amount = 2 + tier + random.nextInt(3);
            }
            case BUILD -> {
                c.target = BUILD_TARGETS[random.nextInt(BUILD_TARGETS.length)];
                c.amount = (12 + random.nextInt(20)) * tier;
            }
            case LIGHT -> {
                c.target = "";
                c.amount = 4 + tier * 2 + random.nextInt(4);
            }
            case ESCORT -> {
                c.target = "";
                c.amount = 1 + random.nextInt(Math.max(1, tier / 2));
            }
            case CLEANSE -> {
                c.target = "";
                c.amount = (4 + random.nextInt(6)) * tier;
            }
        }

        double scale = FnfBondsConfig.CONTRACT_REWARD_SCALE.get();
        c.rewardEmeralds = (int) Math.max(1, Math.round((6 + 5.5 * c.tier + 0.12 * c.amount) * scale));
        c.rewardStanding = (int) Math.round((6 + 7.5 * c.tier) * scale);
        c.rewardContribution = 8 * c.tier;
        c.rewardSeals = Math.max(1, c.tier / 2);
        return c;
    }

    private static boolean hasAny(Identifier[] ids) {
        for (Identifier id : ids) {
            if (FnfRefs.has(id)) return true;
        }
        return false;
    }

    private static @Nullable Identifier pickAvailable(Identifier[] ids, RandomSource random) {
        List<Identifier> available = new ArrayList<>();
        for (Identifier id : ids) {
            if (FnfRefs.has(id)) available.add(id);
        }
        return available.isEmpty() ? null : available.get(random.nextInt(available.size()));
    }

    /** What a crab scavenges into the settlement's lost &amp; found. */
    public static Settlement.LostItem randomLostLoot(RandomSource random) {
        return LOST_LOOT_POOL[random.nextInt(LOST_LOOT_POOL.length)];
    }
}
