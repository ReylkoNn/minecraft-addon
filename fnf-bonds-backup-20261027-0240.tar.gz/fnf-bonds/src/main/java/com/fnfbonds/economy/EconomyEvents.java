package com.fnfbonds.economy;

import com.fnfbonds.FnfBondsConfig;
import com.fnfbonds.core.Commodity;
import com.fnfbonds.core.FnfRefs;
import com.fnfbonds.core.ModTags;
import com.fnfbonds.network.Network;
import com.fnfbonds.registry.ModBlocks;
import com.fnfbonds.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.npc.villager.AbstractVillager;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.entity.player.TradeWithVillagerEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.level.LevelEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

import java.util.UUID;

/**
 * Every place where the world feeds the economy. All handlers are cheap and short-circuit when the
 * player is not inside a settlement.
 */
@EventBusSubscriber(modid = com.fnfbonds.FnfBonds.MODID)
public final class EconomyEvents {
    private EconomyEvents() {}

    // ------------------------------------------------------------------ ticking

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (event.getLevel() instanceof ServerLevel level && FnfBondsConfig.MODULE_ECONOMY.get()) {
            EconomyTicker.onLevelTick(level);
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!FnfBondsConfig.MODULE_ECONOMY.get()) return;
        if (player.level().getGameTime() % 20L != 0L) return;

        Settlement settlement = EconomyData.at(player);
        if (settlement == null) {
            ClientHudState.clear(player.getUUID());
            return;
        }
        if (FnfBondsConfig.HUD_ENABLED.get()) Network.sendHud(player, settlement);
        ClientHudState.mark(player.getUUID(), settlement.id);
    }

    @SubscribeEvent
    public static void onLevelUnload(LevelEvent.Unload event) {
        if (event.getLevel() instanceof ServerLevel) ClientHudState.clearAll();
    }

    // ------------------------------------------------------------------- death

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof Mob victim)) return;
        if (!(victim.level() instanceof ServerLevel level)) return;
        if (!FnfBondsConfig.MODULE_ECONOMY.get()) return;

        Settlement settlement = EconomyData.get(level).settlementAt(victim.blockPosition());
        if (settlement == null) return;

        Identifier species = BuiltInRegistries.ENTITY_TYPE.getKey(victim.getType());
        boolean grudge = victim.getType().builtInRegistryHolder().is(ModTags.GRUDGE_MOBS);
        boolean hostile = victim.getType().builtInRegistryHolder().is(ModTags.HOSTILE_MOBS)
                || victim.getType().builtInRegistryHolder().is(EntityTypeTags.RAIDERS)
                || victim.getType().builtInRegistryHolder().is(EntityTypeTags.UNDEAD);

        ServerPlayer killer = event.getSource().getEntity() instanceof ServerPlayer player ? player : null;

        if (grudge && killer != null) {
            Actions.onGrudge(level, settlement, killer, victim);
            return;
        }

        if (!hostile) return;

        // caravan escort: kills during an ambush save the cargo
        for (Caravan caravan : settlement.caravans) {
            if (caravan.raided && caravan.escortKills < caravan.escortNeeded) caravan.escortKills++;
        }

        if (killer != null) {
            PlayerRecord record = settlement.record(killer.getUUID());
            record.addStanding(species.equals(FnfRefs.ICEOLOGER) || species.equals(FnfRefs.ILLUSIONER) ? 3 : 2);
            record.contribution += 2;
            record.addKinship(species.toString(), 1);
            for (Contract contract : settlement.contracts) {
                if (!killer.getUUID().equals(contract.owner) || contract.isComplete()) continue;
                if (contract.type == ContractType.HUNT && contract.target.equals(species.toString())) contract.progress++;
                if (contract.type == ContractType.CLEANSE) contract.progress++;
            }
        }
        EconomyTicker.updateThreat(level, settlement);
        EconomyData.get(level).setDirty();
    }

    // ----------------------------------------------------------- block placing

    @SubscribeEvent
    public static void onBlockPlaced(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (!FnfBondsConfig.MODULE_ECONOMY.get()) return;

        BlockPos pos = event.getPos();
        Settlement settlement = EconomyData.get(level).settlementAt(pos);
        if (settlement == null) return;

        PlayerRecord record = settlement.record(player.getUUID());
        boolean light = event.getState().is(ModTags.LIGHT_SOURCES);
        for (Contract contract : settlement.contracts) {
            if (!player.getUUID().equals(contract.owner) || contract.isComplete()) continue;
            if (contract.type == ContractType.BUILD && contract.target.equals(
                    BuiltInRegistries.BLOCK.getKey(event.getState().getBlock()).toString())) {
                contract.progress++;
            } else if (contract.type == ContractType.LIGHT && light) {
                contract.progress++;
            }
        }
        if (light) {
            record.addStanding(0);
            settlement.threat = Math.max(0, settlement.threat - 1);
        }
        EconomyData.get(level).setDirty();
    }

    // -------------------------------------------------------------- villager trade

    @SubscribeEvent
    public static void onTrade(TradeWithVillagerEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(player.level() instanceof ServerLevel level)) return;
        if (!FnfBondsConfig.MODULE_ECONOMY.get()) return;

        Settlement settlement = EconomyData.get(level).settlementAt(player.blockPosition());
        if (settlement == null) return;

        PlayerRecord record = settlement.record(player.getUUID());
        ItemStack cost = event.getMerchantOffer().getCostA();
        ItemStack result = event.getMerchantOffer().getResult();
        Commodity bought = Commodity.of(result);
        Commodity sold = Commodity.of(cost);
        if (bought != null) settlement.applyBuyPressure(bought, result.getCount());
        if (sold != null) settlement.applySellPressure(sold, cost.getCount());
        record.contribution += 1;
        record.addStanding(1);
        EconomyData.get(level).setDirty();
    }

    // ------------------------------------------------------------- interactions

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(player.level() instanceof ServerLevel level)) return;
        if (!FnfBondsConfig.MODULE_ECONOMY.get()) return;

        Settlement settlement = EconomyData.get(level).settlementAt(player.blockPosition());
        if (settlement == null) return;
        PlayerRecord record = settlement.record(player.getUUID());
        long day = EconomyData.day(level);
        ItemStack hand = player.getMainHandItem();

        // sharing mead with a villager is the cheapest standing there is — once a day
        if (event.getTarget() instanceof AbstractVillager villager && hand.is(ModItems.MEAD.get())) {
            if (record.lastMeadDay == day) {
                Actions.warn(player, "chat.fnfbonds.error.mead_cooldown");
                return;
            }
            record.lastMeadDay = day;
            record.addStanding(1);
            hand.shrink(1);
            villager.setPersistenceRequired();
            player.sendSystemMessage(Component.translatable("chat.fnfbonds.mead.shared")
                    .withStyle(ChatFormatting.GOLD));
            EconomyData.get(level).setDirty();
            return;
        }

        // herding a friendly Friends&Foes species: credited once per species per day
        if (event.getTarget() instanceof Mob mob && mob.getType().builtInRegistryHolder().is(ModTags.FRIENDLY_MOBS)) {
            Identifier species = BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType());
            Long last = record.herdDays.get(species.toString());
            if (last != null && last == day) return;
            record.herdDays.put(species.toString(), day);
            Actions.onFriendlyMobEntered(level, settlement, player, mob);
            player.sendSystemMessage(Component.translatable("chat.fnfbonds.herd.credit",
                            Component.translatable("entity." + species.getNamespace() + "." + species.getPath()))
                    .withStyle(ChatFormatting.GREEN));
            for (Contract contract : settlement.contracts) {
                if (contract.type == ContractType.HERD && player.getUUID().equals(contract.owner)) {
                    Actions.refreshLiveProgress(level, settlement, contract);
                }
            }
        }
    }

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (!FnfBondsConfig.MODULE_ECONOMY.get()) return;
        if (!(event.getEntity() instanceof Mob mob)) return;
        if (!mob.getType().builtInRegistryHolder().is(ModTags.HOSTILE_MOBS)) return;

        Settlement settlement = EconomyData.get(level).settlementAt(mob.blockPosition());
        if (settlement != null) EconomyTicker.updateThreat(level, settlement);
    }

    @SubscribeEvent
    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!FnfBondsConfig.MODULE_ECONOMY.get()) return;
        if (EconomyData.get(player.level()).settlements().isEmpty() && !FnfRefs.fnfLoaded()) {
            Actions.logMissing("Friends&Foes");
        }
    }

    // ------------------------------------------------------- settlement anchors

    /** Called by the anchor blocks when they are placed or broken. */
    public static void onAnchorPlaced(ServerLevel level, BlockPos pos, String kind) {
        Settlement settlement = EconomyData.get(level).nearest(pos, 24);
        if (settlement == null) {
            settlement = EconomyData.get(level).settlementAt(pos);
        }
        if (settlement == null) return;
        switch (kind) {
            case "desk" -> settlement.deskPos = pos.immutable();
            case "board" -> settlement.boardPos = pos.immutable();
            case "post" -> settlement.postPos = pos.immutable();
            default -> {
            }
        }
        EconomyData.get(level).setDirty();
    }

    public static void onAnchorBroken(ServerLevel level, BlockPos pos) {
        Settlement settlement = EconomyData.get(level).settlementAt(pos);
        if (settlement == null) settlement = EconomyData.get(level).nearest(pos, 24);
        if (settlement == null) return;
        if (pos.equals(settlement.deskPos)) settlement.deskPos = BlockPos.ZERO;
        if (pos.equals(settlement.boardPos)) settlement.boardPos = BlockPos.ZERO;
        if (pos.equals(settlement.postPos)) settlement.postPos = BlockPos.ZERO;
        EconomyData.get(level).setDirty();
    }

    public static boolean isAnchor(BlockPos pos, Level level) {
        return level.getBlockState(pos).is(ModBlocks.LEDGER_DESK.get())
                || level.getBlockState(pos).is(ModBlocks.CONTRACT_BOARD.get())
                || level.getBlockState(pos).is(ModBlocks.TRADE_POST.get());
    }

    /** Server-side mirror of "is the HUD currently showing a settlement" for commands. */
    public static final class ClientHudState {
        private static final java.util.Map<UUID, Integer> LAST = new java.util.HashMap<>();

        static void mark(UUID id, int settlementId) {
            LAST.put(id, settlementId);
        }

        static void clear(UUID id) {
            LAST.remove(id);
        }

        static void clearAll() {
            LAST.clear();
        }

        public static boolean inSettlement(UUID id) {
            return LAST.containsKey(id);
        }
    }
}
