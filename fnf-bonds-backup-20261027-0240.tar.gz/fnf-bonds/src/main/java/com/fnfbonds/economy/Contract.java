package com.fnfbonds.economy;

import com.fnfbonds.core.Commodity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;

import java.util.UUID;

/** A single procedural contract on a settlement's board. */
public final class Contract {
    public int id;
    public ContractType type = ContractType.DELIVERY;
    /** Commodity path, entity id, block id or "" depending on {@link #type}. */
    public String target = "";
    public int amount = 1;
    public int progress;
    public int tier = 1;
    public int rewardEmeralds;
    public int rewardStanding;
    public int rewardContribution;
    public int rewardSeals;
    public long expiresAtDay;
    public @Nullable UUID owner;

    public boolean isComplete() {
        return this.progress >= this.amount;
    }

    public boolean isExpired(long day) {
        return day > this.expiresAtDay;
    }

    public float completion() {
        return this.amount <= 0 ? 1.0f : Math.min(1.0f, (float) this.progress / (float) this.amount);
    }

    // ------------------------------------------------------------------ text

    public Component title() {
        return switch (this.type) {
            case DELIVERY -> {
                Commodity c = Commodity.byPath(this.target);
                yield Component.translatable(this.type.titleKey(),
                        c == null ? Component.literal(this.target) : Component.translatable(c.translationKey()));
            }
            case HUNT, HERD -> Component.translatable(this.type.titleKey(), mobName(this.target));
            case BUILD -> Component.translatable(this.type.titleKey(), blockName(this.target));
            default -> Component.translatable(this.type.titleKey());
        };
    }

    public Component goal() {
        return switch (this.type) {
            case DELIVERY -> Component.translatable(this.type.goalKey(), this.amount, commodityName(this.target));
            case HUNT, HERD -> Component.translatable(this.type.goalKey(), this.amount, mobName(this.target));
            case BUILD -> Component.translatable(this.type.goalKey(), this.amount, blockName(this.target));
            case APIARY, LIGHT, ESCORT, CLEANSE -> Component.translatable(this.type.goalKey(), this.amount);
        };
    }

    private static Component mobName(String id) {
        Identifier parsed = tryParse(id);
        return parsed == null
                ? Component.literal(id)
                : Component.translatable("entity." + parsed.getNamespace() + "." + parsed.getPath());
    }

    private static Component blockName(String id) {
        Identifier parsed = tryParse(id);
        return parsed == null
                ? Component.literal(id)
                : Component.translatable("block." + parsed.getNamespace() + "." + parsed.getPath());
    }

    private static Component commodityName(String path) {
        Commodity c = Commodity.byPath(path);
        return c == null ? Component.literal(path) : Component.translatable(c.translationKey());
    }

    private static @Nullable Identifier tryParse(String raw) {
        try {
            return Identifier.parse(raw);
        } catch (Exception e) {
            return null;
        }
    }

    // ------------------------------------------------------------------- nbt

    public CompoundTag write() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("id", this.id);
        tag.putInt("type", this.type.ordinal());
        tag.putString("target", this.target);
        tag.putInt("amount", this.amount);
        tag.putInt("progress", this.progress);
        tag.putInt("tier", this.tier);
        tag.putInt("em", this.rewardEmeralds);
        tag.putInt("st", this.rewardStanding);
        tag.putInt("ct", this.rewardContribution);
        tag.putInt("sl", this.rewardSeals);
        tag.putLong("exp", this.expiresAtDay);
        if (this.owner != null) tag.putString("owner", this.owner.toString());
        return tag;
    }

    public static Contract read(CompoundTag tag) {
        Contract c = new Contract();
        c.id = tag.getIntOr("id", 0);
        c.type = ContractType.byOrdinal(tag.getIntOr("type", 0));
        c.target = tag.getStringOr("target", "");
        c.amount = tag.getIntOr("amount", 0);
        c.progress = tag.getIntOr("progress", 0);
        c.tier = tag.getIntOr("tier", 0);
        c.rewardEmeralds = tag.getIntOr("em", 0);
        c.rewardStanding = tag.getIntOr("st", 0);
        c.rewardContribution = tag.getIntOr("ct", 0);
        c.rewardSeals = tag.getIntOr("sl", 0);
        c.expiresAtDay = tag.getLongOr("exp", 0L);
        String owner = tag.getStringOr("owner", "");
        if (!owner.isEmpty()) {
            try {
                c.owner = UUID.fromString(owner);
            } catch (IllegalArgumentException ignored) {
                c.owner = null;
            }
        }
        return c;
    }
}
