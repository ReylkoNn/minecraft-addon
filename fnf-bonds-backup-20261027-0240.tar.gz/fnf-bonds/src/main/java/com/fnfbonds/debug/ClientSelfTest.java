package com.fnfbonds.debug;

import com.fnfbonds.FnfBonds;
import com.fnfbonds.FnfBondsConfig;
import com.fnfbonds.client.ClientPayloadHandler;
import com.fnfbonds.client.LedgerScreen;
import com.mojang.blaze3d.pipeline.RenderTarget;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.events.ContainerEventHandler;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.worldselection.CreateWorldScreen;
import net.minecraft.client.input.InputWithModifiers;
import net.minecraft.world.level.storage.LevelStorageSource;
import net.minecraft.world.level.storage.LevelSummary;

import java.util.concurrent.TimeUnit;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Headless client self-test: renders the real GUI and HUD and writes screenshots to
 * {@code run/screenshots/}.
 *
 * <p>Disabled unless the JVM is started with {@code -Dfnfbonds.clienttest=true}
 * ({@code -Dfnfbonds.clienttest.world=false} skips the in-world part and only shoots the screens at
 * the main menu). It exists because a GUI can compile, boot and still be unusable: overlapping text,
 * a button drawn outside the panel, a tab that never refreshes. The server self-test cannot see any
 * of that.
 *
 * <p>What it does, in order:
 * <ol>
 *   <li>waits for the title screen (resources loaded, fonts ready);</li>
 *   <li>opens {@link LedgerScreen} on each of the five tabs with {@link LedgerFixture} and grabs the
 *       framebuffer after a few rendered frames;</li>
 *   <li>creates a throw-away flat test world through vanilla's own
 *       {@link CreateWorldScreen#testWorld} so there is a level and a player;</li>
 *   <li>injects a HUD snapshot and shoots the HUD, then the ledger opened in-world;</li>
 *   <li>logs one summary line and stops the client.</li>
 * </ol>
 *
 * <p>Screenshots are taken from {@code Minecraft#gameRenderer.mainRenderTarget()} at client-tick
 * time, i.e. the framebuffer still holds the last fully drawn frame. Writes happen on the IO pool, so
 * the test waits a few extra ticks before shutting down.
 */
@EventBusSubscriber(modid = FnfBonds.MODID, value = Dist.CLIENT)
public final class ClientSelfTest {
    /** JVM flag that turns the test on. */
    public static final String PROPERTY = "fnfbonds.clienttest";

    private static final String[] TABS = {"overview", "contracts", "market", "caravans", "projects"};

    /** Frames to let the renderer settle before reading the framebuffer. */
    private static final int RENDER_TICKS = 12;

    /**
     * Deadlines are wall clock, not ticks: on a software renderer with a small heap the resource
     * reload alone can take minutes while the client still ticks twenty times a second, and a
     * tick budget would run out before the title screen was ever drawn.
     */
    private static final long BOOT_DEADLINE_MS = 10 * 60 * 1000L;
    private static final long WORLD_LOAD_DEADLINE_MS = 8 * 60 * 1000L;
    private static final long TOTAL_DEADLINE_MS = 25 * 60 * 1000L;
    /** How long a non-title screen may sit there before the test replaces it with the title screen. */
    private static final long DISMISS_AFTER_MS = 15 * 1000L;

    private static final int P_BOOT = 0;
    private static final int P_TABS = 1;
    private static final int P_WORLD_SCREEN = 2;
    private static final int P_IN_WORLD = 4;
    private static final int P_FINISH = 5;

    private static final int P_DONE = -1;

    private static int phase = P_BOOT;
    private static int ticks;
    private static int tab;
    private static boolean running;
    private static long startedAt;
    private static long phaseStartedAt;
    private static final List<String> SHOTS = new ArrayList<>();
    private static final List<String> FAILURES = new ArrayList<>();

    private ClientSelfTest() {}

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        if (!Boolean.getBoolean(PROPERTY) || running) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.gameRenderer == null) return;
        running = true;
        ticks++;
        if (startedAt == 0L) {
            startedAt = System.currentTimeMillis();
            phaseStartedAt = startedAt;
        }
        if (elapsed(startedAt) > TOTAL_DEADLINE_MS) {
            FAILURES.add("total deadline exceeded");
            phase = P_FINISH;
            ticks = 0;
        }
        try {
            step(minecraft);
        } catch (Throwable t) {
            FAILURES.add("phase " + phase + ": " + t);
            FnfBonds.LOGGER.error("[Bonds & Ledger] client-test phase {} threw", phase, t);
            phase = P_FINISH;
            ticks = 0;
        } finally {
            running = false;
        }
    }

    // ------------------------------------------------------------------ states

    private static void step(Minecraft mc) {
        if (phase == P_DONE) return;
        switch (phase) {
            case P_BOOT -> {
                Screen boot = mc.gui.screen();
                if (!(boot instanceof TitleScreen)) {
                    if (ticks % 200 == 0) {
                        FnfBonds.LOGGER.info("[Bonds & Ledger] client-test: booting, {} s, screen={}",
                                elapsed(phaseStartedAt) / 1000L,
                                boot == null ? "none (resources still loading)" : boot.getClass().getSimpleName());
                    }
                    // A fresh run directory stops at the accessibility onboarding screen, which waits
                    // for a click nobody is going to make. Anything that is not the title screen and has
                    // been sitting there for a while gets replaced by it.
                    if (boot != null && elapsed(phaseStartedAt) > DISMISS_AFTER_MS) {
                        FnfBonds.LOGGER.info("[Bonds & Ledger] client-test: dismissing {} for the title screen",
                                boot.getClass().getSimpleName());
                        mc.gui.setScreen(new TitleScreen());
                        markPhase();
                    } else {
                        timeout(mc, BOOT_DEADLINE_MS, "title screen never appeared");
                    }
                    return;
                }
                FnfBonds.LOGGER.info("[Bonds & Ledger] client-test: title screen reached, starting");
                openLedger(mc, 0);
                tab = 0;
                phase = P_TABS;
                ticks = 0;
                markPhase();
            }
            case P_TABS -> {
                if (ticks < RENDER_TICKS) return;
                shoot(mc, "0" + (tab + 1) + "_ledger_" + TABS[tab]);
                tab++;
                ticks = 0;
                if (tab < TABS.length) {
                    openLedger(mc, tab);
                } else {
                    mc.gui.setScreen(null);
                    if (Boolean.parseBoolean(System.getProperty(PROPERTY + ".world", "true"))) {
                        FnfBonds.LOGGER.info("[Bonds & Ledger] client-test: entering a world");
                        mc.execute(() -> enterWorld(mc));
                        phase = P_WORLD_SCREEN;
                    } else {
                        phase = P_FINISH;
                    }
                    ticks = 0;
                    markPhase();
                }
            }
            case P_WORLD_SCREEN -> {
                // both entry paths land here: opening an existing save shows loading screens only,
                // while creating one first stops at the create-world screen and needs a click
                if (mc.level != null && mc.player != null) {
                    FnfBonds.LOGGER.info("[Bonds & Ledger] client-test: in world after {} s",
                            elapsed(phaseStartedAt) / 1000L);
                    forceHudConfig();
                    phase = P_IN_WORLD;
                    ticks = 0;
                    markPhase();
                    return;
                }
                Screen screen = mc.gui.screen();
                if (screen instanceof CreateWorldScreen create) {
                    GuiEventListener button = findButton(create, "selectWorld.create");
                    if (button instanceof Button createButton) {
                        FnfBonds.LOGGER.info("[Bonds & Ledger] client-test: pressing '{}'",
                                createButton.getMessage().getString());
                        createButton.onPress(new InputWithModifiers() {
                            @Override public int input() { return 257; }

                            @Override public int modifiers() { return 0; }
                        });
                        ticks = 0;
                        markPhase();
                        return;
                    }
                    FAILURES.add("create-world button not found");
                    phase = P_FINISH;
                    ticks = 0;
                    return;
                }
                timeout(mc, WORLD_LOAD_DEADLINE_MS, "world never finished loading");
            }
            case P_IN_WORLD -> {
                // the HUD hides snapshots older than three seconds, so keep refreshing it
                ClientPayloadHandler.hud = LedgerFixture.hud();
                ClientPayloadHandler.hudReceivedAt = System.currentTimeMillis();
                // the "Loading terrain" overlay covers the first seconds in the world, and the HUD
                // also steps aside while the ledger is open: shoot early, then shoot again once the
                // world has settled and the screen is closed — same file name, last copy wins
                if (ticks == 40 || ticks == 200) {
                    shoot(mc, "06_hud_in_world");
                } else if (ticks == 210) {
                    openLedger(mc, 0);
                } else if (ticks == 222) {
                    shoot(mc, "07_ledger_in_world");
                } else if (ticks == 330) {
                    mc.gui.setScreen(null);
                    mc.gui.toastManager().clear();   // vanilla toasts sit exactly where the HUD does
                } else if (ticks == 350) {
                    shoot(mc, "06_hud_in_world");
                } else if (ticks >= 370) {
                    phase = P_FINISH;
                    ticks = 0;
                }
            }
            case P_FINISH -> {
                if (ticks < 30) return;   // let the IO pool finish writing the PNGs
                report();
                phase = P_DONE;           // mc.stop() keeps ticking for a few frames: report once
                mc.stop();
            }
            default -> {
            }
        }
    }

    /** True once the current phase has overrun its deadline; the test then winds down. */
    private static boolean timeout(Minecraft mc, long deadlineMs, String what) {
        if (elapsed(phaseStartedAt) < deadlineMs) return false;
        FAILURES.add(what + " (" + elapsed(phaseStartedAt) / 1000L + " s)");
        FnfBonds.LOGGER.error("[Bonds & Ledger] client-test: {} after {} s", what, elapsed(phaseStartedAt) / 1000L);
        if (phase == P_FINISH) return true;
        phase = P_FINISH;
        ticks = 0;
        return true;
    }

    private static long elapsed(long since) {
        return System.currentTimeMillis() - since;
    }

    private static void markPhase() {
        phaseStartedAt = System.currentTimeMillis();
    }

    /**
     * Opens the newest existing save if there is one (much cheaper than making another), otherwise
     * asks vanilla to build a flat test world through its own create-world screen.
     */
    private static void enterWorld(Minecraft mc) {
        LevelStorageSource source = mc.getLevelSource();
        try {
            List<LevelSummary> levels = source
                    .loadLevelSummaries(source.findLevelCandidates())
                    .get(2, TimeUnit.MINUTES);
            if (!levels.isEmpty()) {
                String levelId = levels.getFirst().getLevelId();
                FnfBonds.LOGGER.info("[Bonds & Ledger] client-test: opening existing world '{}'", levelId);
                mc.createWorldOpenFlows().openWorld(levelId, () -> mc.gui.setScreen(new TitleScreen()));
                return;
            }
        } catch (Exception e) {
            FnfBonds.LOGGER.warn("[Bonds & Ledger] client-test: could not list saves: {}", e.toString());
        }
        FnfBonds.LOGGER.info("[Bonds & Ledger] client-test: no save found, creating a flat test world");
        CreateWorldScreen.testWorld(mc, () -> mc.gui.setScreen(new TitleScreen()));
    }

    // ------------------------------------------------------------------ pieces

    private static void openLedger(Minecraft mc, int tabIndex) {
        CompoundTag data = LedgerFixture.full(tabIndex);
        mc.setScreenAndShow(new LedgerScreen(data));
    }

    private static void forceHudConfig() {
        try {
            FnfBondsConfig.HUD_ENABLED.set(true);
            FnfBondsConfig.HUD_SHOW_MARKET.set(true);
        } catch (RuntimeException e) {
            FnfBonds.LOGGER.warn("[Bonds & Ledger] client-test: could not force HUD config: {}", e.toString());
        }
    }

    private static void shoot(Minecraft mc, String name) {
        String file = name + ".png";
        RenderTarget target = mc.gameRenderer.mainRenderTarget();
        Screenshot.grab(mc.gameDirectory, file, target, 1,
                message -> FnfBonds.LOGGER.info("[Bonds & Ledger] client-test: {}", message.getString()));
        SHOTS.add(file);
    }

    /** Walks the screen's widget tree (layouts nest buttons inside container handlers). */
    private static GuiEventListener findButton(Screen screen, String translationKey) {
        String wanted = Component.translatable(translationKey).getString();
        return findButton(screen.children(), wanted);
    }

    private static GuiEventListener findButton(List<? extends GuiEventListener> children, String wanted) {
        for (GuiEventListener child : children) {
            if (child instanceof AbstractWidget widget
                    && widget.getMessage().getString().equals(wanted)
                    && widget instanceof Button) {
                return child;
            }
            if (child instanceof ContainerEventHandler container) {
                GuiEventListener found = findButton(container.children(), wanted);
                if (found != null) return found;
            }
        }
        return null;
    }

    private static void report() {
        FnfBonds.LOGGER.info("[Bonds & Ledger] client-test: {} screenshots, {} failures -> {}",
                SHOTS.size(), FAILURES.size(), new File(mc().gameDirectory, "screenshots").getAbsolutePath());
        for (String shot : SHOTS) FnfBonds.LOGGER.info("[Bonds & Ledger]   shot {}", shot);
        for (String failure : FAILURES) FnfBonds.LOGGER.error("[Bonds & Ledger]   FAIL {}", failure);
        FnfBonds.LOGGER.info("[Bonds & Ledger] CLIENT-TEST {} ({} shots / {} failures)",
                FAILURES.isEmpty() ? "PASSED" : "FAILED", SHOTS.size(), FAILURES.size());
    }

    private static Minecraft mc() {
        return Minecraft.getInstance();
    }
}
