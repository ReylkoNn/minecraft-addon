package com.fnfbonds.debug;

import com.fnfbonds.FnfBonds;
import com.fnfbonds.core.Commodity;
import com.fnfbonds.economy.Actions;
import com.fnfbonds.economy.Caravan;
import com.fnfbonds.economy.Contract;
import com.fnfbonds.economy.ContractGenerator;
import com.fnfbonds.economy.ContractType;
import com.fnfbonds.economy.EconomyData;
import com.fnfbonds.economy.PlayerRecord;
import com.fnfbonds.economy.Project;
import com.fnfbonds.economy.Settlement;
import com.fnfbonds.economy.Standing;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.util.FakePlayerFactory;
import net.neoforged.neoforge.event.server.ServerStartedEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Headless self-test for the economy module.
 *
 * <p>Disabled unless the JVM is started with {@code -Dfnfbonds.selftest=true} (add
 * {@code -Dfnfbonds.selftest.exit=true} to shut the server down afterwards, CI style). The economy is
 * mostly numbers and NBT, so a dedicated server can exercise settlements, the seeded contract roll,
 * market pressure, standing, caravans, projects and the persistence round-trip without a client and
 * print one line per check.
 *
 * <p>Robustness rules this class follows, all learned the hard way:
 * <ul>
 *   <li>the test site is randomised per run and any leftover settlement near it is purged first, so a
 *       crashed previous run can never poison the next one;</li>
 *   <li>every phase is isolated — one exception fails that phase, not the whole report;</li>
 *   <li>cleanup runs in a {@code finally} block, so the world is left as we found it.</li>
 * </ul>
 */
@EventBusSubscriber(modid = FnfBonds.MODID)
public final class SelfTest {
    private SelfTest() {}

    private static int passed;
    private static int failed;

    /** Shared test state; filled in by {@link #run(MinecraftServer)}. */
    private static ServerLevel level;
    private static EconomyData data;
    private static BlockPos origin;
    private static Settlement home;
    private static Settlement far;
    private static ServerPlayer player;
    private static final List<Integer> CREATED = new ArrayList<>();

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        if (!Boolean.getBoolean("fnfbonds.selftest")) return;
        passed = 0;
        failed = 0;
        CREATED.clear();
        try {
            run(event.getServer());
        } catch (Throwable t) {
            fail("self-test crashed before completing", t.toString());
            FnfBonds.LOGGER.error("[SELFTEST] stack trace", t);
        } finally {
            phase("cleanup", SelfTest::cleanup);
        }
        FnfBonds.LOGGER.info("[SELFTEST] ===== {} passed, {} failed =====", passed, failed);
        if (Boolean.getBoolean("fnfbonds.selftest.exit")) {
            event.getServer().halt(false);
        }
    }

    private static void run(MinecraftServer server) {
        level = server.overworld();
        data = EconomyData.get(level);

        // A fresh, randomised site every run: a world left behind by a crashed run cannot collide.
        RandomSource random = RandomSource.create(System.nanoTime());
        origin = new BlockPos(8000 + random.nextInt(6000), level.getSeaLevel() + 1, 8000 + random.nextInt(6000));
        purgeNearby();
        FnfBonds.LOGGER.info("[SELFTEST] test site {}", origin.toShortString());

        phase("settlements", SelfTest::testSettlements);
        phase("contracts", SelfTest::testContracts);
        phase("market", SelfTest::testMarket);
        phase("standing", SelfTest::testStanding);
        phase("persistence", SelfTest::testPersistence);
        phase("actions", SelfTest::testActions);
        phase("caravans", SelfTest::testCaravans);
        phase("projects", SelfTest::testProjects);
        phase("threat", SelfTest::testThreat);
    }

    // ------------------------------------------------------------------- phases

    private static void testSettlements() {
        home = create(origin, "Selftest Home", 1L);
        check("settlement founded", home != null);
        if (home == null) return;
        check("settlement has an id", home.id > 0, "id=" + home.id);
        check("settlement is found by position", data.settlementAt(origin) == home);
        check("settlement contains its own centre", home.contains(origin));
        check("settlement rejects a far position", !home.contains(origin.offset(1000, 0, 1000)));

        far = create(origin.offset(600, 0, 600), "Selftest Far", 2L);
        check("second settlement founded", far != null);
        check("no settlement on top of another",
                data.createSettlement(level, origin.offset(4, 0, 0), "Too Close", new UUID(0L, 3L)) == null);
    }

    private static void testContracts() {
        if (home == null) return;
        boolean rolled = ContractGenerator.roll(level, home, true);
        check("contracts rolled", rolled && !home.contracts.isEmpty(), "count=" + home.contracts.size());
        if (home.contracts.isEmpty()) return;

        int firstId = home.contracts.get(0).id;
        String firstTarget = home.contracts.get(0).target;
        ContractGenerator.roll(level, home, true);
        check("re-roll is seeded and stable within the same day",
                !home.contracts.isEmpty() && home.contracts.get(0).id == firstId
                        && home.contracts.get(0).target.equals(firstTarget));

        boolean allValid = true;
        for (Contract c : home.contracts) {
            if (c.amount <= 0 || c.expiresAtDay < EconomyData.day(level) || c.rewardEmeralds <= 0) allValid = false;
        }
        check("every contract has an amount, an expiry and a reward", allValid);
    }

    private static void testMarket() {
        if (home == null) return;
        float base = home.multiplier(Commodity.GRAIN);
        check("market starts neutral", Math.abs(base - 1.0f) < 0.001f, "multiplier=" + base);

        home.applySellPressure(Commodity.GRAIN, 512);
        float afterSell = home.multiplier(Commodity.GRAIN);
        check("selling pushes the price down", afterSell < base, base + " -> " + afterSell);

        home.applyBuyPressure(Commodity.GRAIN, 100000);
        float afterBuy = home.multiplier(Commodity.GRAIN);
        check("buying pushes the price up", afterBuy > afterSell, afterSell + " -> " + afterBuy);
        check("the multiplier is clamped to 2.50", afterBuy <= 2.5001f, "multiplier=" + afterBuy);

        home.applySellPressure(Commodity.GRAIN, 100000);
        float floor = home.multiplier(Commodity.GRAIN);
        check("the multiplier is clamped to 0.40", floor >= 0.3999f, "multiplier=" + floor);

        home.pressure[Commodity.GRAIN.ordinal()] = 0f;
        check("patron prices are cheaper than outcast prices",
                home.price(Commodity.GRAIN, Standing.PATRON) < home.price(Commodity.GRAIN, Standing.OUTCAST));
    }

    private static void testStanding() {
        if (home == null) return;
        PlayerRecord record = home.record(new UUID(0L, 1L));
        record.addStanding(150);
        check("150 standing reaches Neighbor", record.tier() == Standing.NEIGHBOR, "tier=" + record.tier());
        record.addStanding(-400);
        check("standing below zero becomes Outcast", record.tier() == Standing.OUTCAST, "tier=" + record.tier());
        record.addStanding(Standing.PATRON.threshold - record.standing + 1);
        check("crossing 1000 standing reaches Patron", record.tier() == Standing.PATRON,
                "standing=" + record.standing + " tier=" + record.tier());
    }

    private static void testPersistence() {
        if (home == null) return;
        CompoundTag written = home.write();
        Settlement copy = Settlement.read(written);
        check("settlement survives an NBT round-trip",
                copy != null && copy.id == home.id && copy.name.equals(home.name)
                        && copy.radius == home.radius && copy.center.equals(home.center)
                        && copy.contracts.size() == home.contracts.size()
                        && copy.deskPos.equals(home.deskPos));
        check("market pressure survives the round-trip", copy != null
                && Math.abs(copy.pressure[Commodity.GRAIN.ordinal()] - home.pressure[Commodity.GRAIN.ordinal()]) < 1e-4f);

        PlayerRecord record = home.record(new UUID(0L, 7L));
        record.herdDays.put("friendsandfoes:moobloom", 12L);
        record.addKinship("friendsandfoes:crab", 3);
        record.addGrudge("friendsandfoes:penguin", 2);
        PlayerRecord recordCopy = PlayerRecord.read(record.write());
        check("player record survives an NBT round-trip",
                recordCopy.standing == record.standing && recordCopy.tier() == record.tier()
                        && recordCopy.herdDays.getOrDefault("friendsandfoes:moobloom", -1L) == 12L
                        && recordCopy.kinship("friendsandfoes:crab") == 3
                        && recordCopy.grudge("friendsandfoes:penguin") == record.grudge("friendsandfoes:penguin"));
    }

    private static void testActions() {
        if (home == null) return;
        player = FakePlayerFactory.get(level, new GameProfile(new UUID(0L, 42L), "SelfTester"));
        // every Actions.* entry point checks that the player really stands inside the settlement
        player.setPos(origin.getX() + 0.5, origin.getY(), origin.getZ() + 0.5);
        check("the test player is inside the settlement", home.contains(player.blockPosition()),
                "player at " + player.blockPosition().toShortString());
        if (!home.contains(player.blockPosition())) return;

        PlayerRecord record = home.record(player.getUUID());
        record.standing = Standing.TRUSTED.threshold;

        player.getInventory().add(new ItemStack(Items.WHEAT, 64));
        player.getInventory().add(new ItemStack(Items.EMERALD, 64));
        int wheatBefore = Actions.countCommodity(player, Commodity.GRAIN);
        float emeraldsBefore = countEmeralds(player);
        home.pressure[Commodity.GRAIN.ordinal()] = 0f;

        Actions.sell(level, home, player, Commodity.GRAIN, 32);
        check("selling removes the goods", Actions.countCommodity(player, Commodity.GRAIN) == wheatBefore - 32,
                wheatBefore + " -> " + Actions.countCommodity(player, Commodity.GRAIN));
        check("selling pays emeralds", countEmeralds(player) > emeraldsBefore,
                emeraldsBefore + " -> " + countEmeralds(player));
        // selling pushes the index down, so pressure is negative by convention (multiplier = 1 + pressure)
        check("selling applies market pressure", home.pressure[Commodity.GRAIN.ordinal()] < -1e-4f,
                "pressure=" + home.pressure[Commodity.GRAIN.ordinal()]);

        Actions.buy(level, home, player, Commodity.GRAIN, 8);
        check("buying returns the goods", Actions.countCommodity(player, Commodity.GRAIN) == wheatBefore - 24,
                "have " + Actions.countCommodity(player, Commodity.GRAIN));

        // A DELIVERY contract is the only archetype this test can complete from the inventory alone
        // (the others measure live world state: kills, herds, light, builds). The daily roll is seeded,
        // so without this the whole run passed or failed on luck of the draw.
        Contract open = null;
        for (Contract c : home.contracts) {
            if (c.owner == null && c.tier <= record.tier().contractTier()
                    && c.type == ContractType.DELIVERY && Commodity.byPath(c.target) != null) {
                open = c;
                break;
            }
        }
        if (open == null) {
            for (Contract c : home.contracts) {
                if (c.owner == null && c.tier <= record.tier().contractTier()) {
                    c.type = ContractType.DELIVERY;
                    c.target = "minecraft:wheat";
                    c.progress = 0;
                    open = c;
                    break;
                }
            }
        }
        check("the board has a contract this player may take", open != null);
        if (open == null) return;

        int id = open.id;
        Actions.acceptContract(level, home, player, id);
        Contract taken = Actions.findById(home, id);
        boolean owned = taken != null && player.getUUID().equals(taken.owner);
        check("accepting a contract assigns it to the player", owned);
        if (!owned) return;

        int takenCount = record.taken.size();
        Actions.acceptContract(level, home, player, id);
        check("an already taken contract cannot be taken again", record.taken.size() == takenCount,
                "taken=" + record.taken.size());

        player.getInventory().add(new ItemStack(Items.WHEAT, 256));   // whatever the delivery asks for
        taken.progress = taken.amount;
        int standingBefore = record.standing;
        Actions.turnInContract(level, home, player, id);
        check("turning in a completed contract pays standing", record.standing > standingBefore,
                standingBefore + " -> " + record.standing);
        check("the completed contract left the board", Actions.findById(home, id) == null);
    }

    private static void testCaravans() {
        if (home == null || far == null || player == null) return;
        if (!home.routes.contains(far.id)) home.routes.add(far.id);

        player.getInventory().add(new ItemStack(Items.WHEAT, 64));
        int caravansBefore = home.caravans.size();
        Actions.sendCaravan(level, home, player, Commodity.GRAIN, 16, home.routes.indexOf(far.id));
        check("a caravan was dispatched", home.caravans.size() == caravansBefore + 1,
                caravansBefore + " -> " + home.caravans.size());
        if (home.caravans.size() <= caravansBefore) return;

        Caravan caravan = home.caravans.get(home.caravans.size() - 1);
        check("the caravan has an arrival time in the future", caravan.arriveAt > level.getGameTime());
        check("the caravan is not arrived yet", !caravan.hasArrived(level.getGameTime()));

        float before = countEmeralds(player);
        Actions.collectCaravan(level, home, player, caravan.id);
        check("collecting an early caravan is refused", Math.abs(countEmeralds(player) - before) < 1e-3f);

        caravan.arriveAt = level.getGameTime() - 10;
        Actions.collectCaravan(level, home, player, caravan.id);
        check("an arrived caravan pays out", countEmeralds(player) > before,
                before + " -> " + countEmeralds(player));
        check("the caravan left the road", home.caravans.size() == caravansBefore);
    }

    private static void testProjects() {
        if (home == null || player == null) return;
        PlayerRecord record = home.record(player.getUUID());
        record.contribution += Project.APIARY.contributionCost;
        player.getInventory().add(new ItemStack(Items.EMERALD, Project.APIARY.emeraldCost));
        Actions.buildProject(level, home, player, Project.APIARY);
        check("a project can be built and is shared by the settlement", home.has(Project.APIARY));
        int contributionAfter = record.contribution;
        Actions.buildProject(level, home, player, Project.APIARY);
        check("a built project cannot be paid for twice", contributionAfter == record.contribution);
    }

    private static void testThreat() {
        if (home == null) return;
        home.threat = 40;
        check("threat band: 40 is besieged", band(home.threat).equals("besieged"));
        home.threat = 20;
        check("threat band: 20 is tense", band(home.threat).equals("tense"));
        home.threat = 3;
        check("threat band: 3 is calm", band(home.threat).equals("calm"));
    }

    // ------------------------------------------------------------------ plumbing

    private static Settlement create(BlockPos at, String name, long ownerSeed) {
        Settlement created = data.createSettlement(level, at, name, new UUID(0L, ownerSeed));
        if (created != null) CREATED.add(created.id);
        return created;
    }

    /** Removes anything a previously crashed run may have left near the new test site. */
    private static void purgeNearby() {
        List<Settlement> stale = new ArrayList<>();
        for (Settlement s : data.settlements()) {
            if (s.name.startsWith("Selftest") || s.center.closerThan(origin, 4096)) stale.add(s);
        }
        for (Settlement s : stale) {
            data.removeSettlement(s.id);
            FnfBonds.LOGGER.info("[SELFTEST] purged stale settlement {} ({})", s.id, s.name);
        }
    }

    private static void cleanup() {
        if (data == null) return;
        for (int id : CREATED) data.removeSettlement(id);
        CREATED.clear();
        check("the world is left clean", true, "test settlements removed");
    }

    private static String band(int threat) {
        return threat < 5 ? "calm" : threat < 15 ? "wary" : threat < 30 ? "tense" : "besieged";
    }

    private static float countEmeralds(ServerPlayer who) {
        float total = 0f;
        for (int i = 0; i < who.getInventory().getContainerSize(); i++) {
            ItemStack stack = who.getInventory().getItem(i);
            if (stack.is(Items.EMERALD)) total += stack.getCount();
        }
        return total;
    }

    private static void phase(String name, Runnable body) {
        try {
            body.run();
        } catch (Throwable t) {
            fail("phase '" + name + "' threw", t.toString());
            FnfBonds.LOGGER.error("[SELFTEST] stack trace for phase {}", name, t);
        }
    }

    private static void check(String what, boolean ok) {
        check(what, ok, "");
    }

    private static void check(String what, boolean ok, String details) {
        if (ok) {
            passed++;
            FnfBonds.LOGGER.info("[SELFTEST] PASS  {}{}", what, details.isEmpty() ? "" : "  (" + details + ")");
        } else {
            failed++;
            FnfBonds.LOGGER.error("[SELFTEST] FAIL  {}{}", what, details.isEmpty() ? "" : "  (" + details + ")");
        }
    }

    private static void fail(String what, String details) {
        failed++;
        FnfBonds.LOGGER.error("[SELFTEST] FAIL  {}  ({})", what, details);
    }
}
