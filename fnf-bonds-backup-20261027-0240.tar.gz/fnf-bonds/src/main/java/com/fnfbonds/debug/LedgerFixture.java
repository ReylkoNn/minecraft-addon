package com.fnfbonds.debug;

import com.fnfbonds.core.Commodity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.FloatTag;
import net.minecraft.nbt.IntTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;

import java.util.UUID;

/**
 * A fully populated ledger snapshot, built by hand.
 *
 * <p>Two jobs: it feeds {@link ClientSelfTest} so the GUI can be rendered and screenshotted without
 * a world, and it doubles as a fixture proving the screen copes with every field present — including
 * the awkward cases (a raided caravan, lost loot, a project already built, an outcast-tier contract).
 */
public final class LedgerFixture {
    private LedgerFixture() {}

    private static final int[] MULTIPLIERS = {
            112, 84, 62, 138, 100, 91, 155, 184, 73, 128, 96, 141
    };

    private static final int[] HOLDINGS = {46, 12, 88, 6, 240, 128, 17, 3, 22, 9, 41, 2};

    /** Multiplied by 100 in {@link #MULTIPLIERS} to keep the table readable. */
    private static float multiplier(int index) {
        return MULTIPLIERS[index % MULTIPLIERS.length] / 100f;
    }

    /** One preselected row per tab, so the screenshots show the selected state and its buttons. */
    private static final int[] SELECTION = {-1, 0, 6, 0, 1};

    public static CompoundTag full(int tab) {
        CompoundTag tag = new CompoundTag();
        tag.putInt("tab", tab);
        tag.putInt("sel", SELECTION[Math.clamp(tab, 0, SELECTION.length - 1)]);
        tag.putInt("id", 1);
        tag.putString("name", "Honeycombe Hollow");
        tag.putInt("radius", 80);
        tag.putInt("threat", 12);
        tag.putLong("day", 37);
        tag.putInt("tier", 3);
        tag.putInt("standing", 412);
        tag.putInt("contribution", 137);
        tag.putInt("streak", 5);
        tag.putInt("contractsDone", 14);
        tag.putInt("contractsFailed", 2);
        tag.putInt("caravansDone", 9);
        tag.putFloat("bank", 120.0f);
        tag.putFloat("credit", 12.0f);
        tag.putInt("creditLimit", 16);
        tag.putInt("seals", 6);
        tag.putInt("emeralds", 84);
        tag.putBoolean("board", true);
        tag.putBoolean("post", true);
        tag.putBoolean("anchored", true);
        tag.putInt("contractSlots", 4);
        tag.putInt("caravanSlots", 2);
        tag.putInt("caravanCapacity", 192);
        tag.putLong("gameTime", 88_400L);

        ListTag prices = new ListTag();
        ListTag multipliers = new ListTag();
        ListTag pressures = new ListTag();
        ListTag holdings = new ListTag();
        for (int i = 0; i < Commodity.ALL.length; i++) {
            float mult = multiplier(i);
            prices.add(FloatTag.valueOf(Commodity.ALL[i].basePrice * mult * 0.8f));
            multipliers.add(FloatTag.valueOf(mult));
            pressures.add(FloatTag.valueOf(mult - 1.0f));
            holdings.add(IntTag.valueOf(HOLDINGS[i % HOLDINGS.length]));
        }
        tag.put("prices", prices);
        tag.put("multipliers", multipliers);
        tag.put("pressures", pressures);
        tag.put("holdings", holdings);

        ListTag projectOrder = new ListTag();
        ListTag projectsBuilt = new ListTag();
        for (int i = 0; i < 9; i++) {
            projectOrder.add(StringTag.valueOf("project_" + i));
            projectsBuilt.add(IntTag.valueOf(i == 0 || i == 4 ? 1 : 0));
        }
        tag.put("projectOrder", projectOrder);
        tag.put("projectsBuilt", projectsBuilt);

        ListTag contracts = new ListTag();
        contracts.add(contract(101, 0, "minecraft:wheat", 48, 0, 2, 26, 6, 8, 0, false, 40));
        contracts.add(contract(102, 1, "friendsandfoes:iceologer", 4, 0, 4, 34, 9, 12, 1, false, 39));
        contracts.add(contract(103, 5, "", 12, 0, 1, 14, 4, 4, 0, false, 40));
        contracts.add(contract(104, 2, "friendsandfoes:moobloom", 6, 4, 2, 22, 5, 6, 0, true, 38));
        contracts.add(contract(105, 4, "minecraft:oak_planks", 96, 61, 1, 18, 4, 5, 0, true, 39));
        contracts.add(contract(106, 6, "", 1, 0, 3, 40, 10, 14, 2, true, 37));
        tag.put("contracts", contracts);

        ListTag caravans = new ListTag();
        caravans.add(caravan(7, Commodity.HONEY.ordinal(), 96, "Birchbrook", 88_100L, true, false, 0, 0, 71.4f));
        caravans.add(caravan(8, Commodity.CHITIN.ordinal(), 24, "Frostfell Camp", 91_600L, false, true, 3, 6, 58.0f));
        tag.put("caravans", caravans);

        ListTag routes = new ListTag();
        routes.add(route(2, "Birchbrook", 412));
        routes.add(route(3, "Frostfell Camp", 1180));
        routes.add(route(4, "Meadow Reach", 268));
        tag.put("routes", routes);

        ListTag loot = new ListTag();
        loot.add(lostItem("minecraft:honeycomb", 14));
        loot.add(lostItem("friendsandfoes:crab_claw", 3));
        tag.put("lostLoot", loot);
        return tag;
    }

    public static CompoundTag hud() {
        CompoundTag tag = new CompoundTag();
        tag.putString("name", "Honeycombe Hollow");
        tag.putInt("tier", 3);
        tag.putInt("standing", 412);
        tag.putInt("contribution", 137);
        tag.putInt("seals", 6);
        tag.putInt("threat", 12);
        tag.putInt("contracts", 6);
        tag.putInt("contractsMine", 3);
        ListTag multipliers = new ListTag();
        for (int i = 0; i < Commodity.ALL.length; i++) multipliers.add(FloatTag.valueOf(multiplier(i)));
        tag.put("multipliers", multipliers);
        return tag;
    }

    private static CompoundTag contract(int id, int type, String target, int amount, int progress,
                                        int tier, int emeralds, int standing, int contribution,
                                        int seals, boolean mine, long expiresAtDay) {
        CompoundTag c = new CompoundTag();
        c.putInt("id", id);
        c.putInt("type", type);
        c.putString("target", target);
        c.putInt("amount", amount);
        c.putInt("progress", progress);
        c.putInt("tier", tier);
        c.putInt("em", emeralds);
        c.putInt("st", standing);
        c.putInt("ct", contribution);
        c.putInt("sl", seals);
        c.putLong("exp", expiresAtDay);
        c.putBoolean("mine", mine);
        c.putBoolean("anyOwner", mine);
        if (mine) c.putString("owner", new UUID(0L, 42L).toString());
        return c;
    }

    private static CompoundTag caravan(int id, int commodity, int amount, String destName, long arriveAt,
                                       boolean arrived, boolean raided, int escortKills, int escortNeeded,
                                       float payout) {
        CompoundTag c = new CompoundTag();
        c.putInt("id", id);
        c.putInt("commodity", commodity);
        c.putInt("amount", amount);
        c.putInt("dest", 2);
        c.putString("destName", destName);
        c.putLong("depart", arriveAt - 2400L);
        c.putLong("arrive", arriveAt);
        c.putBoolean("arrived", arrived);
        c.putBoolean("mine", true);
        c.putBoolean("raided", raided);
        c.putBoolean("raidRolled", true);
        c.putInt("escortKills", escortKills);
        c.putInt("escortNeeded", escortNeeded);
        c.putFloat("payout", payout);
        c.putString("owner", new UUID(0L, 42L).toString());
        return c;
    }

    private static CompoundTag route(int id, String name, int distance) {
        CompoundTag r = new CompoundTag();
        r.putInt("id", id);
        r.putString("name", name);
        r.putInt("distance", distance);
        return r;
    }

    private static CompoundTag lostItem(String id, int count) {
        CompoundTag item = new CompoundTag();
        item.putString("item", id);
        item.putInt("count", count);
        return item;
    }
}
