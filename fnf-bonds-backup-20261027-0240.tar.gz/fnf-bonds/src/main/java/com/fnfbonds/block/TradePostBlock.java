package com.fnfbonds.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** The trade post: market prices, buying/selling and caravan dispatch. */
public class TradePostBlock extends Block {
    public TradePostBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        super.onPlace(state, level, pos, oldState, isMoving);
        Anchor.anchorPlaced(level, pos, "post");
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        return Anchor.open(level, pos, player, Anchor.TAB_MARKET);
    }

    @Override
    public void destroy(LevelAccessor level, BlockPos pos, BlockState state) {
        Anchor.anchorBroken(level, pos);
        super.destroy(level, pos, state);
    }
}
