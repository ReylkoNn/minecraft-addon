package com.fnfbonds.block;

import com.fnfbonds.economy.EconomyData;
import com.fnfbonds.economy.Settlement;
import com.fnfbonds.network.Network;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import org.jspecify.annotations.Nullable;

/**
 * Shared behaviour of the three "settlement anchor" blocks: the ledger desk (founds a settlement),
 * the contract board and the trade post. Keeping it in one place means the three blocks stay thin
 * and can never drift apart.
 */
public final class Anchor {
    private Anchor() {}

    public static final int TAB_OVERVIEW = 0;
    public static final int TAB_CONTRACTS = 1;
    public static final int TAB_MARKET = 2;
    public static final int TAB_CARAVANS = 3;
    public static final int TAB_PROJECTS = 4;

    /** Founding a settlement: only the ledger desk does this. */
    public static void foundSettlement(Level level, BlockPos pos, @Nullable LivingEntity placer) {
        if (!(level instanceof ServerLevel serverLevel)) return;
        if (!(placer instanceof ServerPlayer player)) return;

        EconomyData data = EconomyData.get(serverLevel);
        Settlement existing = data.settlementAt(pos);
        if (existing == null) existing = data.nearest(pos, 24);
        if (existing != null) {
            existing.deskPos = pos.immutable();
            EconomyData.get(serverLevel).setDirty();
            player.sendSystemMessage(Component.translatable("chat.fnfbonds.settlement.joined", existing.name)
                    .withStyle(ChatFormatting.AQUA));
            return;
        }

        Settlement created = data.createSettlement(serverLevel, pos, "", player.getUUID());
        if (created == null) {
            player.sendSystemMessage(Component.translatable("chat.fnfbonds.error.cannot_found")
                    .withStyle(ChatFormatting.RED));
            return;
        }
        created.deskPos = pos.immutable();
        player.sendSystemMessage(Component.translatable("chat.fnfbonds.settlement.founded", created.name,
                        created.radius)
                .withStyle(ChatFormatting.GOLD));
    }

    public static void anchorPlaced(LevelAccessor level, BlockPos pos, String kind) {
        if (!(level instanceof ServerLevel serverLevel)) return;
        com.fnfbonds.economy.EconomyEvents.onAnchorPlaced(serverLevel, pos, kind);
    }

    public static void anchorBroken(LevelAccessor level, BlockPos pos) {
        if (!(level instanceof ServerLevel serverLevel)) return;
        com.fnfbonds.economy.EconomyEvents.onAnchorBroken(serverLevel, pos);
    }

    /** Right-click handler shared by desk / board / post. */
    public static InteractionResult open(Level level, BlockPos pos, Player player, int tab) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer serverPlayer)) return InteractionResult.PASS;

        ServerLevel serverLevel = serverPlayer.level();
        EconomyData data = EconomyData.get(serverLevel);
        Settlement settlement = data.settlementAt(pos);
        if (settlement == null) settlement = data.nearest(pos, 32);
        if (settlement == null) {
            serverPlayer.sendSystemMessage(Component.translatable("chat.fnfbonds.error.no_settlement")
                    .withStyle(ChatFormatting.RED));
            return InteractionResult.CONSUME;
        }
        if (!settlement.isAnchored() && tab != TAB_OVERVIEW) {
            serverPlayer.sendSystemMessage(Component.translatable("chat.fnfbonds.error.no_desk")
                    .withStyle(ChatFormatting.RED));
        }
        Network.openLedger(serverPlayer, settlement, tab);
        return InteractionResult.CONSUME;
    }

    /** Used by the portable ledger book: find the closest settlement to the player. */
    public static @Nullable Settlement findForPlayer(ServerPlayer player, double maxDistance) {
        EconomyData data = EconomyData.get(player.level());
        Settlement inside = data.settlementAt(player.blockPosition());
        if (inside != null) return inside;
        return data.nearest(player.blockPosition(), maxDistance);
    }
}
