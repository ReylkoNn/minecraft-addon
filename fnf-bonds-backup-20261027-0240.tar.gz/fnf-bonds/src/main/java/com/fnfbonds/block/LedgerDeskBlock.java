package com.fnfbonds.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.jspecify.annotations.Nullable;

/**
 * The settlement anchor. Placing it founds a settlement (or joins a nearby one) and opens the
 * ledger; breaking it leaves the settlement leaderless until a new desk is placed.
 */
public class LedgerDeskBlock extends Block {
    public LedgerDeskBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        Anchor.foundSettlement(level, pos, placer);
        Anchor.anchorPlaced(level, pos, "desk");
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        return Anchor.open(level, pos, player, Anchor.TAB_OVERVIEW);
    }

    @Override
    public void destroy(LevelAccessor level, BlockPos pos, BlockState state) {
        Anchor.anchorBroken(level, pos);
        super.destroy(level, pos, state);
    }
}
