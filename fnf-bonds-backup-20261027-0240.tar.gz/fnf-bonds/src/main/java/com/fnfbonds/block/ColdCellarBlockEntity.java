package com.fnfbonds.block;

import com.fnfbonds.registry.ModBlockEntities;
import com.fnfbonds.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The cold cellar. Two jobs: it slowly distils frost vials from packed ice, and — more importantly
 * for the economy — its mere presence stabilises the settlement's food and frost prices (see
 * {@link com.fnfbonds.economy.Settlement#multiplier}).
 */
public class ColdCellarBlockEntity extends ContainerBlockEntity {
    public static final int SLOT_INPUT = 0;
    public static final int SLOT_BOTTLES = 1;
    public static final int SLOT_OUTPUT = 2;
    public static final int CYCLE_TICKS = 400;

    public int progress;

    public ColdCellarBlockEntity(BlockPos pos, BlockState state) {
        this(ModBlockEntities.COLD_CELLAR.get(), pos, state);
    }

    protected ColdCellarBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state, 3);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, ColdCellarBlockEntity entity) {
        ItemStack ice = entity.getItem(SLOT_INPUT);
        ItemStack bottles = entity.getItem(SLOT_BOTTLES);
        ItemStack output = entity.getItem(SLOT_OUTPUT);

        boolean canWork = !ice.isEmpty() && ice.getItem() == Items.PACKED_ICE
                && !bottles.isEmpty() && bottles.getItem() == Items.GLASS_BOTTLE
                && (output.isEmpty() || (output.getItem() == ModItems.FROST_VIAL.get()
                && output.getCount() < output.getMaxStackSize()));
        if (!canWork) {
            if (entity.progress > 0) {
                entity.progress = Math.max(0, entity.progress - 2);
                entity.setChanged();
            }
            return;
        }

        entity.progress++;
        if (entity.progress >= CYCLE_TICKS) {
            entity.progress = 0;
            ice.shrink(1);
            bottles.shrink(1);
            if (output.isEmpty()) {
                entity.setItem(SLOT_OUTPUT, new ItemStack(ModItems.FROST_VIAL.get()));
            } else {
                output.grow(1);
            }
            entity.setChanged();
        } else if (level.getGameTime() % 20L == 0L) {
            entity.setChanged();
        }
    }

    public float progress01() {
        return (float) this.progress / (float) CYCLE_TICKS;
    }
}
