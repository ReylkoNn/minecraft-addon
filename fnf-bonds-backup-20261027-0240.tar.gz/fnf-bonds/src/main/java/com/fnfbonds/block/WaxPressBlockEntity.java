package com.fnfbonds.block;

import com.fnfbonds.core.FnfRefs;
import com.fnfbonds.registry.ModBlockEntities;
import com.fnfbonds.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

/**
 * The wax press: the entry point of the addon's production chain.
 *
 * <p>No GUI on purpose — it is a hopper-friendly processor so it can be automated with vanilla
 * hoppers, other mods' pipes and the copper golem. Recipes are a small explicit table; the same
 * table is exposed as data-driven crafting recipes for players who prefer manual play.
 */
public class WaxPressBlockEntity extends ContainerBlockEntity {
    public static final int SLOT_INPUT_A = 0;
    public static final int SLOT_INPUT_B = 1;
    public static final int SLOT_OUTPUT = 2;

    public int progress;
    public int totalProgress;

    public WaxPressBlockEntity(BlockPos pos, BlockState state) {
        this(ModBlockEntities.WAX_PRESS.get(), pos, state);
    }

    protected WaxPressBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state, 3);
    }

    /** One pressing recipe: inputs (either may be empty), output and duration in ticks. */
    public record Recipe(ItemStack inputA, ItemStack inputB, ItemStack output, int ticks) {
        public boolean matches(ItemStack a, ItemStack b) {
            return stackMatches(a, this.inputA) && stackMatches(b, this.inputB);
        }

        private static boolean stackMatches(ItemStack candidate, ItemStack required) {
            if (required.isEmpty()) return true;
            if (candidate.isEmpty()) return false;
            return candidate.getItem() == required.getItem() && candidate.getCount() >= required.getCount();
        }
    }

    public static List<Recipe> recipes() {
        return List.of(
                new Recipe(new ItemStack(Items.HONEYCOMB, 3), ItemStack.EMPTY,
                        new ItemStack(ModItems.BEESWAX.get(), 2), 100),
                new Recipe(new ItemStack(ModItems.BEESWAX.get(), 2), new ItemStack(Items.DYE.pick(DyeColor.RED), 1),
                        new ItemStack(ModItems.WAX_SEAL.get(), 4), 100),
                new Recipe(new ItemStack(ModItems.CHITIN.get(), 3), new ItemStack(ModItems.BEESWAX.get(), 1),
                        new ItemStack(ModItems.CHITIN_PLATE.get(), 1), 120),
                new Recipe(new ItemStack(Items.HONEY_BOTTLE, 1), new ItemStack(Items.WHEAT, 1),
                        new ItemStack(ModItems.MEAD.get(), 1), 200),
                chitinFromClaw(),
                chitinFromTooth()
        ).stream().filter(r -> !r.output().isEmpty() && !r.inputA().isEmpty()).toList();
    }

    /** Chitin is ground from Friends&Foes trophies; both recipes vanish gracefully without the base mod. */
    private static Recipe chitinFromClaw() {
        return new Recipe(new ItemStack(FnfRefs.item(FnfRefs.CRAB_CLAW), 1), ItemStack.EMPTY,
                new ItemStack(ModItems.CHITIN.get(), 2), 150);
    }

    private static Recipe chitinFromTooth() {
        return new Recipe(new ItemStack(FnfRefs.item(FnfRefs.BARNACLE_TOOTH), 1), ItemStack.EMPTY,
                new ItemStack(ModItems.CHITIN.get(), 2), 150);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, WaxPressBlockEntity entity) {
        ItemStack a = entity.getItem(SLOT_INPUT_A);
        ItemStack b = entity.getItem(SLOT_INPUT_B);
        ItemStack output = entity.getItem(SLOT_OUTPUT);

        Recipe recipe = null;
        for (Recipe candidate : recipes()) {
            if (candidate.matches(a, b) && canPlace(output, candidate.output())) {
                recipe = candidate;
                break;
            }
        }

        if (recipe == null) {
            if (entity.progress > 0) {
                entity.progress = Math.max(0, entity.progress - 2);
                entity.setChanged();
            }
            entity.totalProgress = 0;
            return;
        }

        entity.totalProgress = recipe.ticks();
        entity.progress++;
        if (entity.progress >= recipe.ticks()) {
            entity.progress = 0;
            a.shrink(recipe.inputA().isEmpty() ? 0 : recipe.inputA().getCount());
            b.shrink(recipe.inputB().isEmpty() ? 0 : recipe.inputB().getCount());
            if (output.isEmpty()) {
                entity.setItem(SLOT_OUTPUT, recipe.output().copy());
            } else {
                output.grow(recipe.output().getCount());
            }
            entity.setChanged();
        }
        if (level.getGameTime() % 20L == 0L) entity.setChanged();
    }

    private static boolean canPlace(ItemStack output, ItemStack produced) {
        return output.isEmpty()
                || (output.getItem() == produced.getItem()
                && output.getCount() + produced.getCount() <= output.getMaxStackSize());
    }

    public float burnProgress() {
        return this.totalProgress <= 0 ? 0f : (float) this.progress / (float) this.totalProgress;
    }
}
