package com.fnfbonds.network;

import net.neoforged.neoforge.network.handling.IPayloadHandler;

/**
 * Common-side indirection for client payload handling.
 *
 * <p>26.x has no {@code DistExecutor}, and a method reference to a client class placed in common
 * registration code would force the JVM to link that class on a dedicated server — where
 * {@code net.minecraft.client.Minecraft} does not exist. So the common code registers this no-op
 * field, and the client entry point ({@code FnfBondsClient}, loaded only on the client) replaces it
 * with the real handler during mod construction.
 */
public final class PayloadBridge {
    private PayloadBridge() {}

    /** Replaced by the client entry point on physical clients. */
    public static IPayloadHandler<LedgerSyncPayload> onSync = (payload, context) -> {
    };

    public static boolean isClient() {
        return !onSync.equals(NOOP);
    }

    private static final IPayloadHandler<LedgerSyncPayload> NOOP = onSync;
}
