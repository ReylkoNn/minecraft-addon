package com.fnfbonds.network;

import com.fnfbonds.core.ModTags;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Server → client. Carries either the full ledger snapshot ({@link #MODE_OPEN}) or the compact HUD
 * snapshot ({@link #MODE_HUD}).
 */
public record LedgerSyncPayload(CompoundTag data, int mode) implements CustomPacketPayload {
    public static final int MODE_HUD = 0;
    public static final int MODE_OPEN = 1;

    public static final CustomPacketPayload.Type<LedgerSyncPayload> TYPE =
            new CustomPacketPayload.Type<>(ModTags.id("ledger_sync"));

    public static final StreamCodec<RegistryFriendlyByteBuf, LedgerSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.COMPOUND_TAG, LedgerSyncPayload::data,
            ByteBufCodecs.VAR_INT, LedgerSyncPayload::mode,
            LedgerSyncPayload::new);

    public static LedgerSyncPayload open(CompoundTag data) {
        return new LedgerSyncPayload(data, MODE_OPEN);
    }

    public static LedgerSyncPayload hud(CompoundTag data) {
        return new LedgerSyncPayload(data, MODE_HUD);
    }

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
