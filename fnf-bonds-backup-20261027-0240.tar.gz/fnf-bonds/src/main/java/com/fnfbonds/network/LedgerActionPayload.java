package com.fnfbonds.network;

import com.fnfbonds.core.ModTags;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Client → server. A single generic action packet drives the whole ledger GUI: the action id is one
 * of the constants below and the three arguments are interpreted per action. This keeps the network
 * surface tiny and the server authoritative.
 */
public record LedgerActionPayload(int action, int a1, int a2, int a3) implements CustomPacketPayload {
    public static final int ACCEPT_CONTRACT = 0;
    public static final int TURN_IN_CONTRACT = 1;
    public static final int ABANDON_CONTRACT = 2;
    public static final int SELL = 3;
    public static final int BUY = 4;
    public static final int SEND_CARAVAN = 5;
    public static final int COLLECT_CARAVAN = 6;
    public static final int BUILD_PROJECT = 7;
    public static final int REROLL = 8;
    public static final int DONATE = 9;
    public static final int TAKE_CREDIT = 10;
    public static final int REPAY_CREDIT = 11;
    public static final int CLAIM_LOOT = 12;

    public static final CustomPacketPayload.Type<LedgerActionPayload> TYPE =
            new CustomPacketPayload.Type<>(ModTags.id("ledger_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, LedgerActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, LedgerActionPayload::action,
            ByteBufCodecs.VAR_INT, LedgerActionPayload::a1,
            ByteBufCodecs.VAR_INT, LedgerActionPayload::a2,
            ByteBufCodecs.VAR_INT, LedgerActionPayload::a3,
            LedgerActionPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
