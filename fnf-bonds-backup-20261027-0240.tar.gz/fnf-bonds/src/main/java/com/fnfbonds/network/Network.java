package com.fnfbonds.network;

import com.fnfbonds.core.Commodity;
import com.fnfbonds.economy.Actions;
import com.fnfbonds.economy.EconomyData;
import com.fnfbonds.economy.Project;
import com.fnfbonds.economy.Settlement;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** Payload registration and the server-side action dispatcher. */
public final class Network {
    private Network() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        // the handler itself lives in PayloadBridge so this common class never links a client class
        registrar.playToClient(LedgerSyncPayload.TYPE, LedgerSyncPayload.STREAM_CODEC, PayloadBridge.onSync);
        registrar.playToServer(LedgerActionPayload.TYPE, LedgerActionPayload.STREAM_CODEC, Network::handleAction);
    }

    public static void openLedger(ServerPlayer player, Settlement settlement) {
        openLedger(player, settlement, 0);
    }

    public static void openLedger(ServerPlayer player, Settlement settlement, int tab) {
        PacketDistributor.sendToPlayer(player,
                LedgerSyncPayload.open(com.fnfbonds.economy.LedgerSnapshot.build(player, settlement, tab)));
    }

    public static void sendHud(ServerPlayer player, Settlement settlement) {
        PacketDistributor.sendToPlayer(player,
                LedgerSyncPayload.hud(com.fnfbonds.economy.LedgerSnapshot.buildHud(player, settlement)));
    }

    private static void handleAction(LedgerActionPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (!(context.player() instanceof ServerPlayer player)) return;
            ServerLevel level = player.level();
            Settlement settlement = EconomyData.at(player);
            if (settlement == null) {
                Actions.warn(player, "chat.fnfbonds.error.not_in_settlement");
                return;
            }
            Commodity commodity = Commodity.byOrdinal(payload.a1());
            switch (payload.action()) {
                case LedgerActionPayload.ACCEPT_CONTRACT ->
                        Actions.acceptContract(level, settlement, player, payload.a1());
                case LedgerActionPayload.TURN_IN_CONTRACT ->
                        Actions.turnInContract(level, settlement, player, payload.a1());
                case LedgerActionPayload.ABANDON_CONTRACT ->
                        Actions.abandonContract(level, settlement, player, payload.a1());
                case LedgerActionPayload.SELL -> {
                    if (commodity != null) Actions.sell(level, settlement, player, commodity, Math.max(1, payload.a2()));
                }
                case LedgerActionPayload.BUY -> {
                    if (commodity != null) Actions.buy(level, settlement, player, commodity, Math.max(1, payload.a2()));
                }
                case LedgerActionPayload.SEND_CARAVAN -> {
                    if (commodity != null) {
                        Actions.sendCaravan(level, settlement, player, commodity, Math.max(1, payload.a2()), payload.a3());
                    }
                }
                case LedgerActionPayload.COLLECT_CARAVAN ->
                        Actions.collectCaravan(level, settlement, player, payload.a1());
                case LedgerActionPayload.BUILD_PROJECT -> {
                    Project project = Project.byOrdinal(payload.a1());
                    if (project != null) Actions.buildProject(level, settlement, player, project);
                }
                case LedgerActionPayload.REROLL -> Actions.reroll(level, settlement, player);
                case LedgerActionPayload.DONATE -> Actions.donate(level, settlement, player, Math.max(1, payload.a1()));
                case LedgerActionPayload.TAKE_CREDIT ->
                        Actions.takeCredit(level, settlement, player, Math.max(1, payload.a1()));
                case LedgerActionPayload.REPAY_CREDIT ->
                        Actions.repayCredit(level, settlement, player, Math.max(1, payload.a1()));
                case LedgerActionPayload.CLAIM_LOOT -> Actions.claimLostLoot(level, settlement, player);
                default -> {
                }
            }
            // always push a fresh snapshot so the GUI reflects the outcome
            openLedger(player, settlement);
        });
    }
}
